*start

;###################################################################
*Ep013|Changing bodies changed the world.
;###################################################################
;//１、クラーラ

[SCENE id=13]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


I was thinking of the crala I caught myself.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Dorothy178"]
[OnName num="dorothy"]
Why do you look away ......?"
[cpg cn=true]


[OnName num="renzi"]
No, it's nothing.
[cpg cn=true]


Although she was an enemy in Kulara's eyes, I was attracted to her beauty and her bright, lively personality.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



Then one day. I was summoned by the Demon King.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4" pos="2/2" time=800]

Dorothy was there. She looked a little unhappy because of the other day.
[cpg]



[OnName num="renzi"]
"You wanted to see me? The Witch King.
[cpg cn=true]


[OnName num="rudolf"]
Oh. It's about Clara.
[cpg cn=true]


[OnName num="rudolf"]
It's about time we didn't just capture them. The humans may make their next move."
[cpg cn=true]


[OnName num="rudolf"]
Before that happens, I want to break his heart completely. Can you do it?
[cpg cn=true]


[OnName num="renzi"]
"......Yes."
[cpg cn=true]


I couldn't say no. If I refused, Dorothy or Janice would have to take over that role.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy179"]
[OnName num="dorothy"]
Renji didn't have to do it. I'll do it.
[cpg cn=true]


If Dorothy did it, she would show no mercy. Of course she would treat them badly because they are of the same sex.
[cpg]


[OnName num="renzi"]
No. Let me do it."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy180"]
[OnName num="dorothy"]
Why!　Renji, I like that girl."
[cpg cn=true]


I couldn't answer. That's right, I didn't.
[cpg]


Dorothy was getting even more grumpy, but I had no choice now.
[cpg]


[FO pos="2/2" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





Clara is being held captive today.
[cpg]


She is under house arrest on the grounds that she can be used as a bargaining chip with humans.
[cpg]


Of course, they are not treating her too harshly.
[cpg]


[BG f="b_04_5_up.ui" time=1000]

[FACE method="feadin_up" pos="4/7"]


[WAIT time=1500]

[OnName num="renzi"]
"Kulara. Good morning."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara097"]
[OnName num="clara"]
...... is it morning now?"
[cpg cn=true]


[OnName num="renzi"]
You don't feel it anymore?
[cpg cn=true]


I had come to Kulara in human form.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara098"]
[OnName num="clara"]
I have nothing to say to you.
[cpg cn=true]


Kulara has a bullish attitude toward me or toward demons.
[cpg]


Still, I couldn't help but interrogate her.
[cpg]


;//========================================
;//●ＣＧ（ヒロインの体にぴったりと張り付く形で、触手が覆っている）ev_28
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿室内
;//時間　：暗い
;//備考　：主人公は体にぴったり張り付くような触手に変身しています。触手スーツのような感じ。体全体を覆っています
;//========================================

[STOPBGM]
[FACE method="feadout_up" pos="4/7"]

[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1500]
[BGM f="09"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se015]
;//【ＳＥ】『触手・スライム』

I transformed into a tentacle, which is her pet peeve. Tentacles that cling tightly to her body.
[cpg]


I try to get inside her clothes. It will be a physiologically repulsive feeling.
[cpg]

;**【ＣＧ】 ev_28_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara004"]
[OnName num="clara"]
'Ugh ...... that's disgusting ......'
[cpg cn=true]


Clara still endures desperately.
[cpg]


I don't want to see her suffer any more, and I feel like I want to watch her.
[cpg]


I had a whirlwind of contradictory feelings inside me.
[cpg]


How could I get these feelings out of my head?
[cpg]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

;**【ＣＧ】 ev_28_b ***********************
[CG id=6 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara005"]
[OnName num="clara"]
"Ha, ha, that tickles. ...... ah, ah."
[cpg cn=true]


I can feel her body heat. That's the least I can say. ......
[cpg]


I could feel that Klara was definitely there.
[cpg]


;//移植前シーンカット


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





After all, I didn't want to do anything too terrible.
[cpg]


But then, the situation would always be the same.
[cpg]



[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



Night. As I closed my eyes on the bed, I recalled the first interrogation ...... of Kulara in agony.
[cpg]


Is this really what I want to do ......
[cpg]


I can't help but think. But there was nothing else I could do.
[cpg]


I would probably go to Kulara again tomorrow. After all, it was the Demon King's order.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ブラックアウト


;//移植前シーンカット
[window target=true]


Even if I wanted to be united with Kulara, there was no way to do so.
[cpg]


Considering the current situation where they are enemies of each other and furthermore captives of each other, ......
[cpg]


After all, the only way to end the war between humans and demons is to end the war.
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


;//＠ベッドの上で状況を整理する。
I returned to my room and organized the situation.
[cpg]


First, humans and demons are fighting.
[cpg]


Second, according to the information I got from Kulara, the humans are not looking for a fight.
[cpg]


More to the point, my own feeling on the demon side is that not all of them are so passionate.
[cpg]


Third, as long as Kulala is a prisoner of war, she will not be able to be with me on the demon side as long as she intends to fight on the human side.
[cpg]


There are two ways to be united with Kulara. Either we end this conflict or I betray her.
[cpg]


...... Both of them seem to be very difficult.
[cpg]


I think it's easy to say end it, but this is what's happening now, based on various intentions.
[cpg]


No matter how much transformative power I have, I don't know if I can handle it alone.
[cpg]


As for betrayal, it is emotionally difficult.
[cpg]


In particular, it would betray Dorothy. I'm not so sure that's a good idea.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



Thinking about it, I couldn't come to a conclusion, so I headed for the demon king's place.
[cpg]


[OnName num="renzi"]
Kulara said that the human side wasn't looking for a fight either. I think we can bring them to a truce now."
[cpg cn=true]


[OnName num="rudolf"]
"...... not that I don't think about it too, but ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy181"]
[OnName num="dorothy"]
'I can't. I can't. I can't. I can't. There are demons out there who have had their friends and even family members killed."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[VOICE f="Janice161"]
[OnName num="janice"]
Oh. I suppose it's the same on the human side."
[cpg cn=true]


...... In addition to that, they say there are a lot of speculations and ties.
[cpg]


The human side has a grudge against the demon tribe, and the demon side has some radicals.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


Without a way out, I get tired of thinking about it. I feel like I can't help it anymore.
[cpg]


To put it simply, I was in a funk.
[cpg]


While I was interrogating Kulara, I could certainly feel her, which made my life worth living.
[cpg]


Of course, I also have the feeling that it can't be that good.
[cpg]





[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]
;//ブラックアウト



[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara148"]
[OnName num="clara"]
「……」
[cpg cn=true]


Clara is getting weaker by the day. This is naturally so, even if she is given a decent meal.
[cpg]


Not only will she be under house arrest and without any kind of entertainment, but she will also be under the stress of the possibility of being killed at any moment.
[cpg]


[OnName num="renzi"]
Don't worry, I won't kill Kulala.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara149"]
[OnName num="clara"]
...... what are you talking about?"
[cpg cn=true]


[OnName num="renzi"]
I'm on Kulala's side. Trust me."
[cpg cn=true]


What are you talking about? How can I be on your side? You've been through so much.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara150"]
[OnName num="clara"]
Have you lost your mind too, ......?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara151"]
[OnName num="clara"]
But it's true, it's not just those who are ...... restrained, but those who do it may not be in their right mind.
[cpg cn=true]


Yes. I'm long gone crazy.
[cpg]


I'm already crazy in that I'm in love with Klara.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



If I could, I would stay with Kulara forever.
[cpg]


But I couldn't stay that way.
[cpg]


If I stayed by her side for no reason, she would know how much I liked her. If that happened, I would have to go to ......
[cpg]


I was sure I would be in trouble if I had to hide my true identity and take her out.
[cpg]


Of course, I haven't decided if I'm going to do that at all yet.
[cpg]


I was sure that I would be betraying everyone in the dungeon.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



I had come to the cafeteria for no reason.
[cpg]


I needed to talk to someone. It was like nothing was certain in my mind.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/2" time=800]


In the diner, Dorothy and Janice were there. Asha was not there, as she was on duty.
[cpg]


Dorothy looked at me and said, "Oh," and waved her hand.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Dorothy182"]
[OnName num="dorothy"]
I guess Kulara is a tough one," she said. Can you leave it to me for once?"
[cpg cn=true]


[OnName num="renzi"]
No, no. ...... it is."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice162"]
[OnName num="janice"]
Why don't you want to?　Are you defending Klara?
[cpg cn=true]


You asked me if I was protecting you, and that's exactly what I'm doing.
[cpg]


I wanted to save Klara. It was the only way for us to be together in any way.
[cpg]


[OnName num="renzi"]
Anyway, I'll take care of it. I won't let Dorothy get in the way.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Dorothy183"]
[OnName num="dorothy"]
Yeah?"　I have a lot of grudges against her, so I won't go easy on her.
[cpg cn=true]


That's why I couldn't leave it to him, but I couldn't say it out loud.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f=se009]
;//【ＳＥ】『歩く』



I walk down the aisle back to my room.
[cpg]


Going to Asha's would definitely cure my loneliness. But what I wanted was Kulara.
[cpg]


I can't see anything else, this is ......
[cpg]


Maybe it's love. I had to admit it now.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA01_p4_01_a.ui" method="change_1" pos="2/3" time=800]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

Back in my room, a thought occurred to me.
[cpg]



Come to think of it, I could disguise myself as Kulara, but I had never done so.
[cpg]



;//ここからしばらく、クラーラのセリフ名前欄を「クラーラ（蓮司）」と置き換えてください



[FACE method="change_5" pos="2/3"]


[VOICE f="Clara177"]
[OnName num="renzi_to_clara"]
Really, I look just like her. ......
[cpg cn=true]


I look in the mirror and sigh. I have to know the smell of the person I'm transforming into, and I already know Clara's smell well.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClara006"]
[OnName num="renzi_to_clara"]
;//「ごくっ……我慢、できない」
'...... how beautiful.'
[cpg cn=true]


It was something I hadn't done for a long time. Touching Clara directly, that is.
[cpg]


Well, not technically her itself, but I was touching my hand.
[cpg]


;//移植前シーンカット


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



I want to be surrounded by her scent. With that thought in mind, I went to ......
[cpg]


I went straight to sleep in the form of Kulara: ......
[cpg]





[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





The next morning, still in a daze, I was walking down the street to the cafeteria.
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]

[VOICE f="Dorothy184"]
[OnName num="dorothy"]
Aah!"
[cpg cn=true]


As soon as I saw Dorothy, she was on the warpath.
[cpg]


She was chanting some sort of incantation, and I hurried to explain myself.
[cpg]


[FACE method="change_5" pos="1/2"]
[VOICE f="Clara204"]
[OnName num="renzi_to_clara"]
'Chi, no, it's me. See?"
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



;//ここからクラーラの名前欄を元に戻してください




I transform myself back. In human, male form.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Dorothy185"]
[OnName num="dorothy"]
What the ...... I thought you'd run away."
[cpg cn=true]


[OnName num="renzi"]
Sorry.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy186"]
[OnName num="dorothy"]
But why did you disguise yourself as Kulara?　Could it be ......?"
[cpg cn=true]


Dorothy has a hunch. I denied that, too.
[cpg]


[OnName num="renzi"]
She said, "Nothing. I didn't do anything."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
;//[VOICE f="Dorothy187"]
;//[OnName num="dorothy"]
;//「それって、何かしました、って言ってるようなものだと思うよ」
;//[cpg cn=true]

Yeah?　Dorothy nods her head as she says. I don't think you can fake that.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Even after Dorothy found out about my true feelings, nothing much changed.
[cpg]


The days have continued to go on peacefully. Or, as I put it, "peaceful days.
[cpg]


My love has never borne fruit or withered, and the status quo continues to prevail.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



How can I get married with Kulara? There are two ways to get together with Kulara, I have thought before.
[cpg]


But I can't end the fight so easily.
[cpg]


So I have to do it in another way.
[cpg]


In other words, I would disguise myself as a human being, release Kulara's restraints, and return to the human village as a human being.
[cpg]


If I hide my true identity, Kulara will feel indebted to me, and I can blend in as a human.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



Even though I thought about it, I couldn't do it so easily.
[cpg]

;//移植前シーンカット

I don't want to use my position to get any closer to Kulala than I already am.
[cpg]


It's not so much Kulara as it is my heart that won't take it. I knew that.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Back in my bedroom, I had only one thing to think about.
[cpg]


Get Kulara out of here. I knew the structure of the dungeon to some extent.
[cpg]


I knew how to get out in the shortest possible time, and at what time of the day the guards would be thin on the ground.
[cpg]


I didn't need to think about it, she might be able to manage on her own if I unshackled her.
[cpg]


[OnName num="renzi"]
I guess we'll just have to ...... do it."
[cpg cn=true]


I try to sleep, but I can't. I wonder if Klara would have had a night like this?
[cpg]





[BG f="black.ui"  time=1000]
[WAIT time=100]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


I get up in the morning and head to the cafeteria.
[cpg]


My operation needs to be kept secret. But I couldn't just not discuss it with anyone.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Arsha197"]
[OnName num="asha"]
Good morning, Renji. Didn't get much sleep last night?"
[cpg cn=true]


[OnName num="renzi"]
Good morning ...... do I look like one?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha198"]
[OnName num="asha"]
You looked a little pale. Is something troubling you?"
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


If. If I carry out the operation and rescue Kulara, I will be betraying Dorothy, Janice, and Asha, who have been so good to me.
[cpg]


I can never talk to Dorothy in particular. She has a grudge against Kulara.
[cpg]


Janice would also be against it because of her proximity to the Demon King.
[cpg]


By process of elimination, should I consult Asha?
[cpg]


[OnName num="renzi"]
Hey, Asha,......, when you're free, I'd like you to listen to what I have to say.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha199"]
[OnName num="asha"]
Yeah, what?　I think I can get some time after lunch."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]

A secret story. A story that no one is allowed to hear. But I told them it wasn't about love, so they wouldn't get the wrong idea.
[cpg]


In the empty corridor, I checked my surroundings and then began to talk.
[cpg]


[OnName num="renzi"]
I said, "I'm trying to help ...... Kulara out. I want to disguise myself as a human and start the relationship all over again."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha200"]
[OnName num="asha"]
What the ...... love story, that's it."
[cpg cn=true]


Indeed. I guess I lied a bit as a result.
[cpg]


[OnName num="renzi"]
I like Klara. I really want to be with her.
[cpg cn=true]


[OnName num="renzi"]
If things continue the way they are now, Kullara will never like me even if she resents me."
[cpg cn=true]


[OnName num="renzi"]
'So ...... I want to start over. I can be reborn as someone else, because I can do it."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha201"]
[OnName num="asha"]
You mean, "out of the dungeon," right?
[cpg cn=true]


Asha looked a little thoughtful, but quickly
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha202"]
[OnName num="asha"]
'...... I won't stop you. I don't think letting that brave man go is going to change things much."
[cpg cn=true]


He replied. It's just that ...
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Arsha203"]
[OnName num="asha"]
I kinda ...... nah, it's nothing."
[cpg cn=true]


Asha seemed to miss me leaving.
[cpg]


I was heartbroken, but I had no choice but to tell her how I really felt.
[cpg]


[OnName num="renzi"]
I was sorry. I may not be able to come back to the dungeon for a while.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha204"]
[OnName num="asha"]
I will miss you. But I love you so much."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Asha did not strongly disagree. She did seem to miss him, though.
[cpg]


As it turned out, that was a boost. I went to my room and planned a plan to get Kulara out of there.
[cpg]


No one would ever find out. Even if I was discovered, I wanted to make sure that the plan would not fail in the middle of the operation.
[cpg]


Not only did I simulate various possibilities, but I prepared myself for the possibility of antagonizing my friends.
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="black.ui"  time=1000]
[WAIT time=1000]

[FACE method="feadin_up" pos="4/7"]

;//ブラックアウト
[WAIT time=1000]

[BG f="b_04_5_up.ui" time=1000]
[WAIT time=1500]


In terms of time, it was midnight.
[cpg]


I made my way to the room where Clara was being held captive, and I undid the restraints.
[cpg]


[OnName num="renzi"]
Please wake up. I'm here to help you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara232"]
[OnName num="clara"]
'......?　You are ......."
[cpg cn=true]


I looked like a swordsman. Don't feel strange about being able to come here.
[cpg]


[OnName num="renzi"]
'My name is Harry. Come on, let's get out of here.
[cpg cn=true]


I had a fake name ready. It's a play on my last name, which isn't much of a twist, but it's a name that ......
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara233"]
[OnName num="clara"]
He said, "I'm here to help you." ......
[cpg cn=true]


I'm suspicious. But I backed off, with or without saying so.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se010]
;//【ＳＥ】『走る』




We were running. I had convinced myself that once we got out of here, we would live as human beings.
[cpg]


[OnName num="goblins"]
Wait, wait!　Hey, who's there?
[cpg cn=true]


A pursuer comes. But Kulara fights back with magic.
[cpg]


[OnName num="renzi"]
...... You have great power, don't you? You could have escaped on your own.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara234"]
[OnName num="clara"]
The restraints have the power to seal out demons,...... and I couldn't have gotten out on my own."
[cpg cn=true]


But I alone can do nothing when confronted with demons.
[cpg]


Things went smoothly, partly because Kulara himself had the power.
[cpg]


[FO pos="2/3" time=1000]


;//ブラックアウト

[FACE method="feadin_up" pos="4/7"]



It wasn't a moment before I was outside.
[cpg]


Even so, Kulara's magic was overwhelming. She must have originally been a bowman.
[cpg]


There was no telling how powerful she would be when she was in her element.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara235"]
[OnName num="clara"]
"...... outside ......"
[cpg cn=true]


[OnName num="renzi"]
You made it out.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara236"]
[OnName num="clara"]
Yeah. ...... finally.
[cpg cn=true]


Klara stood there, tears streaming down her face.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara237"]
[OnName num="clara"]
I was scared," she said. I really thought they were going to kill me."
[cpg cn=true]


Then he looks at me. I held his hand, holding on to it, trying to resist the urge to hug him.
[cpg]


The shapeshifter who had tricked Clara was unmistakably me, but now I was acting as her benefactor.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



From there, Kulara and I walked alone.
[cpg]


It is quite a distance to the town where Clara lived.
[cpg]


He was quite weak, and we decided to take a lodging on the way.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





[OnName num="demon_A"]
'......What do you humans want?'
[cpg cn=true]


[OnName num="renzi"]
I just need one night. Can you let me stay the night?"
[cpg cn=true]


[OnName num="demon_B"]
No. We don't want any trouble, even if we are neutral."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara238"]
[OnName num="clara"]
I can handle it, Mr. Harry. I can still walk.
[cpg cn=true]


Klara says so, but if she keeps walking, she even runs the risk of the demons catching up with her.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="5/3" time=1]

Just when I was wondering what to do, I happened to pass by.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[move from="2/3" to="1/2" ease="easeInOutSine" time=2000]
[move from="5/3" to="2/2" ease="easeInOutSine" time=2000]

[wait time=2000]
[FACE method="change_5" pos="2/2"]


[VOICE f="Satuki090"]
[OnName num="satsuki"]
"...... wait. That guy."
[cpg cn=true]


[OnName num="renzi"]
Satsuki!　Please, it's me."
[cpg cn=true]


I can't give you a specific name. But I thought Satsuki would understand.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Satuki091"]
[OnName num="satsuki"]
I knew it. I thought you might be the one.
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Clara239"]
[OnName num="clara"]
What?" "E......?　Um, what do you mean?
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



Not being able to understand, or rather not being able to guess in any way, we were taken up to Satsuki's house.
[cpg]


[OnName num="renzi"]
Thank you," she said. For a while I wondered what would happen.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/2" time=800]
[VOICE f="Satuki092"]
[OnName num="satsuki"]
I'm fine. I guess we weren't compatible after all."
[cpg cn=true]


He seemed to have an idea of what was going on since he was in front of Kulara.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Satuki093"]
[OnName num="satsuki"]
I guess it's just human beings being human ...... after all.
[cpg cn=true]


He chooses his words so as not to be recognized. I had no answer.
[cpg]


;//[free]

[OnName num="renzi"]
I said, "......, Miss Kulara. I think you should go to bed.
[cpg cn=true]


[VOICE f="Clara240"]
[OnName num="clara"]
「……」
[cpg cn=true]


I tried to be concerned about Clara, but she was sitting behind me and almost falling asleep.
[cpg]


[OnName num="renzi"]
She needs to sleep properly."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Clara241"]
[OnName num="clara"]
Yeah, yeah. ...... sorry."
[cpg cn=true]


;//[free]


After Clara fell asleep, Satsuki and I continued talking for a bit.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Satuki094"]
[OnName num="satsuki"]
'My love life was similar to yours, so I kind of get it. It's a love that has crossed race boundaries, isn't it?
[cpg cn=true]


[OnName num="renzi"]
"...... yeah."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Satuki095"]
[OnName num="satsuki"]
But I think it's hard to be in love with a traitor."
[cpg cn=true]


Satsuki's eyes were like a hint of what was to come.
[cpg]

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ヒロイン５の家＿室内』（朝）
;//【ＢＧ】『鬼の集落』（朝）******************************************************


After we had rested enough, we left Satsuki's house.
[cpg]


It was almost noon rather than morning.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/2" time=800]
[VOICE f="Clara242"]
[OnName num="clara"]
I slept well for the first time in a long time. Thank you, um, ......."
[cpg cn=true]


[VOICE f="Satuki096"]
[OnName num="satsuki"]
It's Satsuki. You don't have to thank me.
[cpg cn=true]


[OnName num="renzi"]
Thank you. Satsuki, I won't forget this favor."
[cpg cn=true]


Satsuki seemed to have a pained expression on her face.
[cpg]


I guessed she was worried about our future. I couldn't help but think about the future myself.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（朝）******************************************************

[SE f=se020]
;//【ＳＥ】『草原歩く』


We left the ogre village and started walking toward the town of humans once more.
[cpg]


Kulara seems to be recovering quite well, and I think I can manage even if the pursuers come after me now.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara243"]
[OnName num="clara"]
"Mr. Harry,......, who the hell are you?"
[cpg cn=true]


[OnName num="renzi"]
I'm not much of anything," he said. I'm just a traveler and a swordsman.
[cpg cn=true]


I was, to some extent, considering a false identity.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara244"]
[OnName num="clara"]
Oh, no. You say you are just a swordsman, but there is no way such a person can reach the depths of the dungeon.
[cpg cn=true]


But it may only be a matter of time before the rags come tumbling down.
[cpg]


Still, I had to keep up the pretense. She didn't look at me with suspicion and seemed to feel indebted to me.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************



[OnName num="renzi"]
I arrived at ......."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara245"]
[OnName num="clara"]
Oh ......, you're finally home."
[cpg cn=true]


Clara is on the verge of tears again.
[cpg]


[OnName num="renzi"]
What do we do now? First of all, we should report to our families, right?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara246"]
[OnName num="clara"]
Yes," he said. There are a lot of people who need to know that I'm back here.
[cpg cn=true]


[OnName num="renzi"]
Then go tell them. I'm ......."
[cpg cn=true]


There is money secretly stolen from the dungeon. This will allow me to get a place to stay.
[cpg]


Pretending to be human doesn't mean you can get a house. We'll have to go under the false pretense of being travelers.
[cpg]


[OnName num="renzi"]
I'll go get an inn. I'll see you later.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara247"]
[OnName num="clara"]
Yes, sir. I will repay you in due time. Harry saved my life.
[cpg cn=true]


[window target=false]
[FO pos="2/3" time=1000]
[STOPBGM]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="04"]

;//【ＢＧ】『街』（夜）******************************************************





The day was a big deal. A brave man who had been held captive had made a miraculous comeback.
[cpg]


Her family, her friends, or the entire nation was happy to hear the news.
[cpg]


I had mixed feelings. It was all my fault.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『街』（昼）******************************************************





The city was like a festival all night long, especially in the bars, but it was time for it to calm down a bit.
[cpg]


The next day, I finally met up with Clara once more.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6" pos="2/3" time=800]
[VOICE f="Clara248"]
[OnName num="clara"]
She said, "Thank you. That ......, why don't we talk a little?"
[cpg cn=true]


Klara looked at me and blushed.
[cpg]


That expression was something she would not have directed at me in my demon form.
[cpg]




[window target=false]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se023]
;//【ＳＥ】『ドア閉まる』

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





I was invited to Kulara's house.
[cpg]


It was not a particularly luxurious residence, even though it was the home of a brave man.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara249"]
[OnName num="clara"]
I don't know how to thank you," he said. Really, when you came to my rescue, you were the one who ......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara250"]
[VOICE f="sClara007"]
[OnName num="clara"]
;//「白馬の王子様、というと少し変ですが……でも、ずっと真っ暗な部屋に閉じ込められて、毎日のように犯されてたんです」
'The prince on the white horse, which is a little strange ......, but I was locked in a dark room all the time and interrogated on a daily basis.'

[cpg cn=true]


She says things that are almost confessional already, but my conscience is aching. I'm the one who locked her up and interrogated her.
[cpg]


Is this really what I'm doing?
[cpg]


[OnName num="renzi"]
......Where are your parents now?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara251"]
[OnName num="clara"]
My father and mother are both out right now. I asked them to do so."
[cpg cn=true]


He is blushing. My presence had become such a big deal to Kulara.
[cpg]


I know how she feels, or so I thought. It is not hyperbole to say that I saved her life.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara252"]
[OnName num="clara"]
I want to thank you. Will you come to my room?"
[cpg cn=true]


[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1500]
;//ブラックアウト


[FACE method="feadin_up" pos="4/7"]
[WAIT time=1000]
[BG f="b_05_3_up.ui" time=1000]
[WAIT time=1500]

[BGM f="04"]


Her own room was a lovely room. It did not feel like a brave warrior.
[cpg]


For example, the bookshelves were filled with grimoires, and a few bows adorned the walls. It's not a normal girl's room in that respect, though.
[cpg]


Still, it gave a sense of her everyday life.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara253"]
[OnName num="clara"]
......Please don't be surprised by what I'm about to do."
[cpg cn=true]


[OnName num="renzi"]
By that I mean ......?"
[cpg cn=true]


;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[VOICE f="Clara254"]
;//[OnName num="clara"]
;//「私、あの部屋で何度も虐められて……どこか、おかしくなっちゃったんだと思います」
;//[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClara008"]
[OnName num="clara"]
Don't think it's weird," he said. I don't know what else to do."
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_2" pos="2/3" time=800]


Klara said and put her lips to mine.
[cpg]


[OnName num="renzi"]
"Are you sure ...... you want to do this to me?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara256"]
[OnName num="clara"]
Please don't say that," he said. I've already made up my mind, and now I'm hesitating.
[cpg cn=true]


;//移植前シーンカット

;//移植前シーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************


Even without saying anything, Clara's fondness was all too apparent.
[cpg]


But we can't stay together forever.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara309"]
[OnName num="clara"]
You're leaving already, aren't you?
[cpg cn=true]


[OnName num="renzi"]
Yes.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara310"]
[OnName num="clara"]
I'd like to ...... thank you more. But it's almost night, isn't it?"
[cpg cn=true]


[OnName num="renzi"]
Don't worry, I'm sure we'll see each other again."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara311"]
[OnName num="clara"]
Um, if you don't mind, could you tell me where ...... Harry lives?
[cpg cn=true]


[OnName num="renzi"]
"...... that's..."
[cpg cn=true]


Here it is. If ever there was a time when you need to think, it's at times like this.
[cpg]


[OnName num="renzi"]
'As I said, I'm a traveler. I don't have a home in this city."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara312"]
[OnName num="clara"]
Then you are going to stay somewhere for a while. I'd like to know where you are, at least."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夜）******************************************************





So I brought Kulara to the inn where I was going to stay for a while.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara313"]
[OnName num="clara"]
......It's a very fine place."
[cpg cn=true]


[OnName num="renzi"]
Yeah, well.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara314"]
[OnName num="clara"]
Is Mr. Harry, you know, rich?"
[cpg cn=true]


[OnName num="renzi"]
No. ...... uh.
[cpg cn=true]


When they even ask me how I earned the money, I have no way to answer.
[cpg]


But Kulara didn't pursue it any further.
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
;//ブラックアウト

[window target=true]


[SE f=se024]
;//【ＳＥ】『鳥の鳴き声』





After returning to the inn, I went to sleep and the night dawned.
[cpg]



[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="04"]

;//【ＢＧ】『街』（朝）******************************************************





If you ask me if I am happy or not, I am happy, but on the other hand, anxiety was spreading gradually from under my feet.
[cpg]


How long can I go on like this? If I don't settle down here, I will run out of money.
[cpg]


Of course, I have enough money to live for a while, but even if I get a job somewhere, I can't reveal my identity.
[cpg]


Or I could go back to the dungeon one more time and steal ......?　No, that's too risky.
[cpg]


It should be obvious by now that I ran away, or rather that I took Kulara out.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************





Even if it doesn't bother me for the time being, it's a problem I'll have to deal with at some point.
[cpg]


Be that as it may, there was another problem.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[VOICE f="Clara315"]
[OnName num="clara"]
Mr. Harry!
[cpg cn=true]


In front of the inn, I turn around when I am stopped. There was Kulara waving at me with a big smile on her face.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara316"]
[OnName num="clara"]
I'm here. I couldn't stay. ...... annoy you?"
[cpg cn=true]


[OnName num="renzi"]
No, not really, but ......
[cpg cn=true]


At first I was just happy to be with Clara, but I was getting more and more afraid of getting ripped off.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara317"]
[OnName num="clara"]
'How long have you been in town, Mr. Harry?
[cpg cn=true]


[OnName num="renzi"]
Not so much. I'd say about half a month .......'
[cpg cn=true]


I thought I'd picked a moderate place.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara318"]
[OnName num="clara"]
Half a month!　You conquered a dungeon in just that long?"
[cpg cn=true]


That's what happened. Of course, this is the only town near the dungeon.
[cpg]


[OnName num="renzi"]
No, well, technically, it's a little longer, since we did some camping and such.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara319"]
[OnName num="clara"]
Still, it's great!　It took four of us to get through and we couldn't. ...... Oh, yes."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara320"]
[OnName num="clara"]
I'd like to introduce you to some of the people I was partying with. They are all eager to meet you."
[cpg cn=true]


[OnName num="renzi"]
"...... I see."
[cpg cn=true]


All I could say was yes. I get the feeling that I'm about to get a rag.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





And then. We were all gathered at her house.
[cpg]


[OnName num="monk"]
You rescued Kulara, didn't you?
[cpg cn=true]


[OnName num="warrior"]
He saved my former friends. Let me thank you."
[cpg cn=true]


[OnName num="renzi"]
No, I ...... didn't do much.
[cpg cn=true]


Not only the female priestess and warrior who had once accompanied Kulara, but also her parents were there that day.
[cpg]


[OnName num="clara_mother"]
Truly, it seems like a ...... miracle just to have Kulara home like this again."
[cpg cn=true]


Both of Klara's parents appeared to be of the Elven race.
[cpg]


[OnName num="clara_father"]
He did it all," she said. Thank you, Harry."
[cpg cn=true]


Clara herself is rather cheerful and active, but so were her parents.
[cpg]


And they are genuinely celebrating their daughter's return.
[cpg]


[OnName num="renzi"]
'...... No, not that kind of ......'
[cpg cn=true]


[OnName num="monk"]
'You are very modest. You dived into a dungeon all by yourself and saved your country's hero."
[cpg cn=true]


[OnName num="warrior"]
I know," he said. You sound as if you're trying to say you didn't do anything difficult.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara321"]
[OnName num="clara"]
No way. The four of us would never have gotten to the bottom of it. He risked his life, too.
[cpg cn=true]


[OnName num="warrior"]
"I hope it's ......."
[cpg cn=true]


[OnName num="monk"]
You are a traveling swordsman, aren't you?　Where are you from?
[cpg cn=true]


[OnName num="renzi"]
It's a countryside you wouldn't know if I told you.
[cpg cn=true]


It's a painful development. I can't answer the question properly if they keep digging.
[cpg]


[OnName num="monk"]
I see.
[cpg cn=true]


Aside from her parents, the female priestess and the warrior apparently suspect me.
[cpg]


But they did not inquire further on the spot.
[cpg]



[window target=false]
[FO pos="2/3" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[window target=true]
[STOPBGM]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************





It was getting dark, and after dinner we decided to call it a day.
[cpg]



[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara322"]
[OnName num="clara"]
See you later," she said. How long are you going to stay in this town, Harry-san?
[cpg cn=true]


[OnName num="renzi"]
Yes, it's a very livable town, and I'm considering settling down."
[cpg cn=true]


I know what I said came out of my mouth, but...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara323"]
[OnName num="clara"]
Really?　I'm so happy. I've been wondering when I was going to leave.
[cpg cn=true]


Klara was more pleased than I had imagined.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************





Little by little, my happy life was about to fall apart.
[cpg]


Soon it would be discovered that I was gone, even in the dungeon.
[cpg]


And they would find out that it was me who had taken Kulara.
[cpg]


It was one day when I was thinking like that.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/2" time=800]

[VOICE f="Dorothy188"]
[OnName num="dorothy"]
"Hey, there."
[cpg cn=true]


[OnName num="renzi"]
Yes?"
[cpg cn=true]


I turned around and saw a familiar face.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy189"]
[OnName num="dorothy"]
"Janice, are you sure?"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Janice163"]
[OnName num="janice"]
Yes. The description matches the description of the guards.
[cpg cn=true]


I thought quickly what I was going to do. Escape with the power of a shapeshifter?
[cpg]


...... No. Even if I could change my shape temporarily, once I escaped, I would have to keep running endlessly. It would be more constructive to persuade him.
[cpg]


[OnName num="renzi"]
I'm sorry. I took the liberty of doing that.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Janice164"]
[OnName num="janice"]
You admit it. I wish it was just selfishness, but we've lost our trump card.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy190"]
[OnName num="dorothy"]
Why did you betray me?　Are you going to stay that way forever?"
[cpg cn=true]


[OnName num="renzi"]
I'm going to hide my true identity forever. I'm not going back to the dungeon."
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
You must really like it, Dorothy muttered. She looked kind of chagrined.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy191"]
[OnName num="dorothy"]
It's okay," Dorothy said. I have an idea too ...... or rather, this was Janice's idea."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy192"]
[OnName num="dorothy"]
Renji is someone we need. We will ask him to come back.
[cpg cn=true]

[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]

With that said, Dorothy and Janice readily backed away.
[cpg]


[window target=false]
[STOPBGM]
[BG f="b_07_2.ui" time=1500]
[WAIT time=2000]
[window target=true]

[BGM f="04"]

;//【ＢＧ】『街』（昼）******************************************************





I wonder what they were talking about when they said they had an idea.
[cpg]


I could not even guess. Time went on, and it was past noon.
[cpg]


I was on my way to Clara's house. She often asked me where I was staying and vice versa.
[cpg]


So I thought it wouldn't be a problem, but ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[VOICE f="Clara324"]
[OnName num="clara"]
"...... is that you?"
[cpg cn=true]


[OnName num="renzi"]
What's wrong?"　Your expression is dark."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara325"]
[OnName num="clara"]
Just a few minutes ago, someone claiming to be the daughter of the Demon Lord came to my house.
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


I see. So this is what Dorothy had in mind.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara326"]
[OnName num="clara"]
Harry is an alias, isn't it? I heard your name is Renji.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara327"]
[OnName num="clara"]
You're the shapeshifter who put me in a tight spot back there, aren't you?"
[cpg cn=true]


[OnName num="renzi"]
It's ......."
[cpg cn=true]


I had nothing to say back. Klara already knew the truth, and there was no excuse for what had happened.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara328"]
[OnName num="clara"]
She had been deceiving me all along. I'm the one being deceived.
[cpg cn=true]


It must be complicated for Klara. It means that the person who thought he was helping him is also the person who pushed him over the edge.
[cpg]


[OnName num="renzi"]
Sorry ......."
[cpg cn=true]


Silence falls. What am I supposed to say here?
[cpg]


[OnName num="renzi"]
At first, I did what I did for the sake of the demon tribe. There's no doubt about that."
[cpg cn=true]


[OnName num="renzi"]
I fell in love with Kulara as I was dealing with her. That's true."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara329"]
[OnName num="clara"]
I don't believe anything anymore. I don't even know how much of what you say is true."
[cpg cn=true]


[OnName num="renzi"]
......, yeah, right."
[cpg cn=true]


It's true, I've been waving Kulara around for my own reasons.
[cpg]


I thought I had made her a captive of the demon tribe because I fell in love with her beauty, but I have taken her out of the dungeon to sell her a favor. ......
[cpg]


And in the first place, there is the question of whether the demon tribe can be united with those on the human side, even if they are elves.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara330"]
[OnName num="clara"]
Please go home. I, too, would like to clear my thoughts."
[cpg cn=true]


I returned to the inn, unable to say anything back to him.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





I have known the smell of many demons in my life. It was necessary for me to transform.
[cpg]


If I needed to transform immediately, I would go to the demon's side and smell it.
[cpg]


Even if I didn't, I could transform with someone I had known for a long time because I somehow knew their scent.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************





I had one resolution in my mind. I had already decided who I would transform into this time.
[cpg]


In other words, the Demon King. I will transform into him and negotiate with the human king.
[cpg]


If humans and demons are not going to be united, then I have no choice but to end this battle.
[cpg]


If anyone can do that, it's either the Demon King or me, who can pretend to be the Demon King.
[cpg]


Of course, even if I disguised myself as the Demon King, I have no magical power myself, and there is nothing I can do if I am seized.
[cpg]


It is a dangerous strategy that could get me killed on the spot if I am not careful.
[cpg]


[OnName num="renzi"]
It's a little late for that, isn't it ......?"
[cpg cn=true]


I've done a lot of dangerous things in my life. Still, I want to be united with Kulara.
[cpg]


I have no choice but to do it. I died once in this life, I'm not afraid of anything.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="07"]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



As we head toward the center of the city, the buildings and streets gradually become more and more decorated.
[cpg]


The royal palace is approaching. I still don't look like a demon king.
[cpg]


It is better to keep the time I am in the form of the Demon King as short as possible. It is less risky to assume the form only in front of those who need it.
[cpg]


Then I headed for the palace. I was stopped by a soldier, but I hope he is someone I can talk to.
[cpg]


[OnName num="renzi"]
Let me through ......."
[cpg cn=true]


I negotiate, remembering what the Demon King would say and how he would behave.
[cpg]


[OnName num="soldier"]
'Hey, what do you want ...... to do, come to kill us?
[cpg cn=true]


The soldiers are frightened. I guess they have some idea of what the Demon Lord is like, which is convenient.
[cpg]


[OnName num="renzi"]
I need to talk to the king. Take him away.
[cpg cn=true]


[OnName num="soldier"]
What about ......?"
[cpg cn=true]



[FACE method="feadin" pos="4/7"]
[WAIT time=2000]

We don't know what kind of person a human king is.
[cpg]


It's a gamble. If he is belligerent, he will try to kill me.
[cpg]


He is coming alone, without his men. If that is the case, they will think there is no better chance than now.
[cpg]


On the other hand, what if he really wanted to build a friendly relationship?
[cpg]


It would look like the Demon King was taking the risk of being alone. I think it would look like he was serious.
[cpg]


On the other hand, I don't know anything about politics. I had no choice but to keep my mouth shut and try not to reveal anything.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『街』（夜）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください



[OnName num="king"]
"Welcome to my office," he said. It's been a long time.
[cpg cn=true]


Long time no see?　Have we met?
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


I don't know, so I keep quiet. Don't lose the serious look on your face. I can't be afraid.
[cpg]


[OnName num="king"]
If you came all the way here alone, are you trying to negotiate something?"
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


[OnName num="Chancellor"]
We suspect it may have something to do with Kulara's escape.
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


[OnName num="king"]
I see. How's that?"
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『街』（朝）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください





I tried to be as reticent as possible, and if asked anything, I would simply say, "I'm here to call for a cease-fire.
[cpg]


I don't really know what the word "ceasefire" means, but I felt it was better not to say that I wanted to end the war.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください





I desperately tried to stop the conflict between humans and demons. For the sake of everyone I have ever met, but especially for the sake of Kulara.
[cpg]


The discussion went on for a long time, and it was even becoming a question of whether I was the real Demon King. That's when I was called to ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara331"]
[OnName num="clara"]
...... if he's the real Demon Lord?
[cpg cn=true]


[OnName num="king"]
Oh. If you've been deep into the dungeon, haven't you seen it?"
[cpg cn=true]


It was Kulara. I was inwardly impatient, she might be able to guess everything.
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


Still, I had to keep my mouth shut. After all I had already done all I could do.
[cpg]


Clara knows. There are shapeshifters. And that the shapeshifter, in other words, likes me.
[cpg]


So what do we do? Who is this Demon Lord really who is trying to bring about a truce?
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara332"]
[OnName num="clara"]
"...... this person, the Demon Lord, is ......"
[cpg cn=true]


Swallow hard. I tried not to let them see the gesture.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara333"]
[OnName num="clara"]
'It's real. Without a doubt, it is the very Demon Lord I saw."
[cpg cn=true]


[OnName num="king"]
...... I see."
[cpg cn=true]


I was relieved, but I could not beat my chest. I kept up my bluff.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="feadin_up" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="07"]

;//【ＢＧ】『街』（夜）******************************************************


;//背景をそのまま表示してください


Things went smoothly from Clara's testimony.
[cpg]


Most of the time, the viziers of the human side, the king's entourage, were talking, and I was just sitting there.
[cpg]


Even so, a cease-fire was established. It went incredibly well.
[cpg]


I wonder if Kulara really didn't notice. Was my transformation that precise?
[cpg]


Or did she know all about it, and missed it out of pity for me?
[cpg]


Or did she feel my seriousness and cooperate with me?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





I don't know these things at this point.
[cpg]


But the most urgent thing for me to do now was to return to the dungeon.
[cpg]


I must not have any difference of opinion with the real Demon King. I must go and tell her what I did.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





I wanted to do it as soon as possible, but sadly, I didn't have the strength.
[cpg]


On the way to the village, I stopped at a demon village, told Satsuki what had happened, and asked her to let me stay the night.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Satuki097"]
[OnName num="satsuki"]
She said, "...... your story has been told all the way here."
[cpg cn=true]


[OnName num="renzi"]
Is that so?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki098"]
[OnName num="satsuki"]
Yes. The humans don't seem to realize it, but an imposter demon king has made a truce.
[cpg cn=true]


Well, the demon tribe may have passed on information from the demon side as well.
[cpg]


They may be able to objectively understand the conflicting information.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki099"]
[OnName num="satsuki"]
I'm sure it was you, wasn't it?　If I had been a bad guy, they would have killed me."
[cpg cn=true]


[OnName num="renzi"]
It was all right. I was willing to die if it didn't work out.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki100"]
[OnName num="satsuki"]
Where does this obsession come from? Is it love?
[cpg cn=true]


[OnName num="renzi"]
Oh. Even Satsuki knows that.
[cpg cn=true]


Satsuki was a little at a loss for an answer.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki101"]
[OnName num="satsuki"]
Yes," he said. "Yes, I do.
[cpg cn=true]


I answered. I hope that the bickering between the races will stop and her love will one day come true.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





The next morning, I left the demon village and walked further. And finally ......
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





I came back. It was time to explain everything I had done.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]

[VOICE f="Dorothy193"]
[OnName num="dorothy"]
What do you mean?　Explain it all."
[cpg cn=true]


[OnName num="rudolf"]
Dorothy, don't be so angry. You know what I mean.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice165"]
[OnName num="janice"]
But ...... that means you ignored all of our wishes."
[cpg cn=true]


[OnName num="rudolf"]
Are you sure about that?　Janice, you haven't fought enough humans yet."
[cpg cn=true]


The Demon Lord was a man who knew how to talk. I had somehow sensed a hint of that before.
[cpg]

;//[free]

[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]

[OnName num="renzi"]
I am sorry. It was all for my own convenience.
[cpg cn=true]


[OnName num="rudolf"]
No," he said. I had a feeling this would happen from the moment I took Kulara away.
[cpg cn=true]


Is it true? If so, how many moves can he read ahead of time?
[cpg]


[OnName num="rudolf"]
I knew we couldn't stay at odds with each other forever. But I couldn't negotiate directly with him.
[cpg cn=true]


For the demon king, jumping into the bosom of humans was a scary thing to do.
[cpg]


And my willingness to do so on his behalf was respected as a result.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy194"]
[OnName num="dorothy"]
Wait a minute!　Dad, are you sure you want to do this?"
[cpg cn=true]


[OnName num="rudolf"]
What is it?"　What's the problem?　So it's what I wanted.
[cpg cn=true]


[OnName num="rudolf"]
Or does Dorothy have a problem with the cease-fire coming into effect?
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Dorothy195"]
[OnName num="dorothy"]
That's it!　No, no, but..."
[cpg cn=true]


...... Dorothy gets a little tsundere-like in these situations.
[cpg]


I know how she feels too. But I can't respond.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『平原』（昼）******************************************************





The tension between humans and demons is slowly dissolving.
[cpg]


I couldn't be satisfied with that. There is still a part of the conflict going on.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************


I had to go back and forth between the human town and the demons' dungeon.
[cpg]


It was a bridge between the two races. It was a somewhat rewarding job, considering that it was also for the sake of world peace.
[cpg]


Normally, I looked like I did when I rescued Kulara. I can't always be dressed as a demon king.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[VOICE f="Clara334"]
[OnName num="clara"]
Ah ......"
[cpg cn=true]


Also, while staying in town, Klara saw me and approached me.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara335"]
[OnName num="clara"]
She said, "I prefer to call you Renji, not Harry."
[cpg cn=true]


[OnName num="renzi"]
Either one is fine, but I think I'd feel more comfortable that way."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（昼）******************************************************





I am invited to her house. She herself has long been aware of the truth and has told her family about it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara336"]
[OnName num="clara"]
You really are a ...... daredevil.
[cpg cn=true]


[OnName num="renzi"]
I thought it would be better if I didn't. I've been betrayed so many times before.
[cpg cn=true]


Hearing the words, Klara was a little silent.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara337"]
[OnName num="clara"]
Please wait a moment," she said. I'll make you some tea."
[cpg cn=true]

;//[free]

[FO pos="2/3" time=1000]
[WAIT time=1100]

Her parents seemed to be absent. The silence was somehow awkward.
[cpg]

[SE f=se011]
;//【ＳＥ】『食器の音』

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara338"]
[OnName num="clara"]
Here you go.
[cpg cn=true]


[OnName num="renzi"]
Thank you."
[cpg cn=true]


I sip the tea. There is such a thing as tea in this world, isn't there?
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara339"]
[OnName num="clara"]
......I've always wanted to have a quiet cup of tea like this someday.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara340"]
[OnName num="clara"]
With you, too. I knew it was true that you love me.
[cpg cn=true]


[OnName num="renzi"]
"...... it's true."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara341"]
[OnName num="clara"]
There were times when I wondered if I loved you.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara342"]
[OnName num="clara"]
He said, "He just helped me, and then he did that to me. It was you who did that, and it was you who pushed me over the edge."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara343"]
[OnName num="clara"]
Maybe I'm still in doubt. Will you let me be sure from now on?"
[cpg cn=true]


[OnName num="renzi"]
Of course. I'll be the one Clara likes."
[cpg cn=true]


An ambiguous and complicated relationship.
[cpg]


Klara may have been lost, but I wasn't.
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





Everything I had done seemed to be connected to this moment.
[cpg]



;//========================================
;//●ＣＧ（ベッドに隣り合って座っている二人）ev_31
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//備考　：主人公は人間の姿に変身しています
;//========================================

;//*Scene025

[STOPBGM]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="sClara009"]
[OnName num="clara"]
I'm kind of ...... more nervous than I was at the beginning."
[cpg cn=true]


[OnName num="renzi"]
When was the first time?　You mean when I kidnapped you?"
[cpg cn=true]


Klara shook her head. Her cheeks were flushed.
[cpg]



[VOICE f="sClara010"]
[OnName num="clara"]
It was right after you rescued me. I think my feelings were still unstable at that time.
[cpg cn=true]


She was nervous then. Is that so?
[cpg]


Looking back, I think she was definitely stiff.
[cpg]


It was right after she was rescued, so maybe she was still in the process of sorting out her feelings.
[cpg]


[OnName num="renzi"]
How about now?　Are you still nervous?"
[cpg cn=true]

;**【ＣＧ】 ev_31_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara011"]
[OnName num="clara"]
I wonder if ...... now." Can you make sure?"
[cpg cn=true]


I put my lips to hers.
[cpg]


She didn't refuse. At last, I felt that we were truly connected.
[cpg]


;//移植前シーンカット

;//移植前シーンカット

;//ブラックアウト



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





No matter what happens from now on, the feeling of mutual love will never change.
[cpg]


It was no trick. I felt I could assure her of that.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara396"]
[OnName num="clara"]
I asked her, "Are you going to go to ...... now?"
[cpg cn=true]


[OnName num="renzi"]
'Well, ...... I have business in the dungeon again. I have to take care of their intentions over there too."
[cpg cn=true]


Klara looked forlorn. After a moment of brooding.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara397"]
[OnName num="clara"]
Um, can I come with you?"
[cpg cn=true]


He said. I was surprised.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************

[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

Then, Kulara really followed me.
[cpg]


[OnName num="renzi"]
Are you going to come all the way into the dungeon?　I'm sure there are enemies everywhere."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara398"]
[OnName num="clara"]
I intend to go. You've always lived in the dungeon.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara399"]
[OnName num="clara"]
I'd like to know what kind of people your friends are.
[cpg cn=true]


[OnName num="renzi"]
But be careful, some of the ...... demons are still a bit extreme."
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************



[SE f=se020]
;//【ＳＥ】『草原歩く』





We left the city and walked across the plains at night. Kulara was a stone's throw away from the city.
[cpg]


She must be used to camping and such. I was exhausted before she was.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara400"]
[OnName num="clara"]
Renji, you are quite weak, aren't you?
[cpg cn=true]


[OnName num="renzi"]
He said, "Kulara is too strong. ...... I knew the brave man was different."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara401"]
[OnName num="clara"]
Don't make fun of me. I have muscles, too, and I care about them.
[cpg cn=true]


Talking with Kulara about nothing else. I loved that time more than anything.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『平原』（朝）******************************************************





When night turned into morning and eventually into day.
[cpg]




[window target=false]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

We arrived at the dungeon. From here on, it was really just Kulara's enemies.
[cpg]


I don't even know if she'll let me stay, but I'll have to push my way in there.
[cpg]


[OnName num="renzi"]
I'm going to say this again and again, but you better brace yourself. Some of them might say some heartless things."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara402"]
[OnName num="clara"]
It's okay. It's natural for people to say things like that.
[cpg cn=true]


Kulara is another one of those people who didn't want to fight.
[cpg]


When I thought about it, it seemed like maybe I did the right thing.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


As we walked through the corridors of the dungeon, we talked.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara403"]
[OnName num="clara"]
'I'm an elf, as you can see.
[cpg cn=true]


[OnName num="renzi"]
'Oh ...... what about it?'
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara404"]
[OnName num="clara"]
I'm subhuman," he said. When the battle first broke out, there was a dispute over whether to side with the humans or the demons.
[cpg cn=true]


Kulara began to tell me the story of how he had become a brave man.
[cpg]


I kept quiet and listened while walking slowly.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara405"]
[OnName num="clara"]
I was not a pure person, so I was persecuted at times.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara406"]
[OnName num="clara"]
'It's all a reaction, isn't it? You know, I spent a lot of time fighting. ......"
[cpg cn=true]


They also worked to improve the status of elves by achieving battle results.
[cpg]


And while those efforts were bearing fruit, he was now beginning to think that there might be a solution other than fighting.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara407"]
[OnName num="clara"]
...... this may be true for Renji as well.
[cpg cn=true]


[OnName num="renzi"]
Sure, I'm a demon or a human, it's a fine line."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara408"]
[OnName num="clara"]
It's hard for both of us to be half-assed."
[cpg cn=true]


[OnName num="renzi"]
I may be halfway there, but I'm always on Kulara's side. I'm not half-hearted about that."
[cpg cn=true]


Klara nodded. She looked happy.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





We walked further again. I was explaining to Kulara what was going on in the dungeon.
[cpg]


[OnName num="renzi"]
This is my room.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[VOICE f="Clara409"]
[OnName num="clara"]
You have a ...... room called "my room?"
[cpg cn=true]


[OnName num="renzi"]
That's because they're living creatures. ...... Even ants have burrows.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara410"]
[OnName num="clara"]
It's kind of strange. I thought it would be more organized.
[cpg cn=true]


[OnName num="renzi"]
They're pretty much like people. They're probably closer to a regular castle or something, just underground."
[cpg cn=true]


Klara scurried over and said, "I'm sorry.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara411"]
[OnName num="clara"]
......I remember when you interrogated me.
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


I didn't know how to respond, but Kulara was blushing.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara412"]
[OnName num="clara"]
'I'm really not good with tentacles. They scared me."
[cpg cn=true]


[OnName num="renzi"]
Why is your face red when you talk about being scared?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara413"]
[OnName num="clara"]
Why don't you give it one more try?" Maybe now you can overcome your weakness."
[cpg cn=true]


Klara wanted to relive those days again.
[cpg]


Maybe she is trying to override the trauma in her.
[cpg]


[OnName num="renzi"]
She said, "I understand ....... It's hard to stay with bad memories, isn't it?"
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=100]
;//ブラックアウト

;//移植前シーンカット


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

However, there is no art in blaming them for looking the same as before. I was disguised as a tentacle creature like an octopus.
[cpg]

[VOICE f="sClara012"]
[OnName num="clara"]
I'm still a little scared,......, but when I know it's Renji, I love him.
[cpg]


Our relationship has changed. I can't go back to the past anymore. We're just going where we're going.
[cpg]



;//========================================
;//●ＣＧ（触手責め。ヒロイン仰向けの姿勢でベッドに寝ているヒロイン）ev_33
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は蛸のような触手生物に変身しています
;//========================================

;//*Scene027

[STOPBGM]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1500]




[VOICE f="Clara441"]
[OnName num="clara"]
Do you do that with your ...... ears, too?
[cpg cn=true]


He even touched Clara's, who was shy, ears.
[cpg]



[VOICE f="Clara442"]
[OnName num="clara"]
'Nnnn......, it's slimy. It feels strange.
[cpg cn=true]


Clara says this and wriggles at the touch.
[cpg]


It looks like she doesn't like it, but she doesn't reject it.
[cpg]


The word "strange" suggests that she is not rejecting the touch from the bottom of her heart.
[cpg]


The tentacles are wet, so there must be some sonic pleasure.
[cpg]


Both men and women have a sound fetish. How about Klara?
[cpg]


With this in mind, I will only abuse the ears. I will keep doing this for a while.
[cpg]


And as I touch her, she says something like this.
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara464"]
[OnName num="clara"]
'I love you, I love Renji more than ...... anyone else.'
[cpg cn=true]


Clara whispers sweet words, but is this the right time to say them?
[cpg]


I wasn't even going to refuse to accept Clara's invitation. Hopefully, I would be touching her all the time.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





In the end, I forgot what I had originally come here for and flirted with Kulara for a while.
[cpg]


Since I was in a dungeon, my sense of time was a little fuzzy.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="sClara013"]
[OnName num="clara"]
I was wondering what Renji ...... had to do with this place.

[cpg cn=true]


[OnName num="renzi"]
Oh, by the way, ......
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy196"]
[OnName num="dorothy"]
You're late.
[cpg cn=true]


[OnName num="renzi"]
I'm sorry. ......
[cpg cn=true]


;//[free]

[OnName num="rudolf"]
Well, it's good you're here. How have the humans been doing since then?
[cpg cn=true]


[OnName num="renzi"]
I think things are going well. The king himself and the prime ministers seemed to have wanted this from the beginning.
[cpg cn=true]


[OnName num="rudolf"]
I see. I'm glad to hear that.
[cpg cn=true]


[OnName num="rudolf"]
We want the same thing. We hope to be able to distribute things step by step."
[cpg cn=true]


For the time being, mere confirmation of facts. We've been talking about how everything is going so well.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/2" time=800]
[VOICE f="Janice166"]
[OnName num="janice"]
By the way, I walked by Renji's room just now. ...... Who was that voice?"
[cpg cn=true]


Suddenly Janice said so. I guess she knew.
[cpg]


[OnName num="renzi"]
Oh, no, that was the ......
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy197"]
[OnName num="dorothy"]
The elf?
[cpg cn=true]


[OnName num="renzi"]
"...... yes."
[cpg cn=true]


I didn't feel like I could hide it, so I answered.
[cpg]


[FACE method="change_4" pos="2/2"]
[VOICE f="Dorothy198"]
[OnName num="dorothy"]
Hmmm. I'm in a dungeon. Hmm."
[cpg cn=true]


Dorothy is blatantly grumpy.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice167"]
[OnName num="janice"]
You can bring them here all you want, but there will be some who won't like it. You'd better be careful.
[cpg cn=true]


I couldn't say anything back and fell silent.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy199"]
[OnName num="dorothy"]
'...... Well, okay. Janice."
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Janice168"]
[OnName num="janice"]
What?"
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy200"]
[OnName num="dorothy"]
Renji is the one who made the current peace possible. It would be pitiful to kick her out."
[cpg cn=true]


Dorothy remains grumpy. But she wasn't trying to get rid of Kulara.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I guess that's one change. The Dorothy of the past would not have said this.
[cpg]


She felt that her peaceful days would continue. I am just happy now.
[cpg]


If there is ever another fight, I feel I can stop it. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara467"]
[OnName num="clara"]
How was it?"
[cpg cn=true]


[OnName num="renzi"]
The Demon King has been very cooperative. Things are going well."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara468"]
[OnName num="clara"]
I'm glad to hear that. Shall we go back to the city?"
[cpg cn=true]


[OnName num="renzi"]
Yeah, well, ...... I'm going to miss this room, but I'm not going to miss this room."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara469"]
[OnName num="clara"]
Then let's stay here a while longer. I'm always ready."
[cpg cn=true]


He blushes as he says, "Here, my parents won't be here.
[cpg]


[OnName num="renzi"]
Oh," he said. You can flirt as much as you want.
[cpg cn=true]


Klara nodded, looking embarrassed.
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

We can leave this dungeon whenever we want, Klara said.
[cpg]


As far as feelings go, we can make love forever. But it's not going to happen.
[cpg]


I was going to change back into my human form and leave the dungeon. Because
[cpg]


[OnName num="renzi"]
I'm sure Klara's parents are worried about her."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara495"]
[OnName num="clara"]
No, it happens all the time. I've been on a lot of dangerous missions."
[cpg cn=true]


[OnName num="renzi"]
But now you're finally at peace."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara496"]
[OnName num="clara"]
...... Sure, maybe it's time to go back."
[cpg cn=true]


With such talk, he and Kulara head back to the city.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





The time between the dungeon and the city cannot be but a moment.
[cpg]


I could turn into a bird-like demon, but I can't fly with people on board.
[cpg]


Even if I could imitate their ecology, I would not be able to wield all of their original power.
[cpg]


[window target=false]
[STOPBGM]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夕方）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

Kulara seemed to understand this.
[cpg]


I know it must be tedious during this trip, but Kulara is so far ahead of me.
[cpg]


I thought so before, but I guess she has a lot of energy.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara497"]
[OnName num="clara"]
"Are you all right, sir?　Do you want to take a break?"
[cpg cn=true]


[OnName num="renzi"]
Yes, no, I'm fine. ......
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





If I had not been able to relay the demon village along the way, I might have collapsed.
[cpg]


That's how grateful I was for Satsuki's cooperation.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/2" time=800]

[VOICE f="Satuki102"]
[OnName num="satsuki"]
I was so thankful for Satsuki's help. You must have been there and back many times, but you always seem to have a hard time.
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Clara498"]
[OnName num="clara"]
Is it possible that being a shapeshifter makes it harder to build muscle?
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Satuki103"]
[OnName num="satsuki"]
I wonder if ......
[cpg cn=true]


I noticed that Clara and Satsuki were getting to know each other a bit.
[cpg]


Various barriers are being broken down. I hope one day I will be able to talk to Dorothy and the others.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f=se009]
;//【ＳＥ】『歩く』





And as we walked, we came back to the town again.
[cpg]


I still think of the dungeon as home when it's a dungeon and this town. ......
[cpg]


But my real hometown is modern Japan.
[cpg]


Strangely, I don't miss it anymore. I don't even want to go back.
[cpg]


If this world definitely existed and needed me, I wouldn't feel that way.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（昼）******************************************************

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="renzi"]
How's it going?　Does it feel right?"
[cpg cn=true]


And I further refined my transformation as a shapeshifter.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara499"]
[OnName num="clara"]
I thought my ears might be a little bigger. ......
[cpg cn=true]


[OnName num="renzi"]
Maybe I can. I'll try."
[cpg cn=true]


My ability to transform was becoming more and more flexible.
[cpg]


At first I couldn't transform into anything I couldn't smell, but as I ...... sniffed various demons, my abilities transformed.
[cpg]


匂いが想像できるものに対しては、ある程度自在に変身できるようになっていた。
[cpg]


In other words, I was able to transform into a being or person that did not exist. Using this ability, I was trying to transform myself into an elf that was no one else.
[cpg]


[OnName num="renzi"]
I knew that if I kept dressing up as someone who could be anywhere, I'd be in trouble.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara500"]
[OnName num="clara"]
I agree. But why are you elves?"
[cpg cn=true]


[OnName num="renzi"]
I just want to get as close to Kulala as possible."
[cpg cn=true]


I found myself saying honest words. Klara blushes.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara501"]
[OnName num="clara"]
'Really, I don't feel uncomfortable. No matter what he looks like, Renji looks great.
[cpg cn=true]


Kulara says something that makes me gulp. I feel like I want to hug her right now.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************

;//移植前シーンカット




Everything was about to be resolved. There was going to be some kind of trade between the humans and the demons.
[cpg]


If things moved little by little, people and demons would come and go. If that happens, the borderline will become more and more blurred.
[cpg]


Just as the demon called me and the elf called Kulara were united.
[cpg]


If that kind of love increases even a little, there is nothing more I could wish for.
[cpg]


I could say that all of this was possible because I was a half-breed and a traitor.
[cpg]



;//========================================
;//●ＣＧ（二人布団の中でいちゃつく。身を寄せ合っている感じ）ev_35
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：主人公はエルフに変身しています
;//========================================


[STOPBGM]
[BG f="black.ui"  time=1000]
[WAIT time=100]
[BGM f="09"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1500]






[VOICE f="Clara526"]
[OnName num="clara"]
...... It's already morning, isn't it?"
[cpg cn=true]


[OnName num="renzi"]
I swear ...... I feel like sleeping till noon or so."
[cpg cn=true]



[VOICE f="Clara527"]
[OnName num="clara"]
No." You said you had things to do today."
[cpg cn=true]


[OnName num="renzi"]
I know," he said. I have something I have to tell the king over here."
[cpg cn=true]


However, this does not change the course of our friendship.
[cpg]


I was thinking that I don't have to go.
[cpg]


[OnName num="renzi"]
Let me sleep just a little. ......
[cpg cn=true]

;**【ＣＧ】 ev_35_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara528"]
[OnName num="clara"]
Heh. That's fine, I'll wake you up in the morning."
[cpg cn=true]


With that said, Kulara did not mess with me any more.
[cpg]


I think Kulara and I can live happily ever after. If the world is going to stop being like that, I'll change it again.
[cpg]


Looking back, I think Kulara has been making efforts for that purpose for a long time.
[cpg]


We may be similar to each other. Was it our destiny to be attracted to each other?
[cpg]



[VOICE f="Clara529"]
[OnName num="clara"]
Good night, Renji.
[cpg cn=true]


[OnName num="renzi"]
Oh, good night. ......
[cpg cn=true]


I closed my eyes, feeling Clara at my side.
[cpg]


I knew that the next time I woke up, she would still be there. I was happy now that I could believe that.
[cpg]


[SCENE id=18]


;//ＥＮＤ　ヒロイン１ルート


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
