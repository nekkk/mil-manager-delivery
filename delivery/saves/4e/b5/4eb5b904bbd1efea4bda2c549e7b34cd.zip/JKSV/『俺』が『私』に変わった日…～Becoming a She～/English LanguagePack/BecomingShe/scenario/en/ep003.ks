


;#################################################
*Ep003|この学園の秘密
;#################################################

[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[if exp={ isSystemFlagsEnabled( "sysflg_01") }]
[stflag Cha1flg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysflg_2t3f") }]
[stflag Cha2flg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysflg_2t3f") }]
[stflag Cha3flg = 1]
[endif]


*start|この学園の秘密


[SCENE id=3]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

And the days passed for a while.
[cpg]


I was approached by Shiho, who had a crush on me, and I was also played with by Azusa. ......
[cpg]


I have not had anything from Honoka since then, but the time passed by at a dizzying pace.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Then one day. I decided to stop thinking alone anymore and decided to ask my question.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Honoka, Kotoyu-san, and I were in the middle of a conversation.
[cpg]



[OnName num="Rin_male"]
I said, "Oh, you know what? Ms. Kotoyu, isn't there something strange about this school?"
[cpg cn=true]


A vague question. But nothing can start without asking this question.
[cpg]


[OnName num="female_student"]
What do you mean by something strange?　I want to ask specifically.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka049"]
[OnName num="Honoka"]
I don't know what you mean. I don't know what you mean.
[cpg cn=true]


Then let's be a little more specific. I'm afraid you're going to find out about me. ......
[cpg]


In short, I asked if the school was a place where people with problems or peculiarities gathered.
[cpg]


Then, Kotoyu-san chuckled. What's so funny?
[cpg]


[OnName num="female_student"]
My name is Saya Kotoyu," she said.
[cpg cn=true]


[OnName num="female_student"]
But when I was a boy, I used to write it in kanji (Chinese characters) as Saya.
[cpg cn=true]


I was surprised, but at the same time, I knew it was true.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Honoka050"]
[OnName num="Honoka"]
What do you mean?　What does that mean?
[cpg cn=true]


[OnName num="female_student"]
The actuality is that the actuality is that the actuality is not really a good idea.　The actual school is just as you say.
[cpg cn=true]


[OnName num="female_student"]
We get all these idiosyncratic students. It's just a rumor, so I'll leave it to you to judge."
[cpg cn=true]


 Rumors are too coherent. I had to believe
[cpg]


[OnName num="female_student"]
 "I've already noticed Rin-san's dress as a woman."
[cpg cn=true]



[OnName num="Rin_male"]
I'm sure you're lying.　The actuality of the fact is, it's not really a matter of whether or not you're a good person.
[cpg cn=true]


Even though I said something like that, there were various times when it seemed like I would find out.
[cpg]


It was bad enough when they asked about idols. I guess it was that timing.
[cpg]


Or maybe they had been aware of it since the first day they entered the school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka051"]
[OnName num="Honoka"]
I didn't notice it at all. Does that mean everyone else did too?
[cpg cn=true]


[OnName num="female_student"]
I don't know. It's just a rumor.
[cpg cn=true]


[OnName num="female_student"]
I think most of the girls are girls from the beginning, ...... but I still think they all have something going on."
[cpg cn=true]


Oh my God. The things that seem to be a lie are not a lie.
[cpg]


Maybe there are more lies hidden in this school.
[cpg]


How am I supposed to spend my time?
[cpg]



;//■選択肢
[switch]
[case "I don't force myself to pursue the lie."]
	[swap]
	[jump target="*select03_1"]
[case "Question everything."]
	[swap]
	[jump target="*select03_2"]
[endswitch]



1. Don't force a lie.
2. Question everything.



;//==============================
;//１、嘘を無理に追及しない
*select03_1|The secret of this school


;//詩歩ルートと穂乃香ルートで選択肢が発生せずバッドエンドで固定される
[stflag ChaBad = 1]
[system sysflg_bad=true]


It's better to leave a lie as a lie.
[cpg]


Forcing the truth can lead to trouble.
[cpg]


[jump target="*select03_3"]
;//==============================
;//２、全てを疑ってかかる
*select03_2|この学園の秘密
[system sysflg_bad=false]



;//詩歩ルートと穂乃香ルートで選択肢が発生する


From now on, let's be careful about many things.
[cpg]


You never know what will happen at this school. I learned that firsthand.
[cpg]



;//==============================
*select03_3|この学園の秘密


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


But still, I've learned something terrible. what to expect.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho070"]
[OnName num="Shiho"]
Oh, Rin-san. Hello.
[cpg cn=true]


Poetess has a peculiar constitution, too. It must have something to do with the love constitution.
[cpg]


I think it's related, or rather, it's a peculiarity in itself.
[cpg]


[OnName num="Rin_male"]
I'm sure it has something to do with your peculiar constitution.
[cpg cn=true]


If I don't say something, Shiho will just agonize by herself.
[cpg]


Knowing this, I'm cutting to the chase with the poet.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho008"]
[OnName num="Shiho"]
......Then, may I have a word?"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

She asks and I decide to hold her for a while.
[cpg]


I think it would be counterproductive to do this, but Shiho says this makes it more bearable.
[cpg]


I obeyed her, thinking, "...... is it okay then?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho009"]
[OnName num="Shiho"]
It ...... smells good."
[cpg cn=true]


I didn't think so, but I was trying not to ruin the mood.
[cpg]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************




After spending some time like that, I parted from Shiho.
[cpg]




[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAzusa011"]
[OnName num="Azusa"]
She said, "Ah, sister!　Are you home now?"
[cpg cn=true]


I was also crammed by Azusa. I have a different reason for having to obey her: ......
[cpg]


But I can't neglect Azusa, who is also Azusa.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sAzusa012"]
[OnName num="Azusa"]
She looks ...... kind of tired, doesn't she?"
[cpg cn=true]


[OnName num="Rin_male"]
"That's not true,......, hey!"
[cpg cn=true]




;//========================================
;//●ＣＧエロ（主人公に手コキしながら自分のものもしごくヒロイン３。並んで座ってる感じ）ev_12
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン３
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


I sat down right there as Azusa was getting close to me.
[cpg]




[VOICE f="sAzusa013"]
[OnName num="Azusa"]
I could give her an invigorating massage."
[cpg cn=true]


This Azusa person is neither a boy nor a girl, and yet she's not ......
[cpg]


For all that, she seems to be into romance, or rather, she likes skinship.
[cpg]


But it's strange, I'm a guy,...... or is it even stranger if I'm a girl?
[cpg]


I'm getting kind of tired of thinking about it.
[cpg]



;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

I was exhausted and went back to the dormitory.
[cpg]


It was almost time for dinner. I had to hurry. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


Then night. As usual, Honoka and I were alone.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka052"]
[OnName num="Honoka"]
"Oh, you know,......, have you forgotten about that thing already?"
[cpg cn=true]


What are you talking about?　I asked her, and then I thought, "Oh, no, it's okay if you've forgotten about it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka053"]
[OnName num="Honoka"]
No, it's okay if you forgot. No, it's nothing.
[cpg cn=true]


You and Honoka had a lot going on, too. It's like I said earlier I'm forgetting that.
[cpg]


...... This is a bad situation...it's like dating 3 people.
[cpg]


It's not manly to have a relationship with everyone.
[cpg]


I'm going to be a woman in a year, but at least I want to be a man for now.
[cpg]


I thought about who is most important to me.
[cpg]



;//※ここでルート分岐
;//※ここまでの選択肢で、候補になっているヒロインから選択
;//※候補が一人だけの場合、自動的にそのヒロインに固定される

;//詩歩=1か梓=0  Cha2flg 
[if exp={getFlagValue("Cha2flg") == 1}]
[jump target=*selj_s]
[endif]

;//穂乃香の有無
[if exp={getFlagValue("Cha1flg") == 1}]
[jump target=*selj_k]
[endif]

;//梓のみ
[jump target="*select04_3"]

*selj_k
;//■選択肢
[switch]
[case "Honoka"]
	[swap]
	[jump target="*select04_2"]
[case "梓"]
	[swap]
	[jump target="*select04_3"]
[endswitch]


*selj_s
;//穂乃香の有無
[if exp={getFlagValue("Cha1flg") == 1}]
[jump target=*selj_a]
[endif]

;//詩歩のみ
[jump target="*select04_1"]


*selj_a
;//■選択肢
[switch]
[case "Shiho"]
	[swap]
	[jump target="*select04_1"]
[case "Honoka"]
	[swap]
	[jump target="*select04_2"]
[endswitch]






;//////////////////////////////////////
;//■選択肢
[switch]
[case "詩歩"]
	[swap]
	[jump target="*select04_1"]
[case "穂乃香"]
	[swap]
	[jump target="*select04_2"]
[case "Azusa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]



1, Shiho
2. Honoka
3, Azusa



;//==============================
;//１、詩歩
*select04_1
[jump storage="ep004.ks" target="*select04_1"]



;//==============================
;//３、梓

*select04_3
[jump storage="ep007.ks" target="*select04_3"]


;//==============================
;//２、穂乃香
*select04_2
[jump storage="ep010.ks" target="*select04_2"]
