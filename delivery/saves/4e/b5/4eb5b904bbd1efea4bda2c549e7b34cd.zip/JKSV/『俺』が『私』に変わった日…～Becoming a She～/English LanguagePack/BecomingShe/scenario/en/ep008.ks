

*start

;#################################################
*Ep008|梓じゃないと駄目
;#################################################



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


*select06_2|It has to be Azusa.

[SCENE id=8]



I knew I had been too much carried away by the momentum.
[cpg]


I was drunk with myself becoming a girl.
[cpg]


But it's not like that. It has to be Azusa. I strongly thought about that once again.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Days passed by. Summer vacation passed and it became autumn.
[cpg]


Azusa was lamenting the fact that she could not go swimming during the summer vacation.
[cpg]


I can go swimming, swimming pools, whatever. I can spend my time as a man outside of the school.
[cpg]


I enjoyed my last period as a man. This is the last time I can wear a regular T-shirt on my skin.
[cpg]


From now on, I will have to wear a bra.
[cpg]


I felt bad about it, but remembering Azusa's existence made me feel a little better about it.
[cpg]


Even if I become a woman, I can still be a girlfriend for Azusa.
[cpg]


For her, it is the same whether she is a man or a woman.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


And then autumn came. Gradually, my breasts swelled. I think it's a sign of sexual inversion.
[cpg]


I was embarrassed about my body. I began to wonder what sex reversal syndrome was all about.
[cpg]


I discussed it with Azusa, but she insisted, "We'll figure it out.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





Winter and spring came and went.
[cpg]


The days go by quickly.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


There are only a few days left until I become a woman.
[cpg]


At that time, Azusa said something outrageous. No, no, no. Did I do something outrageous?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[OnName num="Rin_male"]
Pregnant!　Since when?"
[cpg cn=true]


I unintentionally shouted out loud.
[cpg]


Because I didn't think Azusa could get pregnant normally.
[cpg]


Nevertheless, it was not a topic I could talk about out loud. People around me were looking at me.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa141"]
[OnName num="Azusa"]
I said, "Shush, you're being too loud. Your sister must be so happy.
[cpg cn=true]


I thought to myself, "That's not the point," but then I realized something.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa142"]
[OnName num="Azusa"]
I thought, "That means we can both be mothers. It's strange, but doesn't it make you happy?
[cpg cn=true]


It's kind of a puzzle, but between me, who is completely gender-swapped, and her, who is bisexual ......
[cpg]


We were able to have children with each other. It's really weird, though.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Azusa143"]
[OnName num="Azusa"]
'For our wedding, let's both wear wedding dresses, shall we? Sis."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





And more time passes.
[cpg]


Azusa was about to give birth to a swollen belly, and I was starting to have sexual inversion disorder.
[cpg]


We were both on absolute bed rest. We were both worried about each other, but we couldn't do anything about it.
[cpg]


My, or rather, my breasts swelled.
[cpg]


I don't know if it was a hormonal imbalance or what, but during that time the fear was so strong.
[cpg]


I couldn't help but wonder if we would be able to have a child and raise it properly at such a young age.
[cpg]


Besides, it had a huge impact on Azusa's life itself.
[cpg]


I have endless regrets. But I decided to think that it was for the best.
[cpg]


Then, when my body was stable enough to leave the hospital and Azusa had finished giving birth, I went to ......
[cpg]


I visited Azusa's hospital room.
[cpg]



[VOICE f="Azusa144"]
[OnName num="Azusa"]
She said, "Isn't she ...... adorable? It's our baby."
[cpg cn=true]


We had already decided on a name. We had already decided on a name for the baby.
[cpg]


We decided to name her "Kaoru" so that she could be either gender.
[cpg]


In fact, the child who was born was a girl. I wondered if she would become a boy later on.
[cpg]


What an idea! I don't want this child to suffer like I did.
[cpg]


If that's the case, don't give him a name that insures him, though.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************


After we had the baby, we fought over which house it would go to.
[cpg]


We couldn't say which one was the bride. We ended up going back and forth between our respective homes.
[cpg]


Our homes are not terribly far from each other. It was possible for us to see each other's families for now.
[cpg]


But when Kaoru gets a little older, we won't be able to do that.
[cpg]



;//========================================
;//●ＣＧエロ（正常位で処女喪失する主人公。痛がるばかりでほとんど感じない）ev_29
;//人物１：主人公（女）
;//服装１：裸
;//人物２：ヒロイン３
;//服装２：裸
;//場所　：主人公の家＿主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sAzusa015"]
[OnName num="Azusa"]
She said, "...... is beautiful. Really, it's a girl.
[cpg cn=true]


[VOICE f="sRin001"]
[OnName num="Rin_female"]
"Yes, she is a girl. Azusa is beautiful, too.
[cpg cn=true]


We stayed by her side as if we were making up for our time at the hospital.
[cpg]


We won't be able to do this kind of thing ...... when the kids get older.
[cpg]


So, thinking it was just for now, we kissed each other on the mouth.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************




[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
As we lay side by side, we talked about what we were going to do.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Azusa166"]
[OnName num="Azusa"]
'...... we want to have a wedding, don't we, sister?
[cpg cn=true]


Well, I wonder about that. There was talk of the two of us wearing wedding dresses together, wasn't there?
[cpg]


Azusa's constitution is also too rare a case to be publicized socially.
[cpg]


It's only supposed to be a man with a cross-dressing habit, so it's not a problem. ......
[cpg]


I wonder. I guess they might give me a blessing for doing it only with my family.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


So, we decided to make arrangements for the wedding.
[cpg]


It seems that wedding halls these days are accommodating minorities like us.
[cpg]


When we told them that we both wanted to wear wedding dresses, they agreed.
[cpg]


Hmmm. I wondered what would happen on the day of the wedding .......
[cpg]


But it was good to see Azusa looking so happy when she was choosing her dress.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

Then we decided to have a formal wedding.
[cpg]


It was a really small venue, but we both properly wore our wedding dresses.
[cpg]


It was strange that even at such a bizarre sight, my parents were crying: ......
[cpg]


No, maybe they are crying because they are sad? Let's not think too much about it.
[cpg]





;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[SE f="se027"]
;//【ＳＥ】『喧噪』


While this was happening,...... we became lovers and the third summer came.
[cpg]

[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
I walk the streets with my daughter, Kaoru.
[cpg]


People on the street sometimes look at us strangely. We are two women holding hands with a child.
[cpg]


Furthermore, ...... my belly is swollen.
[cpg]


;//私はあれからも行為を重ねて、ついに妊娠したのだった。
I have been pregnant since then and am carrying my second child with Azusa.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa187"]
[OnName num="Azusa"]
How are you feeling today, mother?
[cpg cn=true]


No problem. But I don't know if I should call you mother. ......
[cpg]


When I told her that, Azusa smiled.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa188"]
[OnName num="Azusa"]
'You can call me mother too. Can't we both be mothers?"
[cpg cn=true]


It's strange that when Azusa tells me that, I feel like it's not a no-no.
[cpg]


It is not that I am not anxious about what is going to happen to us.
[cpg]


It will be a purely male-less family. How will we work?
[cpg]


Although the male-dominated society has been flattened, there are still not many job opportunities.
[cpg]


But I think I can survive with Azusa.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa189"]
[OnName num="Azusa"]
I am glad I met you at that school. But I like our current relationship better.
[cpg cn=true]


She called me "you. I was so surprised.
[cpg]


;//（女）
[VOICE f="Rin067"]
[OnName num="Rin_female"]
"What, suddenly ......?"
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Azusa190"]
[OnName num="Azusa"]
I think I will probably fall in love with you more in the future. I can't lie to myself.
[cpg cn=true]


Oh, my God, I can't stand it. I feel like kissing. Even though I'm in the city.
[cpg]


I held back those feelings and rubbed my stomach.
[cpg]


I don't need to lie anymore.
[cpg]


[SCENE id=15]

;//ＥＮＤ：ヒロイン３ハッピーエンド
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

