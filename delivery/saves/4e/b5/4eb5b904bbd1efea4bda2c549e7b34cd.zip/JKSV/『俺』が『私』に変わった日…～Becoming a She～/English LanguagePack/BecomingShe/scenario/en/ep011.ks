
*start


;#################################################
*Ep011|The Truth about Honoka
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=10]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************


*select07_1|穂乃香の真実

[SCENE id=11]



[OnName num="Rin_male"]
"Listen to ....... Honoka, what I'm about to say is just speculation.
[cpg cn=true]



[OnName num="Rin_male"]
Honoka is afraid that you're going to forget about me,......?"
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="2/3" time=800]

Honoka fell silent. Then she turned her head down with a dark expression on her face.
[cpg]


I frequently say that you don't forget about me. Isn't that the flip side of forgetting?
[cpg]


[OnName num="Rin_male"]
'Maybe that's the nature of your refusal to kiss me, isn't it?
[cpg cn=true]


What is the trigger for that? I'm sure it's love with me.
[cpg]


I've been refusing to kiss her until now. Every time you have a crush on me or think you like me, your memory must be stolen.
[cpg]


I've never heard of such a constitution, but I've come to that conclusion when I connect everything.
[cpg]



[OnName num="Rin_male"]
Tell me. It's not that you don't want to kiss me, it's just that you can't."
[cpg cn=true]


Honoka was in tears again. I didn't want to see this face anymore, but ......
[cpg]


I want to know the truth. Even if we both have to stare at misfortune together, I won't be deceived by false happiness.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka183"]
[OnName num="Honoka"]
I don't know how ...... I would know. You've been watching me so closely."
[cpg cn=true]


I don't know. If it wasn't me, I might have seen through it.
[cpg]


I think Honoka was giving me hints.
[cpg]


I think Honoka really wanted me to notice.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHonoka016"]
[OnName num="Honoka"]
I'm... I have a peculiar condition of amnesia, and if I like someone ...... too much, I lose my memory."
[cpg cn=true]


She says that the amount of memories lost grows in proportion to the magnitude of the feelings.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHonoka017"]
[OnName num="Honoka"]
If you stay with me like this, you'll forget about ...... me someday.
[cpg cn=true]


The actuality that the actual person says so, there's no doubt about it.
[cpg]


I feel like I can't stand it. But I know what I'm going to say.
[cpg]



[OnName num="Rin_male"]
You can forget about it. You can put up with it. But please don't decide without telling me.
[cpg cn=true]


What is hard for Honoka is surely not to forget me. It's not about putting up with the act.
[cpg]


It's about deceiving me and going out with me. So, I'm sure it has become somewhat easier for her.
[cpg]


Honoka breaks down in tears. I think this was for the best. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

It took a while for Honoka to stop crying. I stroked her head during that time.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************

And when she stopped crying, it seemed that she had also given her answer.
[cpg]


She began to say something like, "Please don't pull away.
[cpg]



[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHonoka018"]
[OnName num="Honoka"]
She said, "I can't stand it just being with you. I felt so many times that I wanted to die like this.
[cpg cn=true]


I don't like that either. If Honoka kills herself, I'll go after her too.
[cpg]


I can't help saying that ....... I'm going to shut up and listen.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you are talking about.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka188"]
[OnName num="Honoka"]
I ...... won't hesitate anymore. I think you can trust me.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka189"]
[OnName num="Honoka"]
I'm confident that even if I forget about ...... your decision, I'll fall in love with you again.
[cpg cn=true]


Yeah. That's good. That's what I thought, too.
[cpg]


You're not the kind of friends who would be torn apart by amnesia or something like that. It's too late for that.
[cpg]


I hugged Honoka. I think Honoka was smiling.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


Morning comes. Night will come.
[cpg]


We didn't have to hold back anymore. We decided to spend our time as normal lovers.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************


Days passed and summer vacation came.
[cpg]


Small amnesia came again and again. The most obvious one was about a person.
[cpg]


I couldn't remember the names of her family members. Or to a classmate.
[cpg]


But that wasn't a big deal. It was more about ......
[cpg]


accumulation" as she calls it. The accumulation of love and the big amnesia that will come someday.
[cpg]


I guess I hadn't quite got it right yet.
[cpg]


I was shocked when I had my first big memory loss.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Honoka202"]
[OnName num="Honoka"]
I was like, "Well, ......, where am I?　Who are you?"
[cpg cn=true]


It was like something you would hear in a TV drama or anime.
[cpg]


I couldn't stand it any longer, but I held her in my arms because I loved her.
[cpg]


I thought she would reject me, but maybe Honoka remembered me deep in her heart.
[cpg]


She didn't shake me out of her embrace.
[cpg]



[OnName num="Rin_male"]
I cried, "Gusu, gusu, aaaaaaaaaaaaaaaaaaaaan!"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
I cried. What's with the sexual inversion disorder? Compared to Honoka, it was nothing at all.
[cpg]


Is it really this painful? Was Honoka enduring this kind of pain all this time?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************





I did not give up. Every time Honoka lost her memory, I took my time until I could explain everything to her and she fell in love with me again.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka203"]
[OnName num="Honoka"]
I thought, "After all, I ...... seem to remember you. Maybe I haven't forgotten everything."
[cpg cn=true]


It was a line that helped a little. But ......
[cpg]


That said, a second loss will probably come.
[cpg]


I might forget everything this time. Fighting that fear, I loved Honoka.
[cpg]


According to the doctor, there is no fear of becoming a cripple. Only the memory will be lost.
[cpg]


But that doesn't mean I can rest easy. And I still can't help but want her.
[cpg]


The next time I lost my memory, I thought about stopping our relationship. But I couldn't.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


The second major memory loss was in the fall. It came after the summer vacation.
[cpg]


Everyone at the school accepted me. After her peculiar constitution was revealed, everyone around me supported her.
[cpg]


Mutations were coming to my body, too. But it didn't seem like a big deal.
[cpg]


For example, my breasts got a little bigger. ......
[cpg]


I was thinking, "So what? I thought Honoka's memories were much more important.
[cpg]


It doesn't matter that I became a woman. It doesn't matter that I am no longer a man.
[cpg]


Compared to the pain of Honoka. Compared to the pain of losing Honoka.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

Time passes. Seasons pass. I am becoming more and more like a woman.
[cpg]


I sometimes felt a little lost in that, but ...... it doesn't matter.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************

The third amnesia came in the spring.
[cpg]


Each time, however, I noticed that the minor amnesia was disappearing.
[cpg]


Maybe the idiosyncrasies are slipping away with each amnesia. ......
[cpg]


What an overly hopeful observation. I have not confirmed it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


And then summer came again, and my sex reversal syndrome began.
[cpg]


I can't see anyone for a month, which is exactly what I'm going through right now.
[cpg]


It's called absolute bed rest. Of course I couldn't see Honoka either.
[cpg]


It somehow didn't feel real when I said I was going to become a woman. ...... The first and foremost concern, sexual inversion disorder, didn't matter anymore.
[cpg]


I want to find a way to stop her amnesia.
[cpg]


More days passed. The day of my discharge from the hospital came and we met face to face for the first time as girls.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka204"]
[OnName num="Honoka"]
She said, "...... You really turned into a girl, didn't you? It feels like a lie."
[cpg cn=true]


Would she love me like this?
[cpg]


I was not worried about the ....... I was more concerned about my amnesia.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka205"]
[OnName num="Honoka"]
I was more concerned about my amnesia. I don't care if I lose my memory. I'll be your lover for as many times as you want.
[cpg cn=true]


Honoka and I embraced silently for a while. No more words were needed.
[cpg]


We returned to the school again. I have to catch up on a month's worth of classes, but more importantly, I have to ......
[cpg]


I haven't seen Honoka for a month. I wanted to make love right now.
[cpg]


Then the holidays. At Honoka's request, she came to my house.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka206"]
[OnName num="Honoka"]
'Those breasts are real too. After all, it looks like a lie. ......
[cpg cn=true]


It's like a lie, huh? Thinking about it, we were swept up in a lie.
[cpg]


There was the lie that I dressed up as a woman and acted like I was a woman, but it was more than that.
[cpg]


Honoka said at first that she would never forget me. That was a lie at that stage.
[cpg]


If I had not been able to see through that lie, I am sure we would not have become so tightly bound.
[cpg]


And now those words are true. That's good.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************


I have already reported to the dormitory that I will be staying out overnight.
[cpg]


We are staying at home with other women. There was no problem.
[cpg]


After flirting for a while, we decided to go to sleep.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka218"]
[OnName num="Honoka"]
"Well, good night. ......
[cpg cn=true]


;//（女）
[VOICE f="Rin173"]
[OnName num="Rin_female"]
I said, "Yes, good night. Good night.
[cpg cn=true]


We slept in the small bed side by side. I was somewhat happy.
[cpg]


We are lovers. Even though we are both girls, we are still.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

The next day. We went to the school together.
[cpg]


Hand in hand, we were good friends. People around us didn't say anything anymore.
[cpg]


It had been like this since I was a boy.
[cpg]


But there was a lot of speculation about my going to the hospital and Honoka's amnesia.
[cpg]


Especially Honoka's memory loss can no longer be hidden. I couldn't even remember my friends' names.
[cpg]


Some people say heartless things. But we can get over it.
[cpg]


;//（女）
[VOICE f="Rin174"]
[OnName num="Rin_female"]
......Honoka. I'm sure we'll get along fine.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka219"]
[OnName num="Honoka"]
It's obvious, isn't it? I'm sure we'll be able to work it out.
[cpg cn=true]


Yes, that's right. I guess I shouldn't have been so formal about it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="female_teacher"]
Then, this problem ...... Kitami-san.
[cpg cn=true]


The first thing to do is to make sure that you have a good understanding of what you're doing.
[cpg]


I still think the amnesia is healing.
[cpg]


After losing your memory so many times, your brain may have developed a tolerance to it,......?
[cpg]


If that's possible, it seems to me that she might be developing a habit of doing things the other way around.
[cpg]


But so far her memory loss has settled down.
[cpg]


We seem to be getting along really well.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************


After class, we left the school and headed for the dormitory.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Honoka220"]
[OnName num="Honoka"]
I'd like to go back to my room.
[cpg cn=true]


Honoka seems to like my room.
[cpg]


For me, that room is a bit painful because it is steeped in memories of when I was a man,.......
[cpg]


But if Honoka likes it, I won't refuse it.
[cpg]


;//（女）
[VOICE f="Rin175"]
[OnName num="Rin_female"]
I'm good. Do you want to come back next holiday or something?"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
Honoka says, "I promise," and smiles. She's so cute.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


Several days and nights pass from there.
[cpg]


When Honoka and I kissed, her memory did not disappear.
[cpg]


Not even a small amnesia. Maybe the accumulation is happening, as Honoka says, ......
[cpg]


But I still think the constitution of the amnesia itself is fading.
[cpg]


I wouldn't say it was the power of love, but I somehow felt that way.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


Then the next holiday. We were on our way to my house.
[cpg]


I was indescribably happy on that holiday, when I could be with Honoka all day long.
[cpg]


We ate dinner together, talked, took baths, ...... though we haven't been able to do so yet.
[cpg]


I felt the distance between our hearts getting closer.
[cpg]








[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************
[WAIT time=100]


At night, we slept together on a small futon.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka236"]
[OnName num="Honoka"]
I said, "It's ...... so small, isn't it? I'm sorry.
[cpg cn=true]


;//（女）
[VOICE f="Rin185"]
[OnName num="Rin_female"]
I'm sorry. I can feel Honoka close to me.
[cpg cn=true]


It's not so much that I can feel her, it's that she's actually close to me. ......
[cpg]


Even as I did so, I could hear Honoka's heartbeat.
[cpg]


The two are facing each other's ceilings,......, so I kind of suggested it.
[cpg]


;//（女）
[VOICE f="Rin186"]
[OnName num="Rin_female"]
Hey, why don't we sleep across from each other?"
[cpg cn=true]


I turned my face toward Honoka. Then Honoka also turned her head this way and looked embarrassed.
[cpg]


But it's like being in love, isn't it? I've been wanting to do this for a long time.
[cpg]


I turned toward Honoka before waiting for her to respond.
[cpg]


Then Honoka also turned to me and went back to sleep: ......
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka237"]
[OnName num="Honoka"]
You're close to ......." Haha."
[cpg cn=true]


I have the urge to hug her like this.
[cpg]


But if I hugged you, I wouldn't be able to sleep forever.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


From there we talked facing each other for a while.
[cpg]


Mainly about the future. It was a dark topic, but strangely we didn't talk about it in a gloomy way.
[cpg]


I feel that we can change any dark future together.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHonoka019"]
[OnName num="Honoka"]
I think we're going to hit it off," he said. It's kind of weird.
[cpg cn=true]


It was that one comment that triggered the conversation. I was somewhat aware of it when I heard it.
[cpg]


;//（女）
[VOICE f="sRin003"]
[OnName num="Rin_female"]
Is that an invitation?
[cpg cn=true]


I tried to make it sound like Honoka was asking me out.
[cpg]


Honoka's face was red. Even her ears were red. She must be really excited.
[cpg]


I think if I give her one more push, I can make her do it again.
[cpg]


I'm already sleepy and I don't want to go that far either. ......
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Honoka239"]
[OnName num="Honoka"]
...... inviting."
[cpg cn=true]


This one word from Honoka blew away my sleepiness.
[cpg]


The first thing I did was to get a nosebleed. She was just too cute.
[cpg]


As it was, I kissed her.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





That day, I couldn't go to sleep right away. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

;//（女）
[VOICE f="Rin197"]
[OnName num="Rin_female"]
"You're still sleepy ......, aren't you? I guess I'm still tired from yesterday."
[cpg cn=true]


Honoka's face turns red when she remembers what happened yesterday.
[cpg]


I thought she would have forgotten about it, but she didn't.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka249"]
[OnName num="Honoka"]
I ...... feel like my memory is continuing lately.
[cpg cn=true]


I knew it. She can notice it, too.
[cpg]


Maybe so, he can't notice that he's lost his memory, but he can ......
[cpg]


He can notice that his memory is continuing.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka250"]
[OnName num="Honoka"]
I wonder if, for some reason, the amnesia is healing."
[cpg cn=true]


Honoka continues, "I did that yesterday, too,.......
[cpg]


If she once was, she could have forgotten about yesterday itself.
[cpg]


Is it the power of love after all? Or has she developed a tolerance?
[cpg]


We don't know the truth. Even the doctors can't know everything.
[cpg]


;//（女）
[VOICE f="Rin198"]
[OnName num="Rin_female"]
I don't think the doctors will know the whole story. It's okay if you continue to remember, and it's okay if you lose your memory.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka251"]
[OnName num="Honoka"]
"......, that's right."
[cpg cn=true]


Even if we lose our memories, even if we become girls, no matter what happens, we will be attracted to each other again. We will be guided.
[cpg]


That's the way it's destined to be. It can't be helped.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

The two of us headed to the school. We've gotten used to holding hands on our way to school.
[cpg]


We don't hear the rumors around us anymore. Even if we do, we don't care.
[cpg]


We are invincible. The problems we had with each other are no longer an obstacle.
[cpg]


In fact, I think it has strengthened our bond.
[cpg]


;//（女）
[VOICE f="Rin199"]
[OnName num="Rin_female"]
Love burns better when there are obstacles, doesn't it?
[cpg cn=true]


I suddenly thought of something and said to Honoka.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka252"]
[OnName num="Honoka"]
I think that even without the ...... obstacle, you and I would still have been connected.
[cpg cn=true]


I see. That's a reversal. I hadn't thought that far ahead.
[cpg]


So you were with us no matter what in the end.
[cpg]


I was somewhat relieved and yawned.
[cpg]


Like a girl, I held my yawning mouth. The gesture also comes out naturally.
[cpg]


I think I can live naturally as a girl from ...... now on.
[cpg]


Honoka is next to me. I feel like I can go anywhere.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka253"]
[OnName num="Honoka"]
...... hey,rin.
[cpg cn=true]


What?　I reply. Honoka looked serious.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka254"]
[OnName num="Honoka"]
I won't forget you. Even if I forget, I won't forget."
[cpg cn=true]


You're going to say it again, aren't you? But I wanted to be told again and again.
[cpg]


[SCENE id=17]

;//ＥＮＤ：ヒロイン２ハッピーエンド
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

