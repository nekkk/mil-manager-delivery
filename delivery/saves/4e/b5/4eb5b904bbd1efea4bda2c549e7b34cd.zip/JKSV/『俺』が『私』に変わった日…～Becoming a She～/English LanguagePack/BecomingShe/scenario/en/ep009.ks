

*start


;#################################################
*Ep009|I want to be swept away
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


*select06_1|流されてしまいたい

[SCENE id=9]

......No, I don't need to think about it. I don't need to think about it.
[cpg]


I think I can just let myself be swept away by Azusa's words.
[cpg]


I don't know if "being swept away" is the right word.
[cpg]


If being as I am is called being swept away, then I want to be swept away.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka063"]
[OnName num="Honoka"]
I was like, "......, what's wrong, shut up."
[cpg cn=true]


I must have looked serious, or Honoka was worried about me.
[cpg]


It's all right. Nothing to worry about.
[cpg]


It's just that I'm going to have the same personality as Azusa. It will be all right.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


And so, I was intoxicated with myself becoming a girl.
[cpg]


I wanted to be a girl like Azusa, a girl who is honest with herself.
[cpg]


Then summer passed.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（朝）******************************************************


By the end of the summer vacation, my heart was already swelling up.
[cpg]


That's funny, it was supposed to be a year later. ......?　I thought, but I had no idea what it was.
[cpg]


It was like I was admitting that I was going to be a girl.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夕方）******************************************************


And by the time fall came, my breasts had swollen considerably and I was no longer a pure male.
[cpg]


I no longer felt bad about Azusa putting clothes on me.
[cpg]


'You've changed, sister. ...... Yes, I'm changing.
[cpg]

I'm going to change in the future. I mean, it's time to start now.
[cpg]


I'm not going to be me, I'm going to be me. That day is approaching.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


Autumn has passed and winter......
[cpg]


My sexual reversal syndrome has started. It's only been six months.
[cpg]


According to the doctor, my body is accepting the fact that I am becoming a woman.
[cpg]


I felt as if it was someone else's problem. I wasn't too surprised at the faster-than-expected progression of my sexual inversion disorder.
[cpg]


And I became a woman completely.
[cpg]


I hadn't seen Azusa for about half a month. I couldn't wait to see her, so I invited her to my house on the first day I left the hospital.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************



[SE f="se007"]
;//【ＳＥ】『ベッドに押し倒す』





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa192"]
[OnName num="Azusa"]
She was so hungry," I said. I like your sister like that, too.
[cpg cn=true]


No matter what Azusa said to me, I could not restrain myself.
[cpg]


I had accepted the situation so much that I wanted to be a girl all the time. ......
[cpg]


Azusa also accepted me for wanting to flirt with her.
[cpg]


At least, that's what I thought at the time.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


Then life at the school began again.
[cpg]


Shiho graduated and was in the same class as Honoka.
[cpg]





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka064"]
[OnName num="Honoka"]
She is dating ...... Azusa-san, right?
[cpg cn=true]


Honoka confirms something that is now too late.
[cpg]


I asked him back, not knowing what his intention was in saying that.
[cpg]


;//（女）
[VOICE f="Rin078"]
[OnName num="Rin_female"]
Yeah, I know, but ...... what does it matter?'
[cpg cn=true]


Honoka falls silent. What the hell, I'm curious.
[cpg]


I pursue. I ask her why she is asking me such a thing.
[cpg]


Then Honoka replied, but it was unexpected.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka065"]
[OnName num="Honoka"]
'Azusa-san, you've been looking tired lately. I wondered if something was wrong.
[cpg cn=true]


What is it? Is that what this is about? Of course Azusa is tired.
[cpg]


I'm coming on to her every day. Honoka doesn't need to know about it. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


And today, I caught Azusa again and tried to flirt with her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sAzusa016"]
[OnName num="Azusa"]
You're going to ...... find out."
[cpg cn=true]


It's rare to see Azusa on the run. I guess it's proof that I've changed.
[cpg]


But I don't really care if I get to see a new side of Azusa or not.
[cpg]


;//＠
;//性欲を満たしてくれる人が欲しい。それが梓だという話。
I want someone who can satisfy my sexual desire. That's the story of Azusa.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa204"]
[OnName num="Azusa"]
"Well, sister,......, why don't you refrain from this kind of thing a little more?"
[cpg cn=true]


;//（女）
[VOICE f="Rin079"]
[OnName num="Rin_female"]
What ......?"
[cpg cn=true]


I couldn't believe my ears. I never thought I would hear such a thing from Azusa.
[cpg]





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





I felt as if I had been ...... rejected in a roundabout way.
[cpg]


She doesn't accept all of me. I'm sure Azusa is fond of me.
[cpg]


Still, I was frustrated.
[cpg]


Who would fill me up? Would Shiho-san, who had always been in love with me, be able to help me?
[cpg]


But she has graduated. At this point, I have nothing to rely on her for.
[cpg]


Of course, I have no intention of relying on Honoka.
[cpg]


After thinking about ...... I came to one conclusion.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



I have been waiting for a holiday for a long time.
[cpg]


Once I decided what I was going to do, I suddenly couldn't wait for the holidays.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


And then the holiday. It was nighttime, and I was standing in the city.
[cpg]


I didn't care about the curfew anymore. If I was going to be expelled, it didn't matter.
[cpg]




[VOICE f="Rin080"]
[OnName num="Rin_female"]
Excuse me. Excuse me.
[cpg cn=true]


[OnName num="man"]
"...... what?"
[cpg cn=true]


I've always wanted to date a guy.
[cpg]


Today was the first step. I approached a stranger.
[cpg]


;//（女）
[VOICE f="sRin002"]
[OnName num="Rin_female"]
I'm lost. Can you show me the way?"
[cpg cn=true]


[OnName num="man"]
I said, "No problem, but where are you going?
[cpg cn=true]


I walked along with the man, making up a random direction I wanted to go.
[cpg]


;//（女）
[VOICE f="Rin100"]
[OnName num="Rin_female"]
'Well, come on then, Uncle .......'
[cpg cn=true]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



I felt like a woman.
[cpg]


I don't mean that I feel like a woman, but I really have become one. ......
[cpg]


Still, I never thought I would be this much of a girl.
[cpg]


Maybe if I had been dating Shiho or Honoka, this would not have happened.
[cpg]


I have to thank Azusa. To Azusa for making me this way.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』

While I was repeating these things, the teacher scolded me terribly.
[cpg]


I heard that the punishment would be decided later. I'm not really concerned if I don't get expelled from school or not.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa205"]
[OnName num="Azusa"]
Is it true that you snuck out of the dormitory, ...... sister?
[cpg cn=true]


But Azusa was worried about me.
[cpg]


I had no reason to lie, so I told the truth as it was.
[cpg]




[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Azusa206"]
[OnName num="Azusa"]
I was worried about her. I see."
[cpg cn=true]


Azusa looked a little gloomy. It's not like that, it doesn't suit me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』





[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Honoka066"]
[OnName num="Honoka"]
What did you do to ...... Azusa-san?　She was crying.
[cpg cn=true]


I didn't do anything. I just told her the truth.
[cpg]


I think I should tell Honoka everything. I'm afraid she's going to say a lot of things to me after this, and it's going to be a hassle.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka067"]
[OnName num="Honoka"]
I think you should take better care of her if she's your girlfriend. I don't know if this is meddling.
[cpg cn=true]


I shook my head. I still think Azusa is important.
[cpg]


But I am sure that it is not Azusa that fulfills me.
[cpg]


That is already an undeniable fact, so I felt I had to tell Azusa that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

While I was returning to the dormitory after the class. Azusa caught me again.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Azusa207"]
[OnName num="Azusa"]
She said, "I need to talk to you for a minute. May I?"
[cpg cn=true]


She looked serious. I couldn't refuse her, so I complied.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa208"]
[OnName num="Azusa"]
What should we do now?　I'm useless, aren't I?
[cpg cn=true]


Azusa is on the verge of tears.
[cpg]


It is not as if she is being dumped by her sister. People gather around her.
[cpg]


When I asked her not to cry, she looked up.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sAzusa017"]
[OnName num="Azusa"]
I still love you.
[cpg cn=true]


There's nothing wrong with that. I don't care if we eventually get married or anything.
[cpg]


But even after marriage I may not be satisfied.
[cpg]


If I tell ...... everything as it is, Azusa would probably kill me.
[cpg]


;//（女）
[VOICE f="Rin122"]
[OnName num="Rin_female"]
I understand. I know how Azusa feels, so don't worry."
[cpg cn=true]


I lied to Azusa for a bit.
[cpg]


Because I'm not going to go home on the next holiday again.
[cpg]


I might be expelled from school next time. But I still want to.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


And the next holiday. I met up with him in town.
[cpg]


I don't just ask him for directions anymore. He knew what I wanted.
[cpg]


[OnName num="man"]
"Well, let's go. What do you want to eat?"
[cpg cn=true]


I unabashedly cling to his arm.
[cpg]


......I'm sorry, Azusa.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


While all this was going on, my expulsion from school became official.
[cpg]


The teachers seemed to know what I was doing.
[cpg]


I don't think Azusa told the teachers directly. I wonder if anyone heard me talking to Azusa.
[cpg]


;//（女）
[VOICE f="Rin161"]
[OnName num="Rin_female"]
Thank you for your help at ......."
[cpg cn=true]


The teacher didn't return my parting words properly.
[cpg]


I think it was natural. But I still couldn't stop myself.
[cpg]





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************





;//（女）
[VOICE f="Rin162"]
[OnName num="Rin_female"]
"......I guess this school won't be coming back."
[cpg cn=true]


;//＠
;//私は援交以外の全てが馬鹿らしくなって、次にどこかの学園に転入する気も無くなっていた。
I felt ridiculous about everything except dating guys, and I had no intention of transferring to some other school next time.
[cpg]


If I had to say something, I was a little concerned about ...... Azusa.
[cpg]


At that time, there was someone coming out of the academy.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Azusa210"]
[OnName num="Azusa"]
'Wait, sister!
[cpg cn=true]


Azusa. I guess she is still worried about me.
[cpg]


She is still my girlfriend. She might dump me here.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa211"]
[OnName num="Azusa"]
"I'll follow your sister wherever she goes ...... so please let me know when you decide where you're going to transfer to."
[cpg cn=true]


But it was rather the opposite. Azusa is still thinking about me.
[cpg]


It's kind of painful. I want to respond to her love, but I can't.
[cpg]


But I can't. Azusa can't satisfy me.
[cpg]


;//（女）
[VOICE f="Rin163"]
[OnName num="Rin_female"]
I'm sure we're better off without her.
[cpg cn=true]


Azusa shakes her head. And then she says, "It's not good.
[cpg]


Maybe Azusa would say so. Either way, though, the conclusion I come to is the same.
[cpg]


It might be a tragic love in a way. The true nature as a girl that Azusa awakened in me ended up splitting us apart.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Azusa212"]
[OnName num="Azusa"]
;//「……こんなことなら私、本物の男の子に生まれたかった」
......I wish I had been born a real boy if it was like this.
[cpg cn=true]


Azusa says so as if muttering. I can't say anything more.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


I left without telling Azusa that I would no longer attend any school.
[cpg]


Maybe I wanted to escape from Azusa. I might think that I might be able to have a decent love life.
[cpg]


A decent relationship does not suit me right now. This kind of ending suits me. ......
[cpg]


[OnName num="man"]
"Oh, you're here. Let's go then. ......"
[cpg cn=true]


[SCENE id=16]

;//ＥＮＤ：ヒロイン３バッドエンド
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="bend.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=2100]


[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[jump storage="epend.ks" target="*back_title"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

