
*start



;#################################################
*Ep002|A secret I can't tell you.
;#################################################

[SCENE id=2]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


[SE f="se000"]
;//【ＳＥ】『歩く』

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
The next morning. I met Shiho on the way from the dorm to the school.
[cpg]



[OnName num="Rin_male"]
She said, "...... Good morning."
[cpg cn=true]

;//asd
It was awkward. I felt awkward, and at the same time, I learned for the first time that Shiho is also a dorm student.
[cpg]


There are so many dorm residents that I don't immediately recognize her. I couldn't recognize all of their faces.
[cpg]


;//[t_move pos=C 下礼]

[VOICE f="Shiho068"]
[OnName num="Shiho"]
Good morning. Rinsan.
[cpg cn=true]


The other side bowed to me. I bowed, too. He is polite to no end.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


When I went to the classroom, Honoka was not there. I'm a little worried.
[cpg]


[OnName num="female_student"]
I went to the classroom, but Honoka was not there. I wonder if she caught a cold.
[cpg cn=true]


[OnName num="Rin_male"]
I don't know her very well.
[cpg cn=true]


I don't know much about it, that's a fact. I don't know if it's okay to say that she went to the hospital.
[cpg]


[OnName num="female_student"]
I don't know much about it.　You were roommates, weren't you?
[cpg cn=true]


[OnName num="Rin_male"]
"Yeah, but I just left a note at ...... saying we were going to the hospital, but I don't know much more than that."
[cpg cn=true]


[OnName num="female_student"]
Hospital?　Hmmm... ......."
[cpg cn=true]


Ms. Takanashi seems to be convinced of something. So what is that conviction?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

After all, Honoka didn't even show up for class that day in the middle of the day. ......
[cpg]


I've missed a whole day of school. That's a bit important.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa008"]
[OnName num="Azusa"]
I'm so glad you're here.　You smell good today too!"
[cpg cn=true]


Azusa hugs me. What do you mean by smelling good? I'm not wearing perfume or anything.
[cpg]


I'm not wearing perfume or anything. Azusa is the one who smells good. ...... No, no, no, I'm a real pervert when I say this.
[cpg]


[OnName num="Rin_male"]
I'm close, Azusa. I told you before."
[cpg cn=true]


My tone becomes a bit masculine. When I'm with Azusa, I feel a bit relaxed.
[cpg]


I have to be careful ......, I thought, and we parted after walking together to the halfway point again today.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夕方）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka016"]
[OnName num="Honoka"]
......I'm home.
[cpg cn=true]


Evening. Honoka finally returns home.
[cpg]



[OnName num="Rin_male"]
I'm back. What's wrong ......?"
[cpg cn=true]


I want to say, "What's wrong? It wasn't because she had taken the day off.
[cpg]


I was struck by the fact that she looked kind of like a ghost.
[cpg]


I have never seen Honoka's face like this. I've never seen Honoka look like this.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインの胸やまんこに触れる主人公。キスしながら。横並びにベッドに座り込む）ev_07
;//人物１：主人公（男）
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//場所　：学生寮室内
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Honoka017"]
[OnName num="Honoka"]
I wonder how I can make ...... memories."
[cpg cn=true]


She suddenly comes up to me and says something like this.
[cpg]


I was not the kind of girl who would say such sentimental things.
[cpg]


How to make memories?　I don't know anything about that either.
[cpg]


But I wasn't in the mood to say anything, and I wasn't in the mood to say, "I don't know.
[cpg]


[OnName num="Rin_male"]
I don't have any friends.
[cpg cn=true]


I don't have any friends. Honoka replied, "I don't have any friends.
[cpg]


I have never seen Honoka in such a negative mood before.
[cpg]


I wonder if I'm not a friend. I'm starting to feel like that.
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Honoka018"]
[OnName num="Honoka"]
"...... Hey, rin, let's kiss."
[cpg cn=true]


[OnName num="Rin_male"]
 what's wrong with you. Suddenly."
[cpg cn=true]


Isn't Honoka kind of desperate?
[cpg]


But there is no doubt that he is asking me out. To refuse at this point would hurt Honoka.
[cpg]


I don't know what to do. ......
[cpg]




;//■選択肢
[switch]
[case "Accept"]
	[swap]
	[jump target="*select01_1"]
[case "Refuse"]
	[swap]
	[jump target="*select01_2"]
[endswitch]




1, Accept
2, Refuse



;//==============================
;//１、受け入れる
*select01_1|話せない秘密

;//ルート分岐時、穂乃香が候補になる
[stflag Cha1flg = 1]
[system sysflg_01=true]

Are you okay with me?　I asked her. Honoka then replied.
[cpg]




[VOICE f="Honoka019"]
[OnName num="Honoka"]
Please, give me a memory. Please, give me a memory.
[cpg cn=true]



[jump target="*select01_3"]


;//==============================
;//２、断る
*select01_2|話せない秘密


[system sysflg_01=false]


I shook my head. I'm not going to do this lightly.
[cpg]


[OnName num="Rin_male"]
What?
[cpg cn=true]


But he forcibly took my lips.
[cpg]

;//==============================

*select01_3|話せない秘密


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夕方）******************************************************

;//移植のためシーンをカットしています

Our lips part. We look at each other.
[cpg]



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHonoka001"]
[OnName num="Honoka"]
"......rin. I'm sorry."
[cpg cn=true]


Honoka apologizes for some reason. I wanted to do this.
[cpg]


I remained silent, not understanding everything.
[cpg]


Even though we were further apart than before, I felt more embarrassed now.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//移植のためシーンをカットしています

As I repeated the process, I realized that the sun was setting.
[cpg]




[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Honoka043"]
[OnName num="Honoka"]
'...... It's getting late, isn't it? Sorry."
[cpg cn=true]


I replied that it was fine.
[cpg]


The first time I saw her, she looked like a ghost again.
[cpg]


That's funny. I thought I could have helped her. I guess I can't help you.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Honoka044"]
[OnName num="Honoka"]
You can forget about today.
[cpg cn=true]


I couldn't believe my ears.what to do with the money, but I'm sure I'll be able to find a way.
[cpg]


I was surprised to hear Honoka say the exact opposite.
[cpg]


[OnName num="Rin_male"]
She said, "What, ......?　Aren't you going to make it a memory?"
[cpg cn=true]


Honoka laughed at my words without effort. I don't like it. I don't want to see her face like this.
[cpg]


I'd like to see Honoka smile more honestly.
[cpg]


But I can't come up with that kind of stinky dialogue. I'm a wimp.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Honoka045"]
[OnName num="Honoka"]
I'll forget about it. Let's pretend it never happened.
[cpg cn=true]


What the hell is that ......?
[cpg]


 what's going to happen to Honoka.　What happened at the hospital?
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

;//ＢＫ


......That's what happened, the next morning.
[cpg]



;//========================================
;//●ＣＧエロ（素股。主人公寝ている感じで、ヒロインが上。ヒロインが主導権を握る）ev_08
;//人物１：主人公（男）
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//場所　：学生寮室内
;//時間　：夕方
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="Rin_male"]
...... what are you doing, Honoka?
[cpg cn=true]




[VOICE f="sHonoka002"]
[OnName num="Honoka"]
What?　Oh, no, no, I just thought you had a cute sleeping face.
[cpg cn=true]


[OnName num="Rin_male"]
"......"
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you're doing. The gap from yesterday is tremendous.
[cpg]


The next day at lunchtime, the first thing that comes to mind is that the two of them are going to have a good time.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

The next day at lunchtime. Honoka is chatting and laughing with another girl.
[cpg]


The next day at lunchtime, Honoka is chatting with another girl without hesitation.
[cpg]


I'm even more curious ...... what it really was.
[cpg]



[OnName num="Rin_male"]
The first thing you need to do is to get a good idea of what you want to do. You know,......?"
[cpg cn=true]


When I called out to her, Honoka looked a little serious.
[cpg]




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka046"]
[OnName num="Honoka"]
The first thing you need to do is to make sure that you have a good understanding of what you're doing. Yes, I know.
[cpg cn=true]


What do you mean you understand? I don't know anything.
[cpg]


I thought I did, but apparently it was a completely different story.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka047"]
[OnName num="Honoka"]
"Next class is swimming. ...... what should we do?"
[cpg cn=true]


Oh, oh, I forgot. I forgot. I mean, I don't have a swimsuit.
[cpg]


I know the teachers will understand, but it's not good if I don't. I'm sure they'll pay attention to me.
[cpg]


I'm sure the teachers will understand, but I'll be the center of attention from my classmates.
[cpg]


[OnName num="female_student"]
What's wrong?　Can't you swim or something?
[cpg cn=true]



[OnName num="Rin_male"]
Haha, something like that ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


Now, I decided to take a break from swimming lessons. I had to take a break.
[cpg]


It might be possible to deceive it by wearing a slightly special swimsuit, but of course there are swimsuits designated by the school.
[cpg]


I couldn't swim in it. It was impossible no matter how I thought about it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』


......This is the story of what happened after I took a break from swimming lessons.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Azusa009"]
[OnName num="Azusa"]
I'm sure you've heard that I missed swimming lessons, sister.
[cpg cn=true]


Azusa spoke to me. Maybe she saw the pool from the window.
[cpg]


Either way, it would be bad if Azusa found out. I tried to make things right.
[cpg]



[OnName num="Rin_male"]
I tried to make things up. "Well, well, ...... there's been a bit of a mix-up."
[cpg cn=true]


Azusa says, "I understand. I don't know if she understands. I don't think so.
[cpg]


Because you don't even know who I am. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa010"]
[OnName num="Azusa"]
I tend to take a lot of time off from swimming.
[cpg cn=true]


I just reply, "Heh. I didn't pursue the reason deeply.
[cpg]


I didn't want to ask her why she takes a day off, because I was afraid she would ask me too.
[cpg]


Then, Azusa asks, "Are you menstruating? Azusa asked me, "Are you menstruating?
[cpg]



[OnName num="Rin_male"]
Yes, that's right!　I'm having my period, so I had to take the day off.
[cpg cn=true]


I jumped at the reason and shouted louder than I should have.
[cpg]


Azusa looked at me suspiciously. She gives me a icy stare.
[cpg]


What the hell, you're not going to find out about this, are you?　That's too intuitive.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa011"]
[OnName num="Azusa"]
When was your last menstruation, sister?
[cpg cn=true]


Huh?　Oh no, it was that ......
[cpg]


I couldn't answer right away. 25 days ago?　30 days ago?
[cpg]


No, to begin with, everyone's menstruation cycle is different, right?　While I was thinking about it, Azusa asked me the next question.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Azusa012"]
[OnName num="Azusa"]
Is your period heavy or light?　Or is it light?"
[cpg cn=true]


I can't answer that immediately either. They are heavy!　and I can't even explain what kind of pain it is.
[cpg]


I mean, they totally suspect me, don't they?
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Azusa013"]
[OnName num="Azusa"]
"Don't worry about ....... I'm the one who can't get into the pool all year round. I lie to everyone."
[cpg cn=true]


Huh?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


I was taken straight to the locker room.
[cpg]



[VOICE f="Azusa014"]
[OnName num="Azusa"]
"You're really a man, aren't you, sister?"
[cpg cn=true]


I couldn't fool them anymore. I was prepared for that.
[cpg]


Besides, Azusa is hiding something from me. She also said she was lying to everyone.
[cpg]


[OnName num="Rin_male"]
How did you know?
[cpg cn=true]


[VOICE f="sAzusa001"]
[OnName num="Azusa"]
I understand. I'm just like her.
[cpg cn=true]


[OnName num="Rin_male"]
What?
[cpg cn=true]


[VOICE f="sAzusa002"]
[OnName num="Azusa"]
I call it partial degeneration,...... and I'm neither a man nor a woman.
[cpg cn=true]



;//========================================
;//●ＣＧエロ（主人公にパイズリフェラするヒロイン３。ヒロインが座り込んでるような形）ev_09
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン３
;//服装２：制服
;//場所　：女子トイレ
;//時間　：昼
;//========================================


[FADEOUTBGM]

[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sAzusa003"]
[OnName num="Azusa"]
So I envy real men like your sister.
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you are looking for.
[cpg]


[OnName num="Rin_male"]
She's so close.
[cpg cn=true]




[VOICE f="sAzusa004"]
[OnName num="Azusa"]
I don't mean ...... deeply.
[cpg cn=true]


By neither male nor female, do you mean bisexual or something like that?
[cpg]


In any case, I learned a great secret.
[cpg]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


And after school, in the evening.
[cpg]


Azusa ran toward me again.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAzusa005"]
[OnName num="Azusa"]
She said, "Can I hold your hand?　Sis!"
[cpg cn=true]


I couldn't refuse. I let Azusa know my secret.
[cpg]


She hasn't threatened me yet, but if she does, there is no way out.
[cpg]


On the other hand, there might be a way for me to reveal Azusa's secret to her. ......
[cpg]


I didn't feel like I could beat Azusa in that game. I've already been swallowed up by her tension.
[cpg]





;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shiho069"]
[OnName num="Shiho"]
Oh my, where are you two going?"
[cpg cn=true]


I was seen being pulled by the arm by someone I didn't really want to be found by.
[cpg]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Azusa031"]
[OnName num="Azusa"]
It's nothing, nothing at all."
[cpg cn=true]


He was so high-spirited. I always feel like this when I'm with Azusa.
[cpg]


I was pulled along by someone who said, "Let's go. I can't shake her off.
[cpg]


I don't know what Azusa will say if I do. ......
[cpg]


What should I do? Should I ask Shiho for help?
[cpg]



;//■選択肢
[switch]
[case "I'll ask Shiho for help."]
	[swap]
	[jump target="*select02_1"]
[case "Let Azusa do what she wants to do"]
	[swap]
	[jump target="*select02_2"]
[endswitch]



1. Ask Shiho for help
2. Let Azusa do as she wants to do



;//==============================
;//１、詩歩に助けを求める
*select02_1


;//ルート分岐時、詩歩が候補になる
[stflag Cha2flg = 1]
[system sysflg_2t3f=true]



[OnName num="Rin_male"]
Please help me, Shiho-san!
[cpg cn=true]


Shiho is bewildered by my asking for help. Yes, that's the kind of reaction I get.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Azusa032"]
[OnName num="Azusa"]
I ask her, "Are you sure you want to do that? I'm going to tell Shiho-san, aren't I?
[cpg cn=true]


No, it doesn't really bother me. I've known Shiho-san for a long time.
[cpg]


 However, it would be dangerous if someone else found out... Should I just obey here?
[cpg]


[jump target="*select02_3"]
;//==============================
;//２、梓のしたいようにさせる
*select02_2


;//ルート分岐時、梓が候補になる
[stflag Cha3flg = 1]
[system sysflg_2t3f=false]


 After thinking about it, I decided to let Azusa do what she wanted.
[cpg]


The actual fact is that the actual truth will be revealed if you go against Azusa and spoil her good mood.
[cpg]


She was taken by the hand as it was. ......
[cpg]



;//==============================
*select02_3
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

In an empty classroom where she was taken, Azusa says this.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sAzusa006"]
[OnName num="Azusa"]
Kneel down like you're kneeling to me.
[cpg cn=true]


[OnName num="Rin_male"]
Why did you do that?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sAzusa007"]
[OnName num="Azusa"]
Can't you do it?　Have you forgotten that I know your secret?
[cpg cn=true]


When she said that, I couldn't say it back.
[cpg]


;//========================================
;//●ＣＧエロ（フェラチオさせられる主人公。今度は主人公がかがむ形）ev_10
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン３
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================



;**【ＣＧ】 ev_10_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sAzusa008"]
[OnName num="Azusa"]
She's so cute."
[cpg cn=true]


I was squatting in front of her, feeling a little uncomfortable.
[cpg]




[VOICE f="sAzusa009"]
[OnName num="Azusa"]
'I can't believe you're a boy, your hair is so beautiful. ......
[cpg cn=true]


Saying so, Azusa patted my head.
[cpg]


Azusa's hands feel like a girl's hands. ...... I wonder if they really have no gender.
[cpg]




[VOICE f="sAzusa010"]
[OnName num="Azusa"]
As long as you know my secret, your sister is at my beck and call ...... phew."
[cpg cn=true]


She looked happy and said something like that.
[cpg]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



After all that happened, I was finally starting to think something was wrong.
[cpg]


Azusa says she's a hermaphrodite, Shiho-san has a romantic disposition, and Honoka seems to be hiding something,.......
[cpg]


There are too many peculiarities or people who are not normal.
[cpg]


There is something wrong with this school. I was on my way home with this thought in my mind.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka048"]
[OnName num="Honoka"]
What's wrong with you?　Your expression is so dark.
[cpg cn=true]


That was Honoka a while ago, wasn't it? I reply appropriately, thinking.
[cpg]



[OnName num="Rin_male"]
I thought, "Oh, you know, ...... are in a lot of trouble.
[cpg cn=true]


Who is the one in trouble? Of course it is hard for me, but even Shiho-san and Azusa-san must have hard times.
[cpg]


I'm sure Honoka does, too. ......
[cpg]


I feel like I'm going deeper and deeper as I think about it. Let's go to bed today.
[cpg]



[jump storage="ep003.ks" target="*start"]

