
*start


;#################################################
*Ep001|Turbulent School Life
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』


[OnName num="female_student"]
"Good day to you."
[cpg cn=true]


[OnName num="female_student"]
"Yes, how do you do?"
[cpg cn=true]


They say "Gogawara yo. These people. I commute to school thinking, "Seriously?
[cpg]


It is very close to the school from the dormitory. While walking that distance, I could hear the rare word "Gokigenyou.
[cpg]


This time I heard "Sis-sama" from somewhere. Maybe I should call Shiho-san "Sis-sama" too.
[cpg]


I'd better not. I'm afraid she'll laugh at me, and if she does, I won't be able to get back on my feet.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


Well, I had reached a critical point on the second day of my cross-dressing life.
[cpg]


I think I did well on the first day. That is, the toilet problem.
[cpg]


I tried to use the dormitory bathroom as much as possible, but even so, the limit of my endurance comes suddenly.
[cpg]


I should have had the courage to go there before class.
[cpg]


It's too late to regret it now. I decided to endure this class for now.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』


And then I stopped in front of the restroom in the hallway.
[cpg]


Is it OK? Isn't this a sanctuary? Because of course it's a women's restroom.
[cpg]


I think about whether it's OK or not, and of course it's not. Right?
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho010"]
[OnName num="Shiho"]
What's wrong?　Mr. Inari-san."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
I backed away while saying, "Ohhhhhh. I was about to shit my pants, watch out.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho011"]
[OnName num="Shiho"]
'...... what's really wrong?
[cpg cn=true]


Nothing!　I said and dashed away.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

After all this happened, we were in front of another restroom.
[cpg]


I was puzzled again. I was puzzled and hesitating.
[cpg]


I knew I shouldn't do this. Because there are girls going in and out even now.
[cpg]


No matter how much I fooled myself, it was no use. It's not a matter of deceiving people or anything like that.
[cpg]


As I was thinking that, this time I received a message from ......
[cpg]




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka006"]
[OnName num="Honoka"]
What's wrong?　Approval."
[cpg cn=true]


When Honoka called out to me, I was strangely not surprised.
[cpg]


 I was really surprised by Shihosan. Is there a difference in tension?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka007"]
[OnName num="Honoka"]
Ah ...... I see. That's right. Do you want me to come in with you?"
[cpg cn=true]


Honoka is very understanding. I honestly thought she was a kind person.
[cpg]


if this is a good thing or not, but it is. I realized once again that she is the only person who knows how discouraging it is for me.
[cpg]


[OnName num="Rin_male"]
He said, "Don't worry, ....... I can go by myself.
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[SE f="se033"]
;//【ＳＥ】『水流す』



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


...... It was refreshing. At the same time as being refreshed, I lost something irreplaceable.
[cpg]


 Or rather, I wonder if it's correct to say that I stole it from another girl who happened to be there.
[cpg]


I don't know. Please help me, whoever you are.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


Then came the second climax. P.E. class.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I'm already feeling heavy on the way to the locker room. If I wasn't in the same class as Honoka, I wouldn't be able to stand it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka008"]
[OnName num="Honoka"]
I'll be fine," she said. I'll be the wall.
[cpg cn=true]


Don't be such a shoplifter. ......
[cpg]



;//========================================
;//●ＣＧ非エロ（更衣室でばれないように着替える主人公。ヒロイン２が隠している）ev_02
;//人物１：主人公（男）
;//服装１：下着
;//人物２：ヒロイン２
;//服装２：体操着
;//場所　：更衣室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="female_studentA"]
I like her, she has big breasts. I adore them.
[cpg cn=true]


[OnName num="female_studentB"]
What?　I'm just fat. You're just fat. You're probably a small eater.
[cpg cn=true]


I hear something I can't ignore, but I keep my mind clear.
[cpg]


[OnName num="Rin_male"]
"...... huh."
[cpg cn=true]


A sigh that still comes out. Honoka heard me.
[cpg]



[VOICE f="Honoka010"]
[OnName num="Honoka"]
What are you going to do?　Do you still want to rest?"
[cpg cn=true]


I just said, "No, I'll do my best,......," and got dressed, tensing up all over my body.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


I think I managed to act like a woman in gym class.
[cpg]


The trick is not to give it your all. Boys' physical strength is always greater than girls'.
[cpg]


So, no matter what you do, you have to relax a little. Also, I don't have a sloppy posture.
[cpg]


I think I got through it. We got through it, didn't we?　What do you think?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho012"]
[OnName num="Shiho"]
Are you okay with ......?"
[cpg cn=true]


I don't see this person often. I wonder if she's approaching me.
[cpg]


I've shown them once that I'm vulnerable. Maybe they care about me, too.
[cpg]


Anyway, I decided to say what I couldn't say.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="Rin_male"]
"Good day to you, Shiho-san.
[cpg cn=true]


First of all, it took courage to say "Gokigenyo," a greeting I was not used to, and then it took even more courage to say "Shiho-san.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho013"]
[OnName num="Shiho"]
Yes, hello. rin-san."
[cpg cn=true]


Then he replied, "Hello. I'll never say "Gokigenyo" again.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho014"]
[OnName num="Shiho"]
I'll never say hello again. Are you okay?"
[cpg cn=true]


I see, now I look tired.
[cpg]


I'm feeling all kinds of mixed feelings, but in general, I guess I'm tired.
[cpg]


I have to act like everything is fine. If they can see through me, I'm finished.
[cpg]


[OnName num="Rin_male"]
"It's nothing. I'm fine.
[cpg cn=true]


I reply. Shiho still seems to be worried about me.
[cpg]


But the more she worries, the more likely she is to find out.
[cpg]


I even think that it might be better not to see her anymore. I even think about it.
[cpg]


Am I becoming a little despicable? Too many things are happening. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho015"]
[OnName num="Shiho"]
Is that so?　You can always count on me.
[cpg cn=true]


He says things that make me cry, but I can't depend on him.
[cpg]


I can't reveal that I am a man. I want to reveal it, but I can't.
[cpg]


The moment he finds out I'm a man, he will be disillusioned ...... or even perverted.
[cpg]


[OnName num="Rin_male"]
I'm really okay with it. Then ......."
[cpg cn=true]

;//asd
The first thing to do is to make sure that you have a good time.
[cpg]




;//ＢＫ



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

On the way there, I ran into another girl. I ran into another girl. It was quite a shocking encounter.
[cpg]



[SE f="se007"]
;//【ＳＥ】『ぶつかる音』

;//ここから暫く梓の名前を「？？」と隠してください




[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Azusa001"]
[OnName num="unknown"]
"Kya!"
[cpg cn=true]

[free time=1000]
I bumped into a girl at a corner.
[cpg]


The girl had fallen down. I wondered if I had hit her that hard, but I reached out to her.
[cpg]


[OnName num="Rin_male"]
"Are you okay?　Can you stand up?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
I said, and the girl looked up at me with sparkling eyes.
[cpg]


[OnName num="Rin_male"]
"Oh my God!
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
What was she thinking?
[cpg]


I tried to shake her off, but I couldn't. She was so strong.
[cpg]


I don't know what's making her do it, or what she's thinking in the first place.
[cpg]


[VOICE f="Azusa002"]
[OnName num="unknown"]
I don't know what she's thinking in the first place.　Please go out with me!
[cpg cn=true]


Go out with me?　What is she talking about? People are gathering around us.
[cpg]


I tried to stay as calm as possible, but this situation is not good.
[cpg]


If they get too close, they will know. There is a possibility of hitting something that should not be there.
[cpg]



;//ここから梓の名前をそのまま表記してください





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa003"]
[OnName num="Azusa"]
I'm Azusa Sanjo, a freshman!　I've been looking for my sister of destiny for a long time.
[cpg cn=true]


I feel like I'm being explained from the opposite end of the spectrum.
[cpg]


I get impatient when I'm explained in reverse order until I reach the conclusion that I want to go out with you.
[cpg]


I was in a hurry even if I wasn't. I had never been hugged by a girl before in my life. It was the first time in my life that I was hugged by a girl.
[cpg]


[OnName num="Rin_male"]
「ごめんね、俺さ、授業があるあるから」
[cpg cn=true]


I was in such a hurry that I let my true self come out. I said, "It's me," which was also a bad idea.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Azusa004"]
[OnName num="Azusa"]
I'm a girl!　It's wild, it's wonderful, it's love at first sight!
[cpg cn=true]


What do you mean by "me"? I don't know such a technical term.
[cpg]

;//asd
Anyway, I felt a sense of urgency from the gallery that kept gathering, and I forced myself to shake it off.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]

;//asd
[OnName num="Rin_male"]
I'm going to go to ...... class then, you know.
[cpg cn=true]


His eyes glazed over. I thought that even if I ran away, he would come after me.
[cpg]


Just because I knew he would come after me, it didn't mean I couldn't run away.
[cpg]



[SE f="se000"]
;//【ＳＥ】『走る』


I ran away as fast as I could. I think I was running at an uncharacteristic speed for a girl.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="Rin_male"]
"Tired ......"
[cpg cn=true]


I was tired to the extent that I couldn't say the words I was not accustomed to saying.
[cpg]


I was so tired that I couldn't say the words I was accustomed to saying.
[cpg]


[OnName num="female_student"]
"Are you okay?　You've looked pale ever since you moved in.
[cpg cn=true]


[OnName num="Rin_male"]
I'm fine.
[cpg cn=true]


How many times have I told her since I came here? I'm fine.
[cpg]


It doesn't matter how many times I've said it, I'm really tired of it. ......
[cpg]


[OnName num="female_student"]
I'm Takanashi. If you want, I can talk to you about it.
[cpg cn=true]


[OnName num="Rin_male"]
It's not like there's anything I can do to help you.
[cpg cn=true]


I'm sure I'm right.
[cpg]


I'm not saying that this person is a man and that he dresses as a woman.
[cpg]


There is no one who understands my feelings. Honoka is a girl after all.
[cpg]


[OnName num="female_student"]
What's your secret?　If so, you can tell only me.
[cpg cn=true]


You're so perceptive. I never said anything about it being a secret.
[cpg]


I've never said anything about a secret.
[cpg]


[OnName num="Rin_male"]
Really, it's okay.
[cpg cn=true]


He said it again. What's okay?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

I was walking around exhausted again today, and I was so tired that I got lost.
[cpg]


[OnName num="Rin_male"]
"Where am I? I'm at ......."
[cpg cn=true]


I end up in a place I don't recognize. I was completely lost in the strangely large school.
[cpg]


Then I hear a girl's voice coming from somewhere.
[cpg]


The voice comes from inside the classroom. I tried to ask her for directions.
[cpg]


This was another big mistake, but ...... on the other hand, it might have been a fateful encounter.
[cpg]



;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

There was Shiho there. She looked like she was in some kind of pain.
[cpg]


Her face was blushing and her breathing was a little rough.
[cpg]


And she was calling someone's name: ......
[cpg]


It was kind of beautiful to the point where I felt like I shouldn't look at him, and I couldn't help but walk away from him.
[cpg]


I feel embarrassed to put this into words, but it was like ......
[cpg]


She looked as if she had someone she loved and was thinking of him or her.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
From there, I managed to make it back to the dormitory on my own and catch my breath.
[cpg]

[OnName num="Rin_male"]
I'm tired ......."
[cpg cn=true]


You've said this a lot, too. The words have a similar meaning.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
The same roommate, Honoka, is worried. I'm going to ask her without hesitation here.
[cpg]



[OnName num="Rin_male"]
 if you've ever heard of her, but I'm sure you've heard of her.
[cpg cn=true]


Honoka nodded. After nodding, she continued.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka011"]
[OnName num="Honoka"]
I know her. I've heard a lot of rumors about her, too.
[cpg cn=true]


What did you say?　What did you just say?　I'm still caught up in the "hears rumors" part. ......
[cpg]


I think you just said "that person, too. Did you mean there are rumors about other people?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka012"]
[OnName num="Honoka"]
'But I don't know anything more than rumors either. What's wrong?"
[cpg cn=true]


No, nothing. I said and plopped down on my desk.
[cpg]





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka013"]
[OnName num="Honoka"]
'Are you sure you're okay?　Shall we sleep together?"
[cpg cn=true]


Honoka says that kind of thing too. It's like some junior.
[cpg]


What was her name, Ichijo, or is it Nijo?　Oh well.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************

The next morning, in the hallway at the beginning of class.
[cpg]


[OnName num="Rin_male"]
......What's that girl doing?"
[cpg cn=true]


There's a girl wandering around in front of the bathroom.
[cpg]


I have no idea what she is doing. She's waiting for someone, but she's fidgety.
[cpg]


There's no way she's holding back, because the bathroom is right in front of her.
[cpg]


I'll leave ...... alone.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And I'm going to take my morning classes with a more sane spirit than yesterday.
[cpg]


I have a career path, too. I can't neglect my classes.
[cpg]


I don't have a specific goal in mind, but it's a student's duty.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

And then lunch break. The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


[OnName num="female_student"]
I was wondering, do you have a favorite idol?
[cpg cn=true]


 Such a story started from trivial topics such as recent TV.
[cpg]


[OnName num="Rin_male"]
The first thing that comes to mind is the fact that the two of you have been in touch with each other for a long time.
[cpg cn=true]


I got to know Ms. Takanashi a little better, and we got to know each other well enough to not use polite language.
[cpg]


But unfortunately, I don't know much about idols at all.
[cpg]


[OnName num="Rin_male"]
I remember that famous Marurin person. I wonder if I like his face.
[cpg cn=true]


I tried to remember the face of an appropriate idol and said her name.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Honoka014"]
[OnName num="Honoka"]
"Oh my God," Honoka said.
[cpg cn=true]


Honoka said. I didn't know what was so bad at first, but ......
[cpg]


[OnName num="female_student"]
'Marurin?　That's a female idol, right?"
[cpg cn=true]


I realized. It is indeed bad.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka015"]
[OnName num="Honoka"]
"Haha, you see, Inari is the type of person who admires the same sex..."
[cpg cn=true]


[OnName num="female_student"]
But she's a guy who is popular with men, isn't she?
[cpg cn=true]


[OnName num="female_student"]
 “You also said that you like your face……Maybe it’s Rin-san.”
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
Oh, what am I going to do? Honoka is digging her grave too. If she hears one word about this, I'm done.
[cpg]


I mean, "Is it a boy?" And. The one word that could kill me socially.
[cpg]


[OnName num="female_student"]
"I wonder if he has a taste for yuri."
[cpg cn=true]

;//[t_move pos=C 下礼]
Bummer. And I don't even know how to say "yuri".
[cpg]


But ......Kotoriyu-san, you're kind of teasing me, aren't you?
[cpg]


It's as if she's already figured out that I'm a guy. I don't think so.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I feel more tired than usual today.
[cpg]


Is my fatigue escalating? Or is it just accumulating?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[SE f="se000"]
;//【ＳＥ】『歩く』

[OnName num="Rin_male"]
I'm wondering if I took a wrong turn again at .......
[cpg cn=true]


Again, I wandered into a corner of the school similar to yesterday.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

There, as expected, was Shiho.
[cpg]


Just like before, she has the look of a maiden in love.
[cpg]


And she was still calling someone's name.
[cpg]


I couldn't stop thinking about that name, so I stayed where I was.
[cpg]


Then I leaned against the door a little. I just leaned against the door a little.
[cpg]


[OnName num="Rin_male"]
"Ah!"
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[SE f="se007"]
;//【ＳＥ】『倒れこむ　ドサッ』

The door opened and I fell down.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Shiho034"]
[OnName num="Shiho"]
I fell down.
[cpg cn=true]


I didn't fall down. What are you going to do with this air?
[cpg]


[BGM f="bg_un"]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShiho001"]
[OnName num="Shiho"]
"......, did you hear me talking to myself just now?"
[cpg cn=true]


[OnName num="Rin_male"]
"No. I didn't. No, I didn't. Even if I did, I'll pretend I didn't hear it. Even if I did, I'll pretend I didn't hear it.
[cpg cn=true]


I thought this was a bad way to put it, but I couldn't think of anything else to say.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShiho002"]
[OnName num="Shiho"]
I thought this was a bad way to put it, but I couldn't say anything else.
[cpg cn=true]


Then, Shiho-san started talking about something I hadn't heard.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sShiho003"]
[OnName num="Shiho"]
I just can't help it. I can't stop myself from falling in love.
[cpg cn=true]


[OnName num="Rin_male"]
What?"
[cpg cn=true]


I braced myself, thinking that she was going to say that she liked me. But
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho004"]
[OnName num="Shiho"]
"I just can't help but fall in love with ...... everyone. It's funny, isn't it?"
[cpg cn=true]



These words did not sound like something a lovesick maiden would say.
[cpg]


It seems that Shiho is seriously worried about it.
[cpg]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sShiho005"]
[OnName num="Shiho"]
It's not normal to fall in love with someone of the same sex.
[cpg cn=true]


But I wanted to deny her that one word.
[cpg]



;//========================================
;//●ＣＧエロ（ヒロイン１に触れていく主人公。背後から胸や股間を触る。互いに立っている）ev_05
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン１
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="Rin_male"]
I wanted to deny that one thing. Shiho-san.
[cpg cn=true]




[VOICE f="sShiho006"]
[OnName num="Shiho"]
"Yes, ......."
[cpg cn=true]


I went up to her and continued, "I don't know what's bothering you.
[cpg]


[OnName num="Rin_male"]
I don't know what's troubling you, but nowadays it's not unusual for people of the same sex to be in love.
[cpg cn=true]


She looks away and blushes again.
[cpg]


I don't know what's going on, but if I could make her feel a little better ......
[cpg]



;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
I did what I did with that in mind, but it was not good that our bodies were so close together.
[cpg]


Her breastplate was against her body.
[cpg]




[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho053"]
[OnName num="Shiho"]
She said, "...... Oh my?"
[cpg cn=true]


Shiho-san, even under the circumstances, was remarkably aware of my discomfort with her breasts.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Shiho054"]
[OnName num="Shiho"]
Are you a man?
[cpg cn=true]


I nodded my head, with a look of "I've done it" on my face.
[cpg]


It was more like I'd done it, but now he knew. There was no way out of this.
[cpg]


What would Shiho think of me? Would she call me a pervert?
[cpg]


As I was thinking that, she said something different from what I had imagined.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
;//[t_move pos=C 動揺]

[VOICE f="Shiho055"]
[OnName num="Shiho"]
I said, "You're so nice, ......!　Oh, to meet a gentleman in a school like this.
[cpg cn=true]


What kind of reaction is that,......?
[cpg]


You shouldn't be happy that there are men in the school.
[cpg]




;//========================================
;//●ＣＧエロ（男だとばれて、手コキされる主人公。少しヒロインはかがんでいる感じ）ev_06
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン１
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Shiho065"]
[OnName num="Shiho"]
Tell me ...... why you are a man and you transferred to this school. How did you get into this school if you're male?"
[cpg cn=true]


Shiho-san asked me. I knew I had no choice but to answer honestly.
[cpg]


I explain. That I would become a woman in a year, and that I had transferred here to get used to it.
[cpg]


And how sorry I am for deceiving Shiho-san. ......
[cpg]


;**【ＣＧ】 ev_06_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Shiho066"]
[OnName num="Shiho"]
'I see. So it was so. ......After all, this academy is ......"
[cpg cn=true]


Shiho-san seems to have been convinced of something.
[cpg]


I don't know what you have convinced me of, but I have something I want to ask you.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="Rin_male"]
Let me ask you something too. What do you mean when you say you fall in love with everyone?"
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sShiho007"]
[OnName num="Shiho"]
I'm ...... I'm nothing."
[cpg cn=true]


It's a blatant lie. After looking so thoughtful, that's not going to happen now.
[cpg]


But it looked like he wanted to hide it, so I decided to leave it alone.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

So we parted ways, leaving some things unsettled.
[cpg]


We promised each other that we would keep this a secret. Promising to keep it a secret.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』


I decided to go back to the dormitory.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Azusa005"]
[OnName num="Azusa"]
"Hey, lady!　Are you going home now?
[cpg cn=true]


The one hugging me from behind was the Ichijo, or was it Nijo?　I want you to stop calling me "big sister".
[cpg]


I wish she would stop calling me "sister.
[cpg]



[OnName num="Rin_male"]
You're so close, Azusa!
[cpg cn=true]


I called her Azusa without any resistance. This girl has an animal-like quality that makes others do so.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa006"]
[OnName num="Azusa"]
I don't know what it means.
[cpg cn=true]


I don't know what that means. I don't know what it means, so I decided to shake it off.
[cpg]


If you get too close and hit something, you might ...... not be able to get it?
[cpg]


Now, there was a strange feeling on Azusa's body. I wonder if it was my imagination.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





[VOICE f="Azusa007"]
[OnName num="Azusa"]
I'm not a dorm student, so I guess this is where we part ways."
[cpg cn=true]


So, I parted from Azusa as it was.
[cpg]


This school is not a boarding school, I thought now.
[cpg]


I guess it is a place where more strict parents are allowed to live in the dormitory.
[cpg]


But my parents are not so strict. And I'm not too crazy about having a girl roommate.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夕方）******************************************************


[OnName num="Rin_male"]
"...... that?"
[cpg cn=true]


When I returned home, Honoka was not there. Instead, there was a letter.
[cpg]


She said, "I'm in the hospital today. I'll be back tomorrow.
[cpg]


Hospital?　Does Honoka have some kind of illness or peculiar constitution?
[cpg]


My imagination is growing more and more.
[cpg]


My suspicion that something is wrong with this school is growing.
[cpg]



[jump storage="ep002.ks" target="*start"]

