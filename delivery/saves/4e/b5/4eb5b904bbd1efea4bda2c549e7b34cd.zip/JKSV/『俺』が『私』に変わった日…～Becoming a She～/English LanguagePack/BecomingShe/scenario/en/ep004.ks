

*start

;#################################################
*Ep004|Poetry Walks that Supported Us
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

[stflag ChaBad = 0]
[if exp={ isSystemFlagsEnabled( "sysflg_bad") }]
[stflag ChaBad = 1]
[endif]

*select04_1|支えてくれた詩歩

[SCENE id=4]


......I knew it was Shiho.
[cpg]


At the very beginning, you supported me.
[cpg]


I still remember that time. I want to protect her this time.
[cpg]


[OnName num="Rin_male"]
......I've made up my mind.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka054"]
[OnName num="Honoka"]
What?　What?"
[cpg cn=true]


I was plugged into talking to myself.
[cpg]


If you choose Shiho, it means you don't choose Honoka.
[cpg]


But I can't help it. I want to be honest about my feelings.
[cpg]


I don't want to lie. That should be the same for Shiho.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


I left the dormitory wanting to confess my feelings to Shiho as soon as I met her.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


But I can't meet her for a long time. I wonder why we don't see each other so much just because we are in the same grade.
[cpg]


During lunch break, I went to the classroom where Shiho was supposed to be, but she was not there.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

And after school. The person was there.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Shiho085"]
[OnName num="Shiho"]
"Oh, ......rinsan. Hello."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
It seemed as if Shiho-san was still thinking about someone else.
[cpg]


Well, let's ask her about that before I confess. ......
[cpg]



[OnName num="Rin_male"]
Is Shiho-san also peculiar?"
[cpg cn=true]


Shiho-san already knows that I turn into a woman.
[cpg]


And he acted like he knew that this academy was full of people with idiosyncratic constitutions.
[cpg]

Now she might reveal her constitution to us.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho086"]
[OnName num="Shiho"]
'...... I'm nothing. Normal."
[cpg cn=true]


But no. I guess I'm still not far enough.
[cpg]


Then I guess I'll have to confess. I don't want to let this person tell me a painful lie.
[cpg]


If he says he's in love, I want to take care of it all.
[cpg]



[OnName num="Rin_male"]
"Shiho, I love you."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
The moment she said that, Shiho was stunned.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
From there, she gradually ...... somehow changed to a crying face.
[cpg]


Did you really hate it that much that he confessed to me?　I'm going to mend it.
[cpg]



[OnName num="Rin_male"]
I was so sorry!　I know it's a little bit too much for me, but I really like you, Shiho-san.
[cpg cn=true]


Oh no. Am I digging a grave? If she doesn't like it, I feel like I'm hurting her more than I'm hurting her.
[cpg]


But Shiho shook her head.
[cpg]


;//[t_move pos=C 動揺]
[VOICE f="Shiho087"]
[OnName num="Shiho"]
I didn't think it was a mutual love.
[cpg cn=true]


Eh?　if I can take that as a yes or no.
[cpg]


I clench my hands. I'm sweating.
[cpg]


And I wait for Shiho's words. Time passes so slowly that it is frustrating to cry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shiho088"]
[OnName num="Shiho"]
I'm so frustrated that time passes so slowly that I feel like crying. I love you, Mr. Inari.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


Shiho comes close to me. The closer they are, the less distance there is between them.
[cpg]


A kiss. It was a gentle kiss. And ......
[cpg]


;//発情しきってるその体温が、伝わってくるようなキスだった。
It was the kind of kiss where you can feel her body heat as she's all tensed up.
[cpg]



;//移植のためシーンをカットしています



[VOICE f="sShiho010"]
[OnName num="Shiho"]
Kyah!"
[cpg cn=true]


I couldn't resist and pressed even closer to her.
[cpg]



;//========================================
;//●ＣＧエロ（処女喪失。正常位で交わる。前のＣＧに引き続き机の上）ev_14
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン１
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

On the desk, Shiho was leaning her back against me.
[cpg]


I thought I had gone too far, so I tried to make it up to her.
[cpg]


[OnName num="Rin_male"]
I was so sorry," she said, "I'm sorry. You're surprised, aren't you?
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=10 index=1 time=1]
;***************************************
[WAIT time=1]



[VOICE f="sShiho011"]
[OnName num="Shiho"]
I said to her, "...... is fine. I don't care what you do to me if it's for your approval.
[cpg cn=true]


But Shiho was more accepting of me than I had imagined.
[cpg]


Of course, there is nothing to do right now. But I just received that feeling.
[cpg]



;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

While there was such a thing as ...... I and Shiho-san decided to go out with each other.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka055"]
[OnName num="Honoka"]
What?　Shiho-san is ...... three years old?"
[cpg cn=true]


And I decided to tell Honoka about it first.
[cpg]


Honoka seemed to know about Shiho. I thought to myself, "I'm in the same dormitory as her, so it's only natural that she knows about her.
[cpg]


[OnName num="Rin_male"]
I'm going to go out with you. Because we're going out."
[cpg cn=true]


Honoka is puzzled. The first thing you need to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]


I think more than that, she's probably wondering how we got together when I'm a guy.
[cpg]


They must be wondering when and where I revealed that I was a man.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka056"]
[OnName num="Honoka"]
'That's fine, but ...... well, does the other side know?　About the approval."
[cpg cn=true]


I know.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka057"]
[OnName num="Honoka"]
The actuality that you can be a lot more than just a woman.　I'm fine with that.
[cpg cn=true]


Ah, that's what you mean. ...... I hadn't thought about that part.
[cpg]


You mean that in a year they will become a couple of women?
[cpg]


I didn't think that deep into it. Maybe I forgot something pretty important.
[cpg]


I didn't forget to tell her, I told her that.
[cpg]


But I still don't know if she will go out with me after becoming a ...... woman.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


[SE f="se000"]
;//【ＳＥ】『歩く』


While I'm concerned about these things, tomorrow is coming.
[cpg]


I'm heading to the school. On the way there, I met Shiho.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho113"]
[OnName num="Shiho"]
She said, "Oh, ......rinsan. Good morning.
[cpg cn=true]


what to expect from the school, but I'm sure it's something I'm going to have to work on.
[cpg]


I wonder how ...... Shiho is feeling. I should ask her here and now.
[cpg]


No I don't know. If they say they only intend to go out with me while I'm a guy, I can't get back on my feet.
[cpg]


If I can't recover, it's better to ask him. But I don't have the courage.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho114"]
[OnName num="Shiho"]
What's troubling you?　rin-san."
[cpg cn=true]


And he could easily see through that.
[cpg]


I have no other choice but to start talking. I have no choice but to tell him everything honestly.
[cpg]


I had to tell him everything honestly about what I would do after becoming a woman. I ask her if she will still love me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho115"]
[OnName num="Shiho"]
"Giggle. You were worried about that?　Why would I care?
[cpg cn=true]


I don't care about the gender of the person I love," Shiho says.
[cpg]


I wonder if she is bisexual. ......
[cpg]


For me, it was a saving word. I couldn't help but relax.
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Azusa060"]
[OnName num="Azusa"]
I asked her, "Sister, are you on your way to the school right now?"
[cpg cn=true]


Then Azusa came in. I didn't want to see her too much right now.
[cpg]


Azusa tried to cross my arms. Shiho is not upset to see that.
[cpg]


It's awkward. I have to say something to Azusa.
[cpg]


[OnName num="Rin_male"]
"Stop it. Don't get too attached to me.
[cpg cn=true]


I'm in public, so it's in the first person, "I".
[cpg]


Hearing my words, Azusa looked shocked.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Azusa061"]
[OnName num="Azusa"]
She asked, "Why ......?　Do you dislike me now?"
[cpg cn=true]


No, no. It was not that I disliked Azusa.
[cpg]


Well, how can I tell you, ...... just leave it as it is?
[cpg]


[OnName num="Rin_male"]
I have found someone I like."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
Shiho-san's face was red. Azusa looked at me and Shiho-san alternately.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

The rumor spread quickly.
[cpg]


I don't think Honoka would say it, so it must be Azusa.
[cpg]


[OnName num="female_studentA"]
"That transfer student, I heard she's dating a senior. ......?"
[cpg cn=true]


[OnName num="female_studentB"]
That's great, I knew that was the way it was at the women's school.
[cpg cn=true]


[OnName num="female_studentA"]
"Let's go out with her too. ......
[cpg cn=true]


[OnName num="female_studentB"]
"Stop joking, already."
[cpg cn=true]


Ah. I don't know how it happened. I didn't want to make it too public.
[cpg]


The risk of being found out as a man is also increased.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

[SE f="se000"]
;//【ＳＥ】『歩く』


With all of this in mind, I finished ...... class and returned to the dormitory.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


When I returned, Honoka was not there. Instead, there is a letter left for her.
[cpg]


She said that she is staying in Shiho's room. ......
[cpg]


Is this, in other words, a thing?
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』




[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho116"]
[OnName num="Shiho"]
I'm sorry to bother you,......, were you surprised?
[cpg cn=true]


Of course I was surprised. But it's a nice surprise.
[cpg]


[OnName num="Rin_male"]
I'm sure you'll be very happy to know that I'm not the only one who's been surprised by this.
[cpg cn=true]


Shiho shook her head. What does that mean?
[cpg]


You mean Honoka started to tell you that. That's right, and there's a leftover letter.
[cpg]


Honoka is being thoughtful too,......, so you could take it as a blessing.
[cpg]



;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

From there we talked about nothing else.
[cpg]


Such an ordinary time was the happiest of all. ......
[cpg]








[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************



[OnName num="Rin_male"]
......Shiho, you really don't have any idiosyncrasies, do you?"
[cpg cn=true]


You may think I'm being a bit harsh. But I had no choice but to ask him again and again.
[cpg]


While he doesn't want to admit it, the same reply may come back to him. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho131"]
[OnName num="Shiho"]
"I don't have ...... any idiosyncrasies or anything like that. Unlike Mr. Approval."
[cpg cn=true]


That's an unusually thorny way of putting it.
[cpg]


 But I don't want to keep holding on. That's why we're still dating.
[cpg]


I want to be the one to let her go. I don't want her to lie anymore.
[cpg]


[OnName num="Rin_male"]
It's hard when you lie to yourself. I think you can understand that.
[cpg cn=true]


Shiho still seemed a little angry.
[cpg]


She had an almost expressionless face. She never gets angry with her facial expression.
[cpg]


I can understand that somehow. But ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shiho132"]
[OnName num="Shiho"]
So you'll take it all in, Mr. Circle of rin-san?
[cpg cn=true]


I can tell he's still a little angry. He seems more impatient than usual.
[cpg]



;//========================================
;//●ＣＧエロ（騎乗位で主人公を襲う感じのヒロイン。何度出してもやめさせてくれない）ev_16
;//人物１：主人公（男）
;//服装１：裸
;//人物２：ヒロイン１
;//服装２：裸
;//場所　：学生寮室内
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


[SE f="se007"]
;//【ＳＥ】『ベッドに倒れこむ』

Then I was pushed down on the bed by Shiho.
[cpg]


[OnName num="Rin_male"]
I was surprised.
[cpg cn=true]


I was indeed surprised. But Shiho's expression is the same as before.
[cpg]


It was almost expressionless,......, but it looked painful.
[cpg]




[VOICE f="sShiho012"]
[OnName num="Shiho"]
I'm sure that if I told you everything I'm thinking,......, you'd be surprised.
[cpg cn=true]




[VOICE f="sShiho013"]
[OnName num="Shiho"]
I'm sure rin-san will end up hating me."
[cpg cn=true]


[OnName num="Rin_male"]
"......"
[cpg cn=true]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho146"]
[OnName num="Shiho"]
I'm sure you'll hate me. ......That's enough, there are times when you have to lie to yourself.
[cpg cn=true]




[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sShiho014"]
[OnName num="Shiho"]
I'm happy just to be able to sleep with you,.......
[cpg cn=true]


Even a single word like that feels like a lie. But what happens when we pursue this lie?
[cpg]


Even those words feel like a lie. But what happens when we pursue that lie?
[cpg]



;//ここまでにバッドエンド固定の分岐を通っている場合、選択肢は発生せず２を選んだことになる
[if exp={getFlagValue("ChaBad") == 1}]
[jump target=*select05_2]
[endif]


;//■選択肢
[switch]
[case "Pursue the lie"]
	[swap]
	[jump target="*select05_1"]
[case "Do not pursue the lie"]
	[swap]
	[jump target="*select05_2"]
[endswitch]


1, pursue the lie
2, do not pursue the lie

;//==============================
;//１、嘘を追及する
*select05_1
[jump storage="ep005.ks" target="*select05_1"]


;//==============================
;//２、嘘を追及しない
*select05_2
[jump storage="ep006.ks" target="*select05_2"]

