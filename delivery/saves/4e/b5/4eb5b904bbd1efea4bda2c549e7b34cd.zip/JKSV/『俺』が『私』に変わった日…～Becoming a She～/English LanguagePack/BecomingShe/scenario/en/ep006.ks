
*start


;#################################################
*Ep006|A good sense of distance
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

*select05_2|ほどよい距離感


[SCENE id=6]


I decided not to pursue her lies. A good distance is necessary.
[cpg]



[OnName num="Rin_male"]
Then ...... good night.
[cpg cn=true]


Thus, Shiho and I slept next to each other. I was so happy to see her.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（朝）******************************************************


From then on we stayed in the same room.
[cpg]


But I didn't tell her about her condition.
[cpg]


I can say that I respect Shiho's feelings because she is lying to me.
[cpg]


What ...... might be a convenient interpretation for me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』


As a result of continuing to put up with ...... Shiho in this way.
[cpg]


I was punished for that.
[cpg]


One day. I was called to a classroom at the end of the school by Shiho.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="Rin_male"]
She was already there.
[cpg cn=true]


She was already there. Then, she said something like this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho194"]
[OnName num="Shiho"]
She said, "I'm sorry ....... I'm at the end of my patience.
[cpg cn=true]


Saying this, he takes out a handkerchief and puts it over my mouth.
[cpg]


As I wondered what it was, my consciousness faded away.
[cpg]


[VOICE f="Shiho195"]
[OnName num="Shiho"]
I'm so tired of lying to you ......."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


The next thing I knew, I woke up in a basement, I don't know where.
[cpg]


I was restrained. I can only move my fingers.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho196"]
[OnName num="Shiho"]
I asked, "Are you ...... awake?"
[cpg cn=true]


It was Shiho. I protested, not understanding the situation.
[cpg]



[OnName num="Rin_male"]
Where am I? How could this ...... happen?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho016"]
[OnName num="Shiho"]
I'm sorry. I'm just the way I am.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho017"]
[OnName num="Shiho"]
"Falling in love is the most important thing in my life. ......"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho018"]
[OnName num="Shiho"]
I just can't bear the thought of you being so far away from me.
[cpg cn=true]




No, the truth is, I'm aware of it too. The truth is, I've been putting up with too much from you, Shiho.
[cpg]


That said, I couldn't imagine that I'd go so far as to lock someone up like this, but ......
[cpg]



[VOICE f="Shiho197"]
[OnName num="Shiho"]
I don't think you know this, but I'm really a young lady."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

He comes closer to me saying that. And then she kissed me as I was restrained.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho019"]
[OnName num="Shiho"]
I can hide it well enough for one person.
[cpg cn=true]



;//移植のためシーンをカットしています




;//ＢＫ


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And ...... days passed.
[cpg]


The restraints were lifted. I was given food, water, and a bathroom.
[cpg]


But they never let me leave my room. I'm not even sure how much time has passed.
[cpg]


Is it summer now?　Is it already autumn?
[cpg]


As these hours repeated over and over again, ......
[cpg]


I was moved to the hospital. It's not that I got sick.
[cpg]


It's just that it's been a long time since I've been outside and what I found out is that the seasons have come full circle.
[cpg]


That means my sexual reversal syndrome has begun.
[cpg]


I'm on absolute bed rest for a month while I'm in the process of degeneration. During that time, I was to be seen by the Hachiman family doctor.
[cpg]


I couldn't even see my parents during that time. What kind of power does the Shiho family have?
[cpg]


More than my body, I hated the idea of being sent back to that basement-like place after being changed.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





These days would not last that long. It would not be so easy to keep them locked up.
[cpg]


But I knew that I would lose my mind before the day came when I would be released.
[cpg]


It was undeniably me who had caused this to happen to Shiho.
[cpg]


I feel so ashamed when I think about it. But it is too late for any regrets.
[cpg]


The two of us are going to go crazy together. I'm sure ......
[cpg]


[SCENE id=14]

;//ＥＮＤ：ヒロイン１バッドエンド
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="bend.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=2100]


[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[jump storage="epend.ks" target="*back_title"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


