
*start


;#################################################
*Ep012|A Superficial Lover's Relationship
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=10]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************


*select07_2|上辺だけの恋人付き合い

[SCENE id=12]


I decided not to think too much about it. Because it's true. What's the point of thinking about it any more?
[cpg]


Now that I've reached the truth, can I escape the tragedy?
[cpg]


Maybe there's nothing I can do. I think that's why Honoka is hiding it from me.
[cpg]



[OnName num="Rin_male"]
'Well then, let's do a little more.
[cpg cn=true]


I just let myself be carried away by the temporary pleasure. There was no resistance to that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


We were flirting again. In the middle of it, Honoka started to cry.
[cpg]


I didn't know what to do anymore.
[cpg]


Can't I escape from pleasure? Then what should I run away to?
[cpg]


I didn't know anymore. I didn't want to think about it because I didn't know.
[cpg]


...... Then Honoka starts refusing to kiss him again.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************

We were lovers on the surface. We would go to school hand in hand, and I was happy to be rumored to be doing so.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shiho261"]
[OnName num="Shiho"]
I was happy to see that and hear the rumors. I envy you a little.
[cpg cn=true]


But I also thought there was nothing to be envied.
[cpg]


Honoka is lying about something. And I would not pursue it.
[cpg]


It's just a superficial relationship. I can't help but feel that way.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Honoka267"]
[OnName num="Honoka"]
I wonder if ...... is correct."
[cpg cn=true]


Honoka also looks happy. Somehow I know that is also a lie.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

...... time passes.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
Honoka kept refusing to kiss me. But I couldn't resist and took her lips from time to time.
[cpg]


Each time she cries, but I don't ask her to leave.
[cpg]


I don't ask her what's wrong. I don't ask her anything.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（朝）******************************************************

The season turns to autumn. The strange feeling I had for Honoka becomes stronger.
[cpg]


For example, she wakes up in the morning and doesn't know where she is.
[cpg]

;//asd
Or she doesn't know how to get to the school. Even though it is such a short distance.
[cpg]


The feeling of discomfort is no longer discomfort, but a clear abnormality.
[cpg]


Still, I continued to pretend not to notice.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


Autumn passed and winter came.
[cpg]


By the time winter came, I started to refrain from flirting.
[cpg]


That was the trigger. I somehow knew.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

Spring. Shortly before Shiho graduated and I moved up one grade. ......
[cpg]


That's when the sexual inversion started in my body.
[cpg]


I've been on bed rest for the past month. I can't even see Honoka because she says my body has become delicate.
[cpg]





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka269"]
[OnName num="Honoka"]
She said, "...... I really turned into a girl, didn't I? I kind of can't believe it."
[cpg cn=true]


I was so excited to see her, but I couldn't help but think that I had to be careful in my own way.
[cpg]


I'm sure Honoka is being considerate in her own way.
[cpg]


;//（女）
[VOICE f="sRin004"]
[OnName num="Rin_female"]
I've been in the hospital for a month, you know?　I can't stand it.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka270"]
[OnName num="Honoka"]
The first person is now me too. You're adapting fast. ......
[cpg cn=true]


Honoka is laughing. She is not laughing from the heart.
[cpg]


It was frustrating. I got frustrated and pushed Honoka down.
[cpg]



;//========================================
;//●ＣＧエロ（主人公がヒロインの胸やまんこを指で責める。二人ともベッドに寝ている状態。ヒロインは途中で記憶を無くし、嫌がりだす）ev_50
;//人物１：主人公（女）
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//場所　：主人公の家＿主人公の部屋
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sHonoka020"]
[OnName num="Honoka"]
I forced her to cover her lips.
[cpg cn=true]


I forcibly cover her lips. I never kissed her deeply before.
[cpg]


Honoka was left to her own devices for a while, but ...... soon.
[cpg]


;**【ＣＧ】 ev_50_a ***********************
[CG id=18 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sHonoka021"]
[OnName num="Honoka"]
"...... you, who are you?"
[cpg cn=true]


I was so excited to see her.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[SE f="se032"]
;//【ＳＥ】『頬をはたく』

After slapping me on the cheek, Honoka ran out of the house.
[cpg]


I did not chase after her. Honoka is Honoka, and she would not know the way when she ran out.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（昼）******************************************************

I later heard from Honoka's parents.
[cpg]


About Honoka's peculiar constitution. It is a condition that is triggered by a crush or a love affair that causes her to lose her memory.
[cpg]


Sometimes it's a small loss of memory, but sometimes it's a big loss that accumulates.
[cpg]


I can't stand up to this fate. I would not have been able to resist it no matter what choice I made.
[cpg]


That's why I'm okay with this. Honoka and I are strangers. That's the way it has to be.
[cpg]



;//========================================
;//●ＣＧ非エロ（鏡の前に立つ主人公。既に女性になっている）ev_49
;//人物１：主人公（男）
;//服装１：制服
;//場所　：主人公の家＿主人公の部屋
;//時間　：朝
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=19index=0 time=1000]
;***************************************
[WAIT time=1000]

I stood in front of the mirror. I've just become a woman.
[cpg]


Honoka doesn't know me anymore.
[cpg]


If this is the case, I should never have fallen in love with Honoka.
[cpg]


My body has also become a woman, and yet I still love Honoka.
[cpg]


There's no way around it, we're separated. ......
[cpg]


If you are a man and a woman, you may be able to start over again.
[cpg]


But I lost my memory, and besides, I don't remember me when I was a man.
[cpg]


I can't help it. There is no way to build a relationship from this point on.
[cpg]


My body, now that I am a woman, is telling me that I can't make up for the days gone by. The days are gone and I can't get them back.
[cpg]


But I pretended not to see it. Yes, it is in my nature to turn a blind eye.
[cpg]


That's how I ended up in this situation.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_un"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

I transferred to a different school than the one I attended before.
[cpg]


I couldn't bear the thought of attending where Honoka was.
[cpg]


I felt like I couldn't stand the thought of seeing Honoka's face. ......
[cpg]


Holidays. The first thing to do is to make sure that you have a good time.
[cpg]


Somehow, I wanted to be swallowed up by this crowd.
[cpg]


;//（女）
[VOICE f="Rin208"]
[OnName num="Rin_female"]
Ah......"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
And she met my eyes for a moment in the crowd.
[cpg]


[VOICE f="Honoka282"]
[OnName num="Honoka"]
"......."
[cpg cn=true]


She just walked past.
[cpg]

[SCENE id=18]

[FADEOUTBGM]

;//ＥＮＤ：ヒロイン２バッドエンド
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="bend.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=3100]


[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[jump storage="epend.ks" target="*back_title"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
