

*start

;#################################################
*Ep007|Azusa that chases after me
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

[stflag ChaBad = 0]
[if exp={ isSystemFlagsEnabled( "sysflg_bad") }]
[stflag ChaBad = 1]
[endif]

*select04_3|俺を追いかけてくれる梓

[SCENE id=7]

[free time=1000]

......Another person I never thought I would meet popped into my mind.
[cpg]


Azusa. A cute junior who has been chasing me for a long time.
[cpg]


I mean, I thought she was someone I could be pushed around by. ......
[cpg]


Wasn't I also being pushed around because I wanted to be?　Thinking about it makes me think Azusa is cute.
[cpg]


Azusa is the only one who noticed my true identity without touching me or anything.
[cpg]


Maybe she's watching me more closely than I thought.
[cpg]


And she's a nun. It's not that I didn't have a calculating thought that I could love her either as a man or a woman .......
[cpg]


But ultimately the deciding factor was that I found myself loving her.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho249"]
[OnName num="Shiho"]
"Good morning, Mr. Approval."
[cpg cn=true]


Good morning," I replied.
[cpg]


It's not that I didn't have Shiho in my mind.
[cpg]


Shiho helped me. I think she was supportive of me.
[cpg]


But love is a different thing. I was no longer troubled by it.
[cpg]


;//0205修正
;//<Shiho250>
;//詩歩「……何か、良い顔をされてますね。何か悩みが吹っ切れましたか？」

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho250"]
[OnName num="Shiho"]
I was no longer troubled. "You have a good face at ....... Have you blown off any of your worries?"
[cpg cn=true]


You are very perceptive, Shiho. That's almost the right answer.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』





[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa062"]
[OnName num="Azusa"]
I was so surprised to hear that your sister called me up.　I can't believe your sister called me."
[cpg cn=true]


So, a place that is not popular. The classroom at the edge of the school.
[cpg]


There, just the two of us, me and Azusa. I've already decided what I'm going to say.
[cpg]


In other words, "I love it". But ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Azusa063"]
[OnName num="Azusa"]
I'm not ready for that.　I'm not ready for it.
[cpg cn=true]


He is shy and flinches. It's hard to make a start when he reacts like this.
[cpg]


It's like I'm supposed to confess my feelings to him.
[cpg]


I don't think that's very favorable. ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="Rin_male"]
I like you. Let's go out together, Azusa.
[cpg cn=true]


Now, what will happen? I don't think it's likely that Azusa will dump on me.
[cpg]


I was staring at Azusa while thinking, "What's going on?
[cpg]


What?　I thought you were expecting it.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Azusa064"]
[OnName num="Azusa"]
Gusu, Higu, I'm so happy. Sis. ......"
[cpg cn=true]


She hugged me tightly. And then ......
[cpg]





;//========================================
;//●ＣＧエロ（騎乗位で主人公の上で腰を振るヒロイン３。ヒロイン３は処女喪失。床でセックスする）ev_24
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン３
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="Rin_male"]
I was just a little bit.
[cpg cn=true]


 I was pushed down and Azusa leaned on top of me.
[cpg]


This is not good. Azusa is a hermaphrodite, so there are contingencies.
[cpg]


;**【ＣＧ】 ev_24_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sAzusa014"]
[OnName num="Azusa"]
I love you, too. I love ...... you, sister."
[cpg cn=true]


[OnName num="Rin_male"]
Wait, let's calm down a bit, Azusa.
[cpg cn=true]


I refused like that and Azusa looked as if she had come to her senses.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************


And then we finally decided to go out with each other.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


That night. I decided to report it to Honoka.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka059"]
[OnName num="Honoka"]
I told her that I was going to go out with Azusa. With Azusa-san. ...... I see."
[cpg cn=true]


I knew she was upset. I'm not saying that I'm unaware of Honoka's feelings.
[cpg]


But I knew I had to tell Honoka.
[cpg]


She was the one who had supported me all this time.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka060"]
[OnName num="Honoka"]
But, Azusa-san, do you know?　That she's going to become a girl. ......
[cpg cn=true]


Oh, I don't know. if I told you that.
[cpg]


I probably didn't. Not good, this is pretty bad. ......
[cpg]


I'm sure I told Shiho about it. Honoka has known for a while.
[cpg]


So I kind of thought Azusa knew too, but she doesn't.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





I spent a sleepless night.
[cpg]


Azusa might not like me. If she knew that I would become a woman.
[cpg]

;//asd
More than anything, I was worried that I had lied to her.
[cpg]


She might get angry with me for that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa079"]
[OnName num="Azusa"]
"Good morning, ....... What are you doing here so early in the morning?"
[cpg cn=true]


I met Azusa before class started and decided to talk to her.
[cpg]


There were other students around. I whispered to her.
[cpg]



[OnName num="Rin_male"]
"...... I have something important to tell you. I'm going to be a girl in a year."
[cpg cn=true]


I explained everything. I explained everything.
[cpg]


The reason why I originally came to the school dressed as a woman is because of this.
[cpg]


I felt sorry for not telling Azusa about it for a long time. ......
[cpg]


When Azusa finished listening to the whole story, she looked indifferent.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa080"]
[OnName num="Azusa"]
What, is that what this is about? I thought so, since it's this school.
[cpg cn=true]


What do you mean, I'm the one who said that. It's a bit disconcerting, isn't it?
[cpg]


;//ＢＫ

;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************


[SE f="se000"]
;//【ＳＥ】『走る』


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

To her, my gender is not important.
[cpg]


Azusa herself is a hermaphrodite.
[cpg]


Somehow, my worries seem to be tiny. ......
[cpg]


And then I realized that it was already late in the evening. It was time to go home.
[cpg]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa096"]
[OnName num="Azusa"]
"Come on, sister, let's go home together."
[cpg cn=true]


She had always been a sticky partner, but since we started going out, she became even more explicit.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa097"]
[OnName num="Azusa"]
Why don't you come over to my place on your next day off?　Let's play together until curfew at the dormitory."
[cpg cn=true]


Come to think of it, Azusa was not a dorm student.
[cpg]


I wondered if that was possible, or if she would do something reckless to me again.
[cpg]


While I was thinking that, I saw Shiho-san walking in front of me.
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shiho251"]
[OnName num="Shiho"]
Good evening. rin-san and ...... Azusa, was it?"
[cpg cn=true]


It hurts a little to look at you. I haven't talked to Shiho much lately.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Shiho252"]
[OnName num="Shiho"]
I've seen the two of you together a lot lately.
[cpg cn=true]


I was troubled because I felt like I was being told a roundabout sarcastic sarcasm.
[cpg]


But Azusa didn't care. On the contrary, she was just saying ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Azusa098"]
[OnName num="Azusa"]
I'm going to go out with your sister. I'm going out with your sister.
[cpg cn=true]


She even said something like this. There is nothing to be afraid of.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


And by the time the weekdays passed and the holidays ...... came, the rumor had spread throughout the school.
[cpg]


People around me think I'm gay, but I'm not.
[cpg]


But it's hard to say that I'm heterosexual. What is our relationship?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka061"]
[OnName num="Honoka"]
I was told, "You have a date with Azusa today, don't you?　Have a good day."
[cpg cn=true]



[OnName num="Rin_male"]
......How did Honoka know?"
[cpg cn=true]


I can imagine that Azusa was probably very happy to tell everyone about it.
[cpg]


I can imagine it. I can see it. That's how it spread throughout the school, I'm sure.
[cpg]


Well, it can be said that it's a quick story, so it's okay. ......
[cpg]



[OnName num="Rin_male"]
Well then, I'm off.
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
Honoka had a complicated expression on her face. It was a really complicated expression.
[cpg]


She was congratulating me, but also jealous and worried about me.
[cpg]


It's going to be a pain in the ass for Honoka, isn't it? But it can't be helped.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//このシーンでの梓の立ち絵は私服です

I had already taken care of all the procedures for the outing yesterday, which was a lot of work.
[cpg]


I headed for the station where Azusa was waiting for me.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa099"]
[OnName num="Azusa"]
I was so worried about her, I couldn't help it.　Oh, did I keep you waiting, sister?
[cpg cn=true]


That's a line that the person who made me wait would say. Why are you the one who came before me saying that?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


I was thinking about that, but I was taken to Azusa's house right away, not only in the name of date.
[cpg]



The house was very spacious, and I imagined that she must be quite a lady.
[cpg]



;//移植のためシーンをカットしています


;//ＢＫ

;//移植のためシーンをカットしています


;//ＢＫ

And after chatting at home for a while, we went out for shopping at Azusa's suggestion: ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa126"]
[OnName num="Azusa"]
She said, "It's tough for you because you have a curfew, doesn't it? She won't have much time to play with me anymore."
[cpg cn=true]


That's true. I have to be back by the evening.
[cpg]




[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa127"]
[OnName num="Azusa"]
"Ah, here it is. How do I look?
[cpg cn=true]


I was tempted to say, "Well, it's just a store," but I gulped.
[cpg]


What is this?　A cosplay store?　I didn't know there was such a thing in this town.
[cpg]


I mean, is this something Azusa would wear?　No way, right? That means ......
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Azusa128"]
[OnName num="Azusa"]
I'll help you find something that suits you, sister, so please come with me."
[cpg cn=true]


Right? I had a bad feeling about this.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


So after shopping, we went straight to Azusa's house.
[cpg]


Azusa's parents didn't even question the contents of the bag. I wonder if they know that she is a reckless type from the start.
[cpg]




[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Azusa129"]
[OnName num="Azusa"]
Wow, it suits you so well!　You're the quintessential sister!"
[cpg cn=true]


I felt like I lost something when I put on the costume that looked like a magical girl.
[cpg]


I think Azusa looks better than me. This kind of thing.
[cpg]



;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





While I was doing this, the evening came and I had to go back to the dormitory.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Azusa140"]
[OnName num="Azusa"]
I was sorry to leave, but I had to say goodbye for now. Goodbye, sister.
[cpg cn=true]


With that, I headed back to the dormitory.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]

Honoka was in the dormitory.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka062"]
[OnName num="Honoka"]
Ah, welcome back. How was it?　Did you have fun?
[cpg cn=true]


Honoka seemed to have recovered from her rejection.
[cpg]


And she genuinely cares about us.
[cpg]



[OnName num="Rin_male"]
It was fun, maybe even ...... tiring."
[cpg cn=true]


If I said I was tired, Honoka would realize what I was doing. I guess I said too much.
[cpg]


But I have to think about it too. What kind of relationship will I build with Azusa from now on?
[cpg]


What kind of relationship do I want to have with Azusa? I have to make it clear.
[cpg]


I have to think about whether I want to continue such things in the future.
[cpg]



;//■選択肢
[switch]
[case "I'm fine with the way things are."]
	[swap]
	[jump target="*select06_1"]
[case "I don't want to be carried away by the momentum."]
	[swap]
	[jump target="*select06_2"]
[endswitch]




1, I'm fine as it is.
2. I don't want to be influenced by the momentum.



;//==============================
;//２、勢いに流されたくない
*select06_2
[jump storage="ep008.ks" target="*select06_2"]


;//==============================
;//１、このままでいい
*select06_1
[jump storage="ep009.ks" target="*select06_1"]
