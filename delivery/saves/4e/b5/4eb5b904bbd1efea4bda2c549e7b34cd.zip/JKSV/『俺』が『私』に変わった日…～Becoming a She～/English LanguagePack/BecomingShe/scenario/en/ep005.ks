




;#################################################
*Ep005|詩歩の嘘
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


*select05_1|Shiho's Lie

[SCENE id=5]





[OnName num="Rin_male"]
......I don't hate you, Shiho.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I bit down. Shiho rolled her eyes.
[cpg]


What should I say from here? It's obvious, I don't need to worry about it anymore.
[cpg]


[OnName num="Rin_male"]
So, please don't lie to me. You're really peculiar, aren't you?"
[cpg cn=true]


Pursue the lie. If you take that act alone, it seems like a negative thing.
[cpg]


But it depends.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho148"]
[OnName num="Shiho"]
Why are you so ...... kind?"
[cpg cn=true]


She seems to have felt it as kindness.
[cpg]


I'm so happy about that alone.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shiho149"]
[OnName num="Shiho"]
'Thank you ....... Really, I seem to like you."
[cpg cn=true]



;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//ＢＫ

Then, Shiho confided in me.
[cpg]


The peculiar nature of being dependent on love,...... or, to shrink it, the nature of being in love.
[cpg]


But now we're fine. She wouldn't cheat on me either, I thought.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Honoka058"]
[OnName num="Honoka"]
'...... you've really become lovers. I can't believe she's visiting me in my underclassman's room."
[cpg cn=true]


Shiho-san comes to my class during lunch break.
[cpg]


She wanted to spend as much time as possible with me, a man.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Shiho165"]
[OnName num="Shiho"]
Yes. Me and rinsan have been together for a long time."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


The days passed as lovers.
[cpg]


Summer eventually turned into autumn ...... and then.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


The first thing you need to do is to make sure that you have the right tools to do the job.
[cpg]


The first thing you need to do is to get a good idea of what you want to do. I had to adjust the size of my pads.
[cpg]


They should not suddenly get bigger, nor should they get smaller.
[cpg]


I had to gradually make the pads thinner and thinner. ...... I was baffled.
[cpg]


It was like cutting hair.
[cpg]


It's like cutting your hair, in that you have to reduce it at the same time as it expands.
[cpg]


When I told Poet Po about ...... the foolishness of it, she laughed at me.
[cpg]


The time limit is getting closer. I was feeling it firsthand.
[cpg]


I often felt anxious, perhaps due to the effects of hormonal balance.
[cpg]


Every time I felt anxious, I was comforted by Ms. Shiho. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************


It is completely winter. I was to spend my last New Year's Eve as a man at my parents' house.
[cpg]


My parents were very unconcerned. They don't even try to avoid talking about how I'm going to become a woman next year.
[cpg]


I can understand if they avoid it. I can understand if they want to spend the year as if nothing happened.
[cpg]


I'm not afraid to say things that I'm not ready for either.
[cpg]


They say things like, "How's your love life?
[cpg]


But I want to see my grandchildren, or ...... I'm really not kidding.
[cpg]


When my dad started talking about breasts, I was like, "Quicksilver.
[cpg]



[OnName num="Rin_male"]
I said, "...... enough!"
[cpg cn=true]


I'm a woman and I'm becoming a woman, but I'm just going to be laughed at.
[cpg]


Oh my God, what kind of family is this? This is the kind of family I'm talking about.
[cpg]


The kind of parents who would send me to a girl's school just because I was about to become a woman.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



And now that winter has passed, it's almost spring. There are only a few days left that I can be a man.
[cpg]


On Valentine's Day, Shiho did her best.
[cpg]


She is a good cook. I thought that chocolates are the same no matter who makes them.
[cpg]


But she made a cake. I thought she was too enthusiastic, but I enjoyed it.
[cpg]

;//asd
Shiho said that this might be the last time she can give me a gift as a man.
[cpg]


I thought that was true, so I prepared for White Day.
[cpg]


I'm going to be a woman soon and I should be able to cook. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


Then it would be summer again. The sexual inversions had begun in my body.
[cpg]


I was put back in the hospital for the rest of the year on absolute bed rest.
[cpg]


It's tough not being able to take classes properly for a month, I thought .......
[cpg]


However, I was able to endure the one-month period while thinking about Shiho-san.
[cpg]


The days in the hospital passed. And finally, I become a complete woman......
[cpg]



[VOICE f="Shiho166"]
[OnName num="Shiho"]
I can't believe that she became a girl,...... but I can't believe it."
[cpg cn=true]


From the day I was able to visit, Shiho-san came to see me.
[cpg]


I can go back to the girl's school without thinking about it anymore.
[cpg]


But I was not sure if I could still be a lover with Shiho.
[cpg]


;//（女）
[VOICE f="Rin001"]
[OnName num="Rin_female"]
Shiho-san ...... will you love me too now that I'm like this?"
[cpg cn=true]


Shiho smiled, remaining unconcerned.
[cpg]


[VOICE f="Shiho167"]
[OnName num="Shiho"]
Yes," she said. Of course I do. You are the only person who understands the real me.
[cpg cn=true]


A few more days passed.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


I and Shiho both graduated from the school, and we dated again.
[cpg]


Two years have passed since those days at the school. How quickly it has passed.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho168"]
[OnName num="Shiho"]
The only thing I'm worried about is that I can't have a child with ......rin-san.
[cpg cn=true]


The only thing that worries me is that I can't have a child with Mr. Approval.
[cpg]


We are both women, normally speaking, we can't have children.
[cpg]


But I have a special surprise for you. I'll save that for later.
[cpg]


For now, I just enjoyed the date.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=100]


;//========================================
;//●ＣＧエロ（貝合わせ。ヒロイン１が主人公の足を持っている）ev_18
;//人物１：主人公（女）
;//服装１：裸
;//人物２：ヒロイン１
;//服装２：裸
;//場所　：主人公の家＿主人公の部屋
;//時間　：夜
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[window target=true]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="Rin_female"]
My parents are coming home late today. What should I do? ......"
[cpg cn=true]


We have been dating for two years, but we are polite to each other.
[cpg]


I can't change it if Shiho-san doesn't become a normal talker first.
[cpg]


But it's also Shiho's identity. ......
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=12 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sShiho015"]
[OnName num="Shiho"]
'Yes. Let's stay together for the rest of the day."
[cpg cn=true]


As I was thinking this, Shiho-san replied happily.
[cpg]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Shiho191"]
[OnName num="Shiho"]
I would like to have a baby with Mr. ......rin."
[cpg cn=true]


Shiho said the same thing again.
[cpg]


Today is the anniversary of exactly two years since we started dating. I think it's time to reveal it to her.
[cpg]


It may be too early for Shiho to become a mother, but let's ...... say it.
[cpg]


;//（女）
[VOICE f="Rin018"]
[OnName num="Rin_female"]
I'm saving my sperm, actually. When I was a man."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho192"]
[OnName num="Shiho"]
What ...... do you mean?"
[cpg cn=true]


I wonder if it is in your knowledge, Shiho. I think there is, but it is not immediately connected to reality.
[cpg]


I think there is, but it may not be immediately connected to reality.
[cpg]


;//（女）
[VOICE f="Rin019"]
[OnName num="Rin_female"]
I think it is possible to have a child if you want to. I don't think I could.
[cpg cn=true]


It's like having a child with yourself. That would be a quandary.
[cpg]


There would be genetic problems. Something must go wrong.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Shiho193"]
[OnName num="Shiho"]
The actuality is, "Really? ......!　Can I have a baby with you?
[cpg cn=true]


Yes, I answered. I was sobbing.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


And then she covered me again. I guess I will have to live with her constitution for the rest of my life.
[cpg]


But that's okay. It's something I've decided to live with for the rest of my life.
[cpg]


Then there is nothing to hesitate about. Our future is open.
[cpg]


I won't lie about my feelings either. That's what I've decided.
[cpg]

[SCENE id=13]

;//ＥＮＤ：ヒロイン１ハッピーエンド
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


