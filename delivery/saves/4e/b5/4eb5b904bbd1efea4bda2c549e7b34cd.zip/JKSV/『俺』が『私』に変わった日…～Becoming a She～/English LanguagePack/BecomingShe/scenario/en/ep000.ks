
*start



;//性反転症の「俺」が「私」になるまで　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています


;//以下音声あり
;//稟（女）　立ち絵なし
;//詩歩　　裸　私服　制服
;//穂乃香　裸　私服　制服
;//梓　　　裸　私服　制服

;//以下音声なし
;//稟（男） 女教師 医者 女子学生
;//男 男Ａ 男Ｂ 男Ｃ


;#################################################
*Ep000|Moving into the Academy
;#################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag ChaBad = 0]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


Summer. A transfer student. I think it is somewhat conspicuous that schoolmates who do not meet each other at the same time as entering the school, but come from the middle of the school year.
[cpg]


[OnName num="Rin_male"]
I'm Hoshina Rei. I'm transferring in today.
[cpg cn=true]



[SE f="se027"]
;//【ＳＥ】『ざわつき　女子の声』

The class was in an uproar. The only voices in the room were female voices. It's no wonder, this is a girl's school.
[cpg]


They say things like, "She's cute," "She's beautiful," "I think I'm going to fall in love with her," and so on.
[cpg]


All of those voices were from female students.
[cpg]


If I were a girl, I would probably feel happy if I was called pretty.
[cpg]


I would also be happy to be called beautiful, although I have a little problem with ...... that I think I'm going to fall in love with.
[cpg]


[OnName num="Rin_male"]
I bowed to her and said, "...... Pleased to meet you."
[cpg cn=true]


My hair flutters as I bow with a bow. It's a wig.
[cpg]


Yes, my first name is originally "I". It would be a little strange to use it in this women's school.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

I am a man. Not so much a man, but a man in terms of gender.
[cpg]


Sadly, I transferred to the women's school as a man.
[cpg]


I have a strange disease called "degeneration. It's not so much a disease, but more of a peculiar constitution.
[cpg]


There are various kinds of this peculiar constitution. There is "partial degeneration," in which a part of a person's body is not the original gender.
[cpg]


Among them, there is a special case called "sex reversal syndrome.
[cpg]


[OnName num="Rin_male"]
"Oh no ......, it's only been a year!"
[cpg cn=true]


That's what my body was. According to the doctor's explanation, after one year, the sexual reversal syndrome begins.
[cpg]


From there, over the course of a month or so, my body would gradually change and become a woman. ......
[cpg]


And they say that the signs show up before that month. Specifically, the breasts start to swell up in the middle of the process.
[cpg]


It's hard to believe. However, I didn't think I was being lied to as far as my parents' reaction was concerned.
[cpg]


So far, so good. It's just hard to believe, and you can take it on yourself whether it's a lie or not.
[cpg]


If it's a lie, it's a lie, and if it's true, you just have to be prepared. But the story did not end there.
[cpg]


[OnName num="Doctor"]
If you suddenly change into a woman, your daily life will be affected.
[cpg cn=true]


[OnName num="Doctor"]
So what do you think?　How about transferring to a women's school?
[cpg cn=true]


[OnName num="Rin_male"]
...... Yes?
[cpg cn=true]


Everyone around me was in favor of transferring to a women's school. I was the only one who was against it.
[cpg]


I was only a child, so I didn't have much of a right to refuse.
[cpg]


My parents were going ahead with the procedure, and my mother was even teaching me how to put on makeup.
[cpg]


I was surprised when I saw myself with makeup on for the first time.
[cpg]


I thought to myself, "...... isn't this a beautiful girl?　I thought to myself, "This is a beautiful girl.
[cpg]



;//========================================
;//●ＣＧ非エロ（鏡の前に立つ主人公。制服をたくし上げる。女物の下着が膨らんでいる）ev_03
;//人物１：主人公（男）
;//服装１：制服
;//場所　：主人公の家＿主人公の部屋
;//時間　：朝
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_sl"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="Rin_male"]
I thought, "...... woo......."
[cpg cn=true]


But then I also thought at the same time, "I'm not dressed like this.......
[cpg]


I'm sure I'm going to have to live my life lying to everyone.
[cpg]


Can I really do it? I'm getting to the point where "I can't" is not good enough.
[cpg]


I don't think I can do it even if I go to .......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


And yet, here I am.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


I took my seat and went to class. There are girls on my right and on my left.
[cpg]


Girls in front of me, girls behind me. There must be girls taking classes on the upper and lower floors.
[cpg]


I was the only boy. I think, "Wow.
[cpg]


I can hear the slightest whisper, but I'm sure they're talking about me. ......
[cpg]


I'm not happy about it. If I could, I'd tell them I'm a guy right now and fly back to my old school.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

Classes go on and on. I'm thinking about a lot of things at the same time.
[cpg]


Is it okay if I just leave it like this? Will they find out? If I was found out, would it be a crime?
[cpg]


All these thoughts lead me to the goal of "I have no choice but to accept the situation as it is.
[cpg]


The situation is not so small that I alone can go against it.
[cpg]


It would be a lot of work just to go back to the school. I finally think that I have no choice but to endure.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


There are only a few people and things I can rely on in this school.
[cpg]


There is only one person who knows my gender, but ......
[cpg]


I didn't feel like relying on that person, so I wandered around the school.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


I found myself on a rooftop. I'm confused to the point where I'm thinking, "Uh, when did I go up the stairs?　I am confused to the extent that I think
[cpg]


I'm not so much confused as I am tired. What awaits me is not only the view from the rooftop overlooking the city ......
[cpg]


I was not the only one. There was a beautiful woman there.
[cpg]



[VOICE f="Shiho001"]
[OnName num="Shiho"]
She said, "I'm ...... meeting you for the first time, aren't I? Are you a transfer student by any chance?"
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（屋上で二人話す。二人柵にもたれかかってるような感じ）ev_01
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン１
;//服装２：制服
;//場所　：学園屋上
;//時間　：夕方
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_sl"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//[SE f="se029"]
;//【ＳＥ】『風の音』




[VOICE f="Shiho002"]
[OnName num="Shiho"]
Isn't it a nice view? It's my favorite place.
[cpg cn=true]


It is indeed a nice view. But in front of this person, it's all a bit hazy.
[cpg]



[VOICE f="Shiho003"]
[OnName num="Shiho"]
I'm Shiho Yahata. May I ask your name?
[cpg cn=true]


My name is Shiho Yahata. A mere self-introduction. I would have said something similar to my classmates in the classroom.
[cpg]


I don't know why, but when this person says it, it sounds so beautiful. Is it the beautiful name or the voice?
[cpg]


[OnName num="Rin_male"]
I'm Hoshina Inari. Yo, nice to meet you.
[cpg cn=true]


My self-introduction came out stuttering, and I was even more nervous than when I said it in the classroom.
[cpg]


 The another's daughter, appears more than usual.
[cpg]



[VOICE f="Shiho004"]
[OnName num="Shiho"]
The name of the person is "Hoshina Kakari, Ms. ...... is a beautiful name, isn't it?
[cpg cn=true]


They say my name is beautiful. For all that, my introduction is far from beautiful.
[cpg]


I'm certainly not dissatisfied with my name. However, ......
[cpg]


I'm a little resentful of the fact that I have a name that can be used by both men and women. I'm a little resentful of that.
[cpg]



[VOICE f="Shiho005"]
[OnName num="Shiho"]
 I feel about this school.　I hope you like it.
[cpg cn=true]


I think I would like it if there is a beautiful woman like you.
[cpg]


I don't have the courage to say such a thing, but she is beautiful enough to make me think of such words.
[cpg]


I nodded. Then, Shiho smiled. She has a beautiful smile, too.
[cpg]



[VOICE f="Shiho006"]
[OnName num="Shiho"]
I'm graduating next spring. I love this school so much that I'm a little sad to leave it.
[cpg cn=true]


I'm a sophomore now, and you're a senior. That's right, I don't want this aura to come out from someone my age.
[cpg]


I can never be this kind of person. I'm a man by nature, and I don't think I can be this kind of feminine woman.
[cpg]


If I'm going to have my happiness, I guess I'll just have to accept being a woman. ......
[cpg]


Thinking about this makes me feel guilty that I am deceiving her by being a transvestite at this very moment.
[cpg]



[VOICE f="Shiho007"]
[OnName num="Shiho"]
'...... you look a little pale. Are you tired from just moving in?"
[cpg cn=true]


A senior who is concerned about me saying so. I feel somewhat sorry.
[cpg]


I feel sorry for myself, even though it is my own fault that I am looking so pale.
[cpg]


Even if it is not my fault, I am sure that I am deceiving others in this school.
[cpg]


I was mentally exhausted by dressing up as a woman, so I was glad to hear my senpai's words.
[cpg]


[OnName num="Rin_male"]
"...... I think I'm going to like this academy too. Yahata-senpai."
[cpg cn=true]


When I said that, Senpai laughed again.
[cpg]


Did I say anything interesting? I don't think so.
[cpg]



[VOICE f="Shiho008"]
[OnName num="Shiho"]
I said anything. I'm not a stranger to you. We're all friends in the same school.
[cpg cn=true]


He even called me a friend. I am so touched by his thoughtfulness.
[cpg]


I have to deceive such a good person from now on.
[cpg]


I couldn't stand it any longer and tried to leave.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[OnName num="Rin_male"]
I've got some business to attend to. I have some errands to run, so I'll see you now."
[cpg cn=true]


With that, I started to walk away. Then, a senior called out to me.
[cpg]


I turned around. I turned around and heard my senior say in her beautiful voice, "Next time we meet, please walk away and call me a poet.
[cpg]



[VOICE f="Shiho009"]
[OnName num="Shiho"]
When you see me again, please call me Shiho. Bye.
[cpg cn=true]


I can't call such a polite person by his first name.
[cpg]


I bowed and ran away from there.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************


[OnName num="Rin_male"]
......She was a beautiful person."
[cpg cn=true]


Out of the school, in the student dormitory. I'm going to live here from now on.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
What's sobering is that I have a roommate.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
I already know her name. It's Kitami Honoka.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka001"]
[OnName num="Honoka"]
Are you still depressed?　You'd better give up, haha.
[cpg cn=true]


The person who laughs off my situation says I should give up.
[cpg]


What he means by that is that he knows who I am.
[cpg]


He says that the school has already explained to him that he can't deceive about my gender until he is my roommate.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka002"]
[OnName num="Honoka"]
I'm glad to hear it, since it's so rare in our school. That's very rare in our school, so I'm glad.
[cpg cn=true]


Of course it's unusual. It's an all-girls school.
[cpg]


 I was a little confused by Honoka-san's way of saying it, but I thought so.
[cpg]


The actuality that there are men in the mix, even though it's rare?　No way. How much easier would that be?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka003"]
[OnName num="Honoka"]
But it takes a lot of guts to live with a boy. No pun intended.
[cpg cn=true]


I know. ...... You're so cheerful, you're kind of off the pace.
[cpg]


I also know that if you're not this bright, you probably won't get through it.
[cpg]


...... I guess I should say hello at least one more time. I did say hello at the academy.
[cpg]


[OnName num="Rin_male"]
I've already said hello to you at the academy.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka004"]
[OnName num="Honoka"]
Honoka, it's fine. Honoka, you're a stranger, aren't you?"
[cpg cn=true]


The same thing as someone else, but the impression you get is quite different.
[cpg]


 I got the feeling that Shihosan's manners of strangers were taking care of me.
[cpg]


I'm sure she's concerned about me too,......, I know that.
[cpg]


[OnName num="Rin_male"]
All right, Honoka. From now on, I think there will be times when only Honoka will be relied upon.'
[cpg cn=true]


They laughed at me when I said it with a serious face. Maybe they laughed at me because I had a serious face.
[cpg]


And while laughing, he told me not to worry about it.
[cpg]


I don't know if I should be concerned about it. The only people who know who I am are Honoka and some teachers, so I have to rely on them. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka005"]
[OnName num="Honoka"]
'Well, it doesn't feel bad to be depended on. But maybe you should relax your shoulders more.
[cpg cn=true]


Shoulder strength, huh? I've never slept in the same room with a girl before.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

What will happen to me from now on?
[cpg]


I have a bad feeling about it. And I hope this premonition will come true.
[cpg]


Being the only guy in a girl's school is a kind of dreamy situation.
[cpg]


Even though it's not what I want, I have no choice but to accept it. Maybe.
[cpg]

[jump storage="ep001.ks" target="*start"]

