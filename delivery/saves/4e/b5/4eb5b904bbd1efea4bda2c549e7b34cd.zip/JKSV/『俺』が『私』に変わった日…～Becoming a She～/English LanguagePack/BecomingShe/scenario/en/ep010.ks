
*start


;#################################################
*Ep010|The Most Important Thing is Honoka
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=10]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

[stflag ChaBad = 0]
[if exp={ isSystemFlagsEnabled( "sysflg_bad") }]
[stflag ChaBad = 1]
[endif]

*select04_2|一番大事なのは穂乃香

[SCENE id=10]


After thinking about it, I decided. The most important person is Honoka.
[cpg]


I don't know how many times she has saved my life. I'm not going to forget about you, Honoka.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[OnName num="Rin_male"]
I haven't forgotten you, Honoka.
[cpg cn=true]


Honoka looked surprised.
[cpg]


She probably thinks that time was a mistake.
[cpg]


But for me, it's an event I just can't forget.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka068"]
[OnName num="Honoka"]
I said forget it, didn't I? I told you to forget it, didn't I?"
[cpg cn=true]


I don't think she understood how I felt. Let me put it another way.
[cpg]


It's not "I haven't forgotten. I'm going to be more proactive. ......
[cpg]



[OnName num="Rin_male"]
I don't want to forget. It's about me and Honoka."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
Honoka's face is bright red. But, however,......
[cpg]


soon turned dark. I wonder what is making her look that way.
[cpg]


She should have been a more cheerful person. The girl I knew was like that.
[cpg]



[OnName num="Rin_male"]
I don't want to see her gloomy face anymore. Especially since I like her so much.
[cpg cn=true]


Honoka's eyes moistened as she said, "That's .......
[cpg]


I wonder if Honoka also liked me. Is that being self-conscious?
[cpg]


I was thinking that, and then Honoka started to talk about it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka069"]
[OnName num="Honoka"]
I like ...... too. I've always liked you, I've always liked you.
[cpg cn=true]


A love affair. I wonder if it's okay that they got together so quickly.
[cpg]


With this in mind, I approach Honoka to kiss her.
[cpg]


I thought it would be OK under this circumstance.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHonoka003"]
[OnName num="Honoka"]
I'm not going to do it. Let's stop.
[cpg cn=true]


I couldn't agree to that. No questions asked.
[cpg]






[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHonoka004"]
[OnName num="Honoka"]
If we do this, ...... will be irreversible."
[cpg cn=true]


I think it's kind of an exaggerated word. I don't know what he intends to say.
[cpg]


Someday I'll have to know what Honoka is worried about, but ......
[cpg]


Come to think of it, didn't she go to the hospital sometime?　I heard that this school is a bunch of peculiarities.
[cpg]


If that's the case, maybe Honoka has some kind of idiosyncrasy too.
[cpg]



;//========================================
;//●ＣＧエロ（ヒロイン処女喪失。正常位。ヒロインは涙ぐみながらも嬉しそう）ev_39
;//人物１：主人公（男）
;//服装１：裸
;//人物２：ヒロイン２
;//服装２：裸
;//場所　：学生寮室内
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]



She seemed to be overly nervous.
[cpg]


I still put my lips to Honoka's. "Chuchu!
[cpg]


;**【ＣＧ】 ev_39_a ***********************
[CG id=15 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sHonoka005"]
[OnName num="Honoka"]
I put my lips to Honoka's. "Chuu......, mmm."
[cpg cn=true]


They continued to kiss each other on the mouth, as if to confirm their mutual presence.
[cpg]


However,...... I felt uncomfortable with Honoka's nervousness the whole time.
[cpg]





;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


There I met Shiho. She was probably going to be late too if she didn't hurry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho253"]
[OnName num="Shiho"]
She said, "Good morning. You look so happy, Mr. Kiuchi.
[cpg cn=true]


I think Honoka said something similar to that to me just yesterday.
[cpg]


The words "getting the girlfriend of your dreams" are not enough.
[cpg]


In other words, there is a difference between "getting married to the person you love" and "getting a girlfriend. The former is happier.
[cpg]


I told her passionately about that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho254"]
[OnName num="Shiho"]
I said, "That's a happy thing. I'm cheering for you behind your back.
[cpg cn=true]


Yes!　I replied cheerfully and headed to the classroom.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


[OnName num="female_student"]
I was so happy to see her.
[cpg cn=true]


takanashi told me the same thing. That's the third person.
[cpg]


The first is the one that I'm going to use. I'm not going to reveal everything here.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』


From the side, it's a love affair between women, so I guess it's better to hide it to some extent.
[cpg]


I told Shiho, but from now on I will be careful not to tell her as much as possible.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


It was a little too late for me to think about it. For some reason, our thing had become a class rumor.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka097"]
[OnName num="Honoka"]
"Why did you tell ......稟, maybe you told someone?"
[cpg cn=true]


I didn't. I didn't. I told Shiho. I told Shiho, but I don't think she's the type to spread rumors around.
[cpg]


But I should check with the person in question just in case. If she did spread the word, it's good to be angry.
[cpg]


......Honoka doesn't seem to be too happy about the rumors.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



[SE f="se000"]
;//【ＳＥ】『走る』



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho255"]
[OnName num="Shiho"]
What's wrong?　Mr. Inari, you're so bloody ......."
[cpg cn=true]


I asked him if he was the one who told on them. I asked him if he was the one who told everyone about it.
[cpg]


I can't think of anything else. But the poet is ......
[cpg]

;//asd
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shiho256"]
[OnName num="Shiho"]
No." Do I look like that kind of person?　I consider myself a very outspoken person, though."
[cpg cn=true]


I was wondering who in the world ...... was then, when I heard a whisper.
[cpg]


[OnName num="female_student"]
"That ...... girl, you know."
[cpg cn=true]


[OnName num="female_student"]
"The girls are so dirty ...... with each other."
[cpg cn=true]


I wonder if everyone can somehow tell by the atmosphere.
[cpg]


But I felt like it wasn't so bad to be the center of attention.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka098"]
[OnName num="Honoka"]
The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg cn=true]


I replied helplessly, "Yes, I guess so.
[cpg]


Tomorrow, the rumors will probably be even more widespread.
[cpg]


I'm sure Azusa will hear about it,......, and I wonder what her reaction will be.
[cpg]

[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Azusa213"]
[OnName num="Azusa"]
I heard it, sister!　Is this the one who is the thief cat who steals your sister?"
[cpg cn=true]


Azusa who stands in the way. I knew this was going to happen. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Honoka099"]
[OnName num="Honoka"]
Well, you are ...... Shijo-san, right?
[cpg cn=true]


A hazy Honoka. I've had similar things happen to me.
[cpg]

;//[t_move pos=R 動揺]
Azusa is even angrier when her name is mistaken.
[cpg]


She's starting to say that she won't give me her sister and that she's mine.
[cpg]


It's bad, isn't it? It's even more obvious, isn't it? I was thinking like that.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Honoka100"]
[OnName num="Honoka"]
I was thinking like that. I'm your girlfriend.
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
He said that and crossed his arms with me. It was a bold move.
[cpg]


Azusa was shocked and trembling.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Azusa214"]
[OnName num="Azusa"]
She was shaking in shock. You don't approve of her, do you?
[cpg cn=true]


I feel sorry for her, but I can't help it. If you don't understand me now, ......
[cpg]


With that in mind, I kissed her. Many students were watching.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka101"]
[OnName num="Honoka"]
I was like, "Oh my God, this was a great day. Next to yesterday, it was probably the most important day of my life."
[cpg cn=true]


Yeah, that's right. I didn't think this would happen either.
[cpg]


I don't know if it was good or bad that Azusa was there, but either way, I was able to blow it off.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka102"]
[OnName num="Honoka"]
I'm having fun, Reiki. I'll never forget how you kissed me today.
[cpg cn=true]


She said something nice to me. We'll always be lovers from now on. But ......
[cpg]


[OnName num="Rin_male"]
I'm amazed you could say "girlfriend" on the spur of the moment. If I had said boyfriend, I would have been out."
[cpg cn=true]


I'll leave it to you," said Honoka, puffing out her chest.
[cpg]


I'm not sure what you mean by "leave it to me," but I do feel that the usual Honoka tension is returning.
[cpg]


I feel like I can do it now. The first thing you need to do is to make sure that you have a good idea of what you're doing.
[cpg]


[OnName num="Rin_male"]
I suggested, "Let's keep our voices down today.
[cpg cn=true]


I suggested that. But Honoka shook her head.
[cpg]


I was surprised that I didn't think it was a good idea to be brave,.......
[cpg]


I don't know, but there is still something that is disturbing Honoka.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


[SE f="se000"]
;//【ＳＥ】『歩く』



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shiho257"]
[OnName num="Shiho"]
Good morning. rin-san ...... oh my."
[cpg cn=true]


I and Honoka tried to commute to school holding hands.
[cpg]


It will not look like we are just good friends. This is why it has become a fact rather than a rumor.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Honoka103"]
[OnName num="Honoka"]
The actuality is, it's not just a rumor, it's a fact. Senpai."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
Shiho was smiling without a hint of embarrassment.
[cpg]


I am sure she had some relationship with me too, but unlike Azusa, she was calm.
[cpg]


[VOICE f="Shiho258"]
[OnName num="Shiho"]
"Heh. I wish you both the best."
[cpg cn=true]


Shiho was honestly congratulating me. I was just happy.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se028"]
;//【ＳＥ】『学園のチャイム』





[OnName num="female_student"]
I was just happy. It wasn't so much a surprise, but I was still surprised.
[cpg cn=true]


Kotoyu-san and I. The two of us were talking during lunch break.
[cpg]


Earlier, the three of us, including Honoka, were talking together. ......
[cpg]


Honoka went to the bathroom. I asked her for advice.
[cpg]


[OnName num="Rin_male"]
She said, "Hey, Ms. Kotoyu, Honoka is not very flirtatious with me even though we've been ...... going out."
[cpg cn=true]


[OnName num="female_student"]
You mean she's not into flirting?
[cpg cn=true]


[OnName num="Rin_male"]
"...... Well. What do you think I should do?"
[cpg cn=true]


[OnName num="female_student"]
I don't know what to do, but you have to take the lead, don't you?
[cpg cn=true]


So be it. I'm the man, even though I'm the former.
[cpg]


But there's something that doesn't feel right. ......What's the reason why you don't like it when you're finally tied together?
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



;//========================================
;//●ＣＧエロ（女子トイレでこっそりセックス。背後から挿入。ヒロインは失禁する）ev_40
;//人物１：主人公（男）
;//服装１：制服
;//人物２：ヒロイン２
;//服装２：制服
;//場所　：女子トイレ
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sHonoka006"]
[OnName num="Honoka"]
"...... head, it makes me dizzy."
[cpg cn=true]




[VOICE f="sHonoka007"]
[OnName num="Honoka"]
I don't ...... like this, I don't like it."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


I spotted Honoka in the distance and ran up to her.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHonoka008"]
[OnName num="Honoka"]
I said, "...... sorry. I just don't feel like it today."
[cpg cn=true]


Even though the girls look like each other, what is it that they can't even hold hands?
[cpg]


The reason for this was frustrating to hear.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


I returned to the classroom before the chime rang and went to class. This time it was English.
[cpg]


[OnName num="female_teacher"]
Then translate here: ......, Kitami-san.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Honoka118"]
[OnName num="Honoka"]
Ha, yes."
[cpg cn=true]


Honoka was nominated to write on the board. She is a pretty good student.
[cpg]

;//asd
She is also good in quizzes and other tests. I thought I was going to be able to ......
[cpg]


I stopped with the chalk in my hand.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka119"]
[OnName num="Honoka"]
She said, "I'm sorry, ...... I don't understand."
[cpg cn=true]


It was no big deal. I just don't know what the problem is.
[cpg]


But I felt something was stuck. I almost knew the answer, but I felt like I couldn't get to it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="Rin_male"]
I asked her, "...... Honoka, are you hiding something from me?"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I asked. Honoka answered that it was nothing.
[cpg]


Of course. This is not the way to ask.
[cpg]


I thought I should ask her when I had more cards in my hand.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Back at the dormitory, it was time to go to bed.
[cpg]



[OnName num="Rin_male"]
I asked, "...... not in the mood today?"
[cpg cn=true]


That's kind of a bad way to ask this, too. It was probably a question I shouldn't have asked in the first place.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka120"]
[OnName num="Honoka"]
I was like, "...... Yeah, I'm sorry, I'm sorry. I'm sorry, I thought we were dating."
[cpg cn=true]



The first thing you need to do is to make sure that you have a good understanding of what you're getting into.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





 For some reason, I couldn't sleep right away that day.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』


[OnName num="Rin_male"]
I was sleepy, so I asked Honoka if she wanted to go out with me.
[cpg cn=true]


I was sleepy, so I asked Honoka to go ahead of me.
[cpg]


Then, just in time to be late, I met Shiho again.
[cpg]


I've seen this happen before, right? I'm sure you've heard of this before, but I'm sure you've heard of this before too.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho259"]
[OnName num="Shiho"]
Good morning. Mr. Approval."
[cpg cn=true]



I noticed. Oh well, her romantic nature hasn't been resolved.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[OnName num="Rin_male"]
"I'm sorry ....... I haven't been able to talk to you much lately.
[cpg cn=true]


I unintentionally apologize. Shiho-san giggles.
[cpg]


It makes me feel a little better when she laughs, but I'm sorry for what I'm doing. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho260"]
[OnName num="Shiho"]
It's okay. It's just that I'm back to where I was before and I want you to be happy."
[cpg cn=true]


I can't say anything else. You're so sweet, Shiho.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


Alright, I'm going to be happy with Honoka. I'm going to be happy with Honoka. I've got Shiho's support.
[cpg]


I took Honoka out again at the end of class.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



[SE f="se000"]
;//【ＳＥ】『歩く』





[VOICE f="Honoka121"]
[OnName num="Honoka"]
Where are you going to take her this time ......?　You won't do anything like before, will you?
[cpg cn=true]


Is he nailing her or asking her out? Maybe he was nailing me.
[cpg]


But no one can stop me from doing so. I can't do it myself.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHonoka009"]
[OnName num="Honoka"]
"This is a classroom where you don't use ......, right?"
[cpg cn=true]


I still don't like it in a roundabout way. Not too far-fetched.
[cpg]



[OnName num="Rin_male"]
I want to kiss you. I've always wanted to.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
I don't care if you call me shameless.
[cpg]


I am a man. I can't just dress up as a woman and throw myself into an all-girls academy and not do anything.
[cpg]


If you want to refuse, you can refuse. I won't let go.
[cpg]






I kissed her. I didn't care who saw us.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

I went out to the corridor with a nonchalant look on my face. There are not many people at the end of the large school.
[cpg]


I could only see a few female students in the distance. I'm fine, I'm fine.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHonoka010"]
[OnName num="Honoka"]
It's not okay. ......
[cpg cn=true]


I don't think there's any reason why she wouldn't be fine, but what does she care?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[SE f="se028"]
;//【ＳＥ】『学園のチャイム』


And after school.
[cpg]


I try to head straight to the student dormitory.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[OnName num="female_student"]
I was stopped by Ms. Kotoyu.
[cpg cn=true]


takanashi-san stopped me. I wonder what it is.
[cpg]


[OnName num="female_student"]
Flirting is fine, but don't get caught.
[cpg cn=true]


I see you've been seen at ....... Okay.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka134"]
[OnName num="Honoka"]
I'm not going home.　I'll leave you here.
[cpg cn=true]



[OnName num="Rin_male"]
I'm going to leave you here. I'm on my way. ......
[cpg cn=true]


I've got an ear on the wall. I'm not in the mood for this.
[cpg]


If it's your ears, but if it's your eyes, you can't fool them anymore.
[cpg]


And if they find out I'm a guy, I'm in big trouble.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka135"]
[OnName num="Honoka"]
What did you and Kotoyu-san talk about?
[cpg cn=true]


I was at a loss for an answer. If I told them that I had been heard and seen, it would make it hard for me to do anything in the future.
[cpg]


It wouldn't be nothing if I said it was nothing.
[cpg]



[OnName num="Rin_male"]
Did they teach you any tips on how to, um, ...... not get caught dressing up as a woman?"
[cpg cn=true]


Hmmm. That's an unreasonable answer. And at the end, he says, "I wonder?" I wonder.
[cpg]


But Honoka didn't pursue it any further.
[cpg]


She looked as if she had something else to worry about.
[cpg]



[OnName num="Rin_male"]
'......If you're worried about something, I can help you.'
[cpg cn=true]


But his face didn't change when I said that. Rather, she looked apologetic.
[cpg]


I wondered if she was getting more worried because of me rather than because of my inability to help her. ......?
[cpg]


I can only imagine, but that's how I felt.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

I was thinking about that, and soon it was nighttime.
[cpg]


Honoka was sleeping soundly. I didn't want to wake her up and attack her in her sleep.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（朝）******************************************************


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
A few days passed, and it was a holiday.
[cpg]


Honoka and I decided to go out on a date.
[cpg]


We haven't decided on a particular destination. For now, I'm thinking of going out of town from a nearby station. ......
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka136"]
[OnName num="Honoka"]
I can't wait to see you. I can't wait.
[cpg cn=true]


Even with such a crude plan, Honoka was pleased. I thought it was a good idea to make a suggestion.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『雑踏』

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
It was hard to go anywhere in town on a holiday because there were quite a few people.
[cpg]


We had lunch at one of the cafes. It was a chain restaurant, just like a student.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
I was happy to see the happiness that was so commonplace. I was happy to see Honoka, who was always cheerful.
[cpg]




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Honoka137"]
[OnName num="Honoka"]
Where should we go next?　I want to buy some clothes.
[cpg cn=true]


He says so with a sparkling smile. He doesn't look like he's straining.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, I bought clothes and stopped by general stores.
[cpg]


It's a typical, normal date with nothing special to say.
[cpg]


However, Honoka was leading the way, and there were many stores that a man alone would not be able to stop by.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se027"]
;//【ＳＥ】『雑踏』


And as the evening progressed, his expression turned just a little shadowy.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka138"]
[OnName num="Honoka"]
I'll never forget what happened today. I'll never forget today.
[cpg cn=true]


He said it again, "I'll never forget it. I don't think that's the first time I've heard that.
[cpg]



[OnName num="Rin_male"]
I'll never forget it. I won't forget it either.
[cpg cn=true]


I decided to head back to the dormitory without going into too much detail.
[cpg]


There was a curfew. I had to be home by then.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka139"]
[OnName num="Honoka"]
"Well, today was fun, wasn't it?
[cpg cn=true]


I think I had fun, too. But the feeling of discomfort inside me only grew stronger.
[cpg]


I wonder why Honoka is so sentimental.
[cpg]


...... With this in mind, I tried to press Honoka for a kiss, as it was an extension of our date.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHonoka011"]
[OnName num="Honoka"]
......Already."
[cpg cn=true]







[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************



[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]


[OnName num="Rin_male"]
'......Honoka doesn't want to do anything?　I thought you were holding back."
[cpg cn=true]


Honoka looks awkward. I don't want to say no but I have to, that's the kind of face I have.
[cpg]


I wish she would say one word of truth. I'm sure she has a peculiar constitution.
[cpg]


Is it still no good? I thought we'd gotten pretty close.
[cpg]



[OnName num="Rin_male"]
"Am I not good enough for you, ......?"
[cpg cn=true]


I'll give it one more push. Furthermore, Honoka's apologetic face, or what is it ......
[cpg]


The face became as if she couldn't stand it.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Honoka152"]
[OnName num="Honoka"]
'It's not fair,......, I won't be able to stand it.'
[cpg cn=true]



Honoka was holding back. It seems she can't kiss him for some reason after all.
[cpg]


 Or even flirting, even if it wasn't kissing...
[cpg]



;//========================================
;//●ＣＧエロ（騎乗位でセックス。何度も射精させられる主人公）ev_43
;//人物１：主人公（男）
;//服装１：裸
;//人物２：ヒロイン２
;//服装２：裸
;//場所　：学生寮室内
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sHonoka012"]
[OnName num="Honoka"]
The truth is,......, I want to be by your side all the time."
[cpg cn=true]


The word "really" is superfluous. He never reveals why he can't do that.
[cpg]


 There must be some reason why he doesn't say it stubbornly.
[cpg]


Honoka mumbled as she held me close.
[cpg]


;**【ＣＧ】 ev_43_a ***********************
[CG id=17 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sHonoka013"]
[OnName num="Honoka"]
But if I knew everything, I think ...... you would hesitate to tell me.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（夜）******************************************************

Today is Saturday, which means tomorrow is my day off.
[cpg]


I think that was part of the relief. In any case,......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


We both slept until almost noon.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************


After breakfast and lunch, we went back to our room.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Honoka166"]
[OnName num="Honoka"]
I said, "...... ahaha. You slept well, didn't you?
[cpg cn=true]


I thought to myself, "That's Honoka, too,.......
[cpg]


[OnName num="Rin_male"]
You know, Honoka ......"
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]


We are both students who just started dating. It would be crazy not to do something here.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHonoka014"]
[OnName num="Honoka"]
"...... yeah. Okay, from now on we'll flirt as much as we want."
[cpg cn=true]


Huh. I thought you'd say no.
[cpg]


Did something blow up on Honoka's part?
[cpg]


If so, I just want to see if the problem has been resolved or if it still remains.
[cpg]



[OnName num="Rin_male"]
I'm not sure what you're talking about. Why did you ever say no to that ...... kiss or whatever?"
[cpg cn=true]


I'm the one who's been asking the awkward questions.
[cpg]


I need to step in more, but I don't have the courage.
[cpg]


I'm aware of it, too. That's why I couldn't go in.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Honoka168"]
[OnName num="Honoka"]
She said, "Well, ...... we're supposed to be a couple of women, aren't we? So I thought it would be better to refrain from this kind of thing."
[cpg cn=true]


See, he responded with a reply that was obviously a lie.
[cpg]


I don't think that's the only reason. Because this is my soon-to-be girlfriend who will soon become a woman.
[cpg]


I'm a man, and it would be more natural for me to think of a normal relationship while I'm still a man.
[cpg]



[OnName num="Rin_male"]
......I see, so you were right."
[cpg cn=true]


I pretended to be convinced, too. I'm not convinced at all.
[cpg]


But there is nothing more I can do. She might cry if I forcefully ask her about it.
[cpg]


I don't want to see her cry. So I don't think I made the wrong choice, I want to think so. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

I also got the OK from Honoka. I flirted with her to make up for what I couldn't do before.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学生寮室内』（昼）******************************************************


Then, right beside me, Honoka continued to speak.
[cpg]



[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHonoka015"]
[OnName num="Honoka"]
I'm going to do this for the rest of the day. I'm going to do this all day.
[cpg cn=true]


Finally, Honoka smiles a little. But I can see that she is carrying tremendous sadness behind it.
[cpg]


What should I do? I feel like this happiness will continue for a while even if I let it go.
[cpg]


Because if not, Honoka would not be able to smile, even if it is a lie.
[cpg]


Isn't it human nature to want to be immersed in happiness, even if it is temporary?
[cpg]


Do I really need to think about her lie until I become unhappy myself?
[cpg]



;//ここまでにバッドエンド固定の分岐を通っている場合、選択肢は発生せず２を選んだことになる
[if exp={getFlagValue("ChaBad") == 1}]
[jump target=*select07_2]
[endif]


;//■選択肢
[switch]
[case "Think about it."]
	[swap]
	[jump target="*select07_1"]
[case "Do not think about it"]
	[swap]
	[jump target="*select07_2"]
[endswitch]



1. think about it
2. don't think about it



;//==============================
;//１、考える
*select07_1
[jump storage="ep011.ks" target="*select07_1"]



;//==============================
;//２、考えない

*select07_2
[jump storage="ep012.ks" target="*select07_2"]

